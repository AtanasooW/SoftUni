﻿namespace MusicHub
{
    using System;
    using System.Globalization;
    using System.Text;
    using Data;
    using Initializer;

    public class StartUp
    {
        public static void Main()
        {
            MusicHubDbContext context =
                new MusicHubDbContext();
            DbInitializer.ResetDatabase(context);

            //Test your solutions here
            Console.WriteLine(ExportAlbumsInfo(context, 9));
        }

        public static string ExportAlbumsInfo(MusicHubDbContext context, int producerId)
        {
            var albums = context.Albums.Where(a => a.ProducerId.HasValue && a.ProducerId.Value == producerId).OrderByDescending(a => a.Price);
            var sb = new StringBuilder();

            foreach (var album in albums)
            {
                sb.AppendLine($"-AlbumName: {album.Name}" + Environment.NewLine +
                    $"-ReleaseDate: {album.ReleaseDate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture)}" + Environment.NewLine +
                    $"-ProducerName: {album.Producer.Name}" + Environment.NewLine +
                    $"-Songs:");
                int count = 1;
                foreach (var item in album.Songs)
                {
                    sb.AppendLine($"---#{count}" + Environment.NewLine +
                    $"---SongName: {item.Name}" + Environment.NewLine +
                    $"---Price: {item.Price}" + Environment.NewLine +
                    $"---Writer: {item.Writer.Name}");
                    count++;
                }
                sb.Append($"-AlbumPrice: {album.Price}");

            }
            return sb.ToString().Trim();
        }

        public static string ExportSongsAboveDuration(MusicHubDbContext context, int duration)
        {
            throw new NotImplementedException();
        }
    }
}
