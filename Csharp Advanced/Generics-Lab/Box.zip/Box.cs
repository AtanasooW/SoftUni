﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BoxOfT
{
    public class Box<T>
    {
        public int Count { get; set; }
        private List<T> list;
        public Box()
        {
            list = new List<T>();
            Count = 0;
        }
        public void Add(T element)
        {
            this.list.Add(element);
            Count++;
        }
        public T Remove()
        {
            T element = this.list[this.Count - 1];
            list.Remove(element);
            Count--;
            return element;
        }
    }
}
