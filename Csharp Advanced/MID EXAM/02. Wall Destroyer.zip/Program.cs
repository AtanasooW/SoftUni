﻿using System;
using System.Linq;

namespace _02._Wall_Destroyer
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            char[,] matrix = new char[n, n];
            int[] cordinates = new int[2];
            int couter = 1;
            int rods = 0;
            string cmd = "";
            for (int i = 0; i < n; i++)
            {
                string text = Console.ReadLine();
                char[] chars = text.ToCharArray();
                for (int cols = 0; cols < n; cols++)
                {
                    matrix[i, cols] = chars[cols];
                    if (matrix[i,cols] == 'V')
                    {
                        (cordinates[0], cordinates[1]) = (i, cols);
                    }
                }
            }
            while (true)
            {
                cmd = Console.ReadLine();
                if (cmd == "End")
                    break;
                //UP
                if (cmd == "up")
                {
                    if (cordinates[0] - 1 >= 0)
                    {
                        if (matrix[cordinates[0] - 1, cordinates[1]] == 'C')
                        {
                            matrix[cordinates[0], cordinates[1]] = '*';
                            matrix[cordinates[0] - 1, cordinates[1]] = 'E';
                            couter++;
                            Console.WriteLine($"Vanko got electrocuted, but he managed to make {couter} hole(s).");
                            break;
                        }
                        else if (matrix[cordinates[0] - 1, cordinates[1]] == 'R')
                        {
                            Console.WriteLine("Vanko hit a rod!");
                            rods++;
                          
                        }
                        else if (matrix[cordinates[0] - 1, cordinates[1]] == '*')
                        {
                            matrix[cordinates[0] - 1, cordinates[1]] = 'V';
                            matrix[cordinates[0], cordinates[1]] = '*';
                            cordinates[0]--; 
                            Console.WriteLine($"The wall is already destroyed at position [{cordinates[0]}, {cordinates[1]}]!");
                        }
                        else
                        {
                            matrix[cordinates[0], cordinates[1]] = '*';
                            couter++;
                            cordinates[0]--;
                            matrix[cordinates[0], cordinates[1]] = 'V';
                            
                        }
                    }
                }
                //RIGHT
                else if (cmd == "right")
                {
                    if (cordinates[1] + 1 < n)
                    {
                        if (matrix[cordinates[0], cordinates[1] + 1] == 'C')
                        {
                            matrix[cordinates[0], cordinates[1]] = '*';
                            matrix[cordinates[0], cordinates[1] + 1] = 'E';
                            couter++;
                            Console.WriteLine($"Vanko got electrocuted, but he managed to make {couter} hole(s).");
                            break;
                        }
                        else if (matrix[cordinates[0], cordinates[1] + 1] == 'R')
                        {
                            Console.WriteLine("Vanko hit a rod!");
                            rods++;
                        }
                        else if (matrix[cordinates[0], cordinates[1]+ 1] == '*')
                        {
                            matrix[cordinates[0], cordinates[1] + 1] = 'V';
                            matrix[cordinates[0], cordinates[1]] = '*';
                            cordinates[1]++;
                            Console.WriteLine($"The wall is already destroyed at position [{cordinates[0]}, {cordinates[1]}]!");
                        }
                        else
                        {
                            matrix[cordinates[0], cordinates[1]] = '*';
                            couter++;
                            cordinates[1]++;
                            matrix[cordinates[0], cordinates[1]] = 'V';
                        }
                    }
                }
                //DOWN
                else if (cmd == "down")
                {
                    if (cordinates[0] + 1 < n)
                    {
                        if (matrix[cordinates[0] + 1, cordinates[1]] == 'C')
                        {
                            matrix[cordinates[0], cordinates[1]] = '*';
                            couter++;
                            matrix[cordinates[0] + 1, cordinates[1]] = 'E';
                            Console.WriteLine($"Vanko got electrocuted, but he managed to make {couter} hole(s).");
                            break;
                        }
                        else if (matrix[cordinates[0] + 1, cordinates[1]] == 'R')
                        {
                            Console.WriteLine("Vanko hit a rod!");
                            rods++;
                        }
                        else if (matrix[cordinates[0] + 1, cordinates[1]] == '*')
                        {
                            matrix[cordinates[0] + 1, cordinates[1]] = 'V';
                            matrix[cordinates[0], cordinates[1]] = '*';
                            cordinates[0]++;
                            Console.WriteLine($"The wall is already destroyed at position [{cordinates[0]}, {cordinates[1]}]!");
                        }
                        else
                        {
                            matrix[cordinates[0], cordinates[1]] = '*';
                            couter++;
                            cordinates[0]++;
                            matrix[cordinates[0], cordinates[1]] = 'V';
                        }
                    }
                }
                //LEFT
                if (cmd == "left")
                {
                    if (cordinates[1] - 1 >= 0)
                    {
                        if (matrix[cordinates[0], cordinates[1] - 1] == 'C')
                        {
                            matrix[cordinates[0], cordinates[1]] = '*';
                            couter++;
                            matrix[cordinates[0], cordinates[1] - 1] = 'E';
                            Console.WriteLine($"Vanko got electrocuted, but he managed to make {couter} hole(s).");
                            break;
                        }
                        else if (matrix[cordinates[0], cordinates[1] - 1] == 'R')
                        {
                            Console.WriteLine("Vanko hit a rod!");
                            rods++;
                        }
                        else if (matrix[cordinates[0], cordinates[1] - 1] == '*')
                        {
                            matrix[cordinates[0], cordinates[1] - 1] = 'V';
                            matrix[cordinates[0], cordinates[1]] = '*';
                            cordinates[1]--;
                            Console.WriteLine($"The wall is already destroyed at position [{cordinates[0]}, {cordinates[1]}]!");
                        }
                        else
                        {
                            matrix[cordinates[0], cordinates[1]] = '*';
                            couter++;
                            cordinates[1]--;
                            matrix[cordinates[0], cordinates[1]] = 'V';
                        }
                    }
                }
            }
            if (cmd ==  "End")
            {
                Console.WriteLine($"Vanko managed to make {couter} hole(s) and he hit only {rods} rod(s).");
            }
            PrintTheMatrix(matrix, n);
            
        }

        private static void PrintTheMatrix(char[,] matrix, int n)
        {
            for (int i = 0; i < n; i++)
            {
                for (int cols = 0; cols < n; cols++)
                {
                    Console.Write(matrix[i, cols]);
                }
                Console.WriteLine();
            }
        }
    }
}
