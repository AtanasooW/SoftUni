﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace EX_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Stack<int> stack = new Stack<int>(Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries).Select(int.Parse));
            Queue<int> queue = new Queue<int>(Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries).Select(int.Parse));
            var dic = new SortedDictionary<string, int>();
            while (true)
            {
                if (stack.Count < 1)
                    break;
                if (queue.Count < 1)
                    break;
                else
                {
                    if (stack.Peek() == queue.Peek())
                    {
                        int sum = stack.Pop() + queue.Dequeue();
                        if (sum == 40)
                        {
                            if (!dic.ContainsKey("Sink"))
                            {
                                dic["Sink"] = 1;
                            }
                            else
                            {
                                dic["Sink"]++;
                            }
                        }
                        else if (sum == 50)
                        {
                            if (!dic.ContainsKey("Oven"))
                            {
                                dic["Oven"] = 1;
                            }
                            else
                            {
                                dic["Oven"]++;
                            }
                        }
                        else if (sum == 60)
                        {
                            if (!dic.ContainsKey("Countertop"))
                            {
                                dic["Countertop"] = 1;
                            }
                            else
                            {
                                dic["Countertop"]++;
                            }
                        }
                        else if (sum == 70)
                        {
                            if (!dic.ContainsKey("Wall"))
                            {
                                dic["Wall"] = 1;
                            }
                            else
                            {
                                dic["Wall"]++;
                            }
                        }
                        else
                        {
                            if (!dic.ContainsKey("Floor"))
                            {
                                dic["Floor"] = 1;
                            }
                            else
                            {
                                dic["Floor"]++;
                            }
                        }
                    }
                    else
                    {
                        int white = stack.Pop() / 2;
                        int grey = queue.Dequeue();
                        stack.Push(white);
                        queue.Enqueue(grey);
                    }
                }
            }
            if (stack.Count > 0)
            {
                Console.WriteLine($"White tiles left: {String.Join(", ", stack)}");
            }
            else
            {
                Console.WriteLine("White tiles left: none");
            }
            if (queue.Count > 0)
            {
                Console.WriteLine($"Grey tiles left: {String.Join(", ",queue)}");
            }
            else
            {
                Console.WriteLine("Grey tiles left: none");
            }

            foreach (var item in dic.OrderByDescending(x => x.Value))
            {
                Console.WriteLine($"{item.Key}: {item.Value}");
            }
        }
    }
}
