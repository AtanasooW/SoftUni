﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TheRace
{
    public class Race
    {
        public List<Racer> data { get; set; }
        public string Name { get; set; }
        public int Capacity { get; set; }

        public Race(string name, int capacity)
        {
            this.data = new List<Racer>();
            this.Name = name;
            this.Capacity = capacity;
        }
        public void Add(Racer racer)
        {
            if (Capacity > 0)
            {
                data.Add(racer);
                Capacity--;
            }
        }
        public bool Remove(string Name)
        {
            if (data.Count < 1)
                return false;
            else
            {
                var removeTheRacer = data.FirstOrDefault(x => x.Name == Name);
                if (removeTheRacer == null)
                    return false;

                else if (removeTheRacer.Name == Name)
                {
                    data.Remove(removeTheRacer);
                    Capacity++;
                    return true;
                }
                return false;
            }
        }
        public Racer GetOldestRacer()
        {
            if (data.Count < 1)
                return null;
            else
            {
                int AgeOfTheldestRacer = data.Max(x => x.Age);
                var getOldestRacer = data.FirstOrDefault(x => x.Age == AgeOfTheldestRacer);
                return getOldestRacer;
            }
        }
        public Racer GetRacer(string name)
        {
            if (data.Count < 1)
                return null;
            else
            {
                var getRacerByName = data.FirstOrDefault(x => x.Name == name);
                return getRacerByName;
            }
        }
        public Racer GetFastestRacer()
        {
            if (data.Count < 1)
                return null;
            else
            {
                var getFastestCar = data.Max(x => x.Car.Speed);
                Racer fastestRacer = data.FirstOrDefault(x => x.Car.Speed == getFastestCar);
                return fastestRacer;
            }
        }
        public int Count
        {
            get => data.Count;
        }
        public string Report()
        {
            return $"Racers participating at {this.Name}:" + Environment.NewLine +
                $"{string.Join(Environment.NewLine, data)}";
        }
    }
}
