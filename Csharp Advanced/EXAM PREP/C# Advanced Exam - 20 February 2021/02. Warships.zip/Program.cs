﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _02._Warships
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            char[,] matrix = new char[n, n];
            List<string> input = Console.ReadLine().Split(",", StringSplitOptions.RemoveEmptyEntries).ToList(); // i hate niggers
            int countForP1 = 0;
            int countForP2 = 0;
            for (int i = 0; i < n; i++)
            {
                char[] chars = Console.ReadLine().Split(" ").Select(char.Parse).ToArray();
                for (int cols = 0; cols < n; cols++)
                {
                    matrix[i, cols] = chars[cols];
                    if (matrix[i,cols] == '<')
                    {
                        countForP1++;
                    }
                    else if (matrix[i,cols] == '>')
                    {
                        countForP2++;
                    }
                }
            }
            int sum = countForP1 + countForP2;
            bool P1 = false;
            bool P2 = false;
            for (int i = 0; i < input.Count; i++)
            {
                string[] cmd = input[i].Split(" ", StringSplitOptions.RemoveEmptyEntries);
                int row = int.Parse(cmd[0]);
                int col = int.Parse(cmd[1]);
                if (countForP1 < 1)
                {
                    P1 = true;
                    break;

                }
                if (countForP2 < 1)
                {
                    P2 = true;
                    break;

                }

                if (row >= 0 && row < n && col >= 0 && col < n)
                {
                    if (matrix[row,col] == '<')
                    {
                        matrix[row, col] = 'X';
                        countForP1--;
                    }
                    else if (matrix[row,col] == '>')
                    {
                        matrix[row, col] = 'X';
                        countForP2--;
                    }
                    else if (matrix[row,col] == '#')
                    {
                        //UP
                        if (row - 1 >= 0)
                        {
                            if (matrix[row - 1, col] == '<')
                            {
                                matrix[row - 1, col] = 'X';
                                countForP1--;
                            }
                            else if (matrix[row - 1, col] == '>')
                            {
                                matrix[row - 1, col] = 'X';
                                countForP2--;
                            }
                        }
                        //UP RIGHT
                        if (row - 1 >= 0 && col + 1 < n)
                        {
                            if (matrix[row - 1, col +1] == '<')
                            {
                                matrix[row - 1, col + 1] = 'X';
                                countForP1--;
                            }
                            else if (matrix[row - 1, col + 1] == '>')
                            {
                                matrix[row - 1, col + 1] = 'X';
                                countForP2--;
                            }
                        }
                        //RIGHT
                        if (col + 1 < n)
                        {
                            if (matrix[row , col + 1] == '<')
                            {
                                matrix[row, col + 1] = 'X';
                                countForP1--;
                            }
                            else if (matrix[row , col + 1] == '>')
                            {
                                matrix[row, col + 1] = 'X';
                                countForP2--;
                            }
                        }
                        //DOWN RIGHT
                        if (row + 1 < n && col + 1 < n)
                        {
                            if (matrix[row + 1, col + 1] == '<')
                            {
                                matrix[row + 1, col + 1] = 'X';
                                countForP1--;
                            }
                            else if (matrix[row + 1, col + 1] == '>')
                            {
                                matrix[row + 1, col + 1] = 'X';
                                countForP2--;
                            }
                        }
                        //DOWN
                        if (row + 1 < n)
                        {
                            if (matrix[row + 1, col ] == '<')
                            {
                                matrix[row + 1, col] = 'X';
                                countForP1--;
                            }
                            else if (matrix[row + 1, col] == '>')
                            {
                                matrix[row + 1, col] = 'X';
                                countForP2--;
                            }
                        }
                        //DOWN LEFT
                        if (row + 1 < n && col - 1 >= 0)
                        {
                            if (matrix[row + 1, col - 1] == '<')
                            {
                                matrix[row + 1, col - 1] = 'X';
                                countForP1--;
                            }
                            else if (matrix[row + 1, col - 1] == '>')
                            {
                                matrix[row + 1, col - 1] = 'X';
                                countForP2--;
                            }
                        }
                        //LEFT
                        if (col - 1 >= 0)
                        {
                            if (matrix[row, col - 1] == '<')
                            {
                                matrix[row, col - 1] = 'X';
                                countForP1--;
                            }
                            else if (matrix[row, col - 1] == '>')
                            {
                                matrix[row, col - 1] = 'X';
                                countForP2--;
                            }
                        }
                        //UP LEFT
                        if (row - 1 >= 0 && col - 1 >= 0)
                        {
                            if (matrix[row - 1, col - 1] == '<')
                            {
                                matrix[row - 1, col - 1] = 'X';
                                countForP1--;
                            }
                            else if (matrix[row - 1, col - 1] == '>')
                            {
                                matrix[row - 1, col - 1] = 'X';
                                countForP2--;
                            }
                        }
                    }
                }
                if (countForP1 < 1)
                {
                    P1 = true;
                    break;

                }
                if (countForP2 < 1)
                {
                    P2 = true;
                    break;
                }
            }
            int totalDestroyed = sum - countForP1 - countForP2;
            if (P1)
            {
                Console.WriteLine($"Player Two has won the game! {totalDestroyed} ships have been sunk in the battle.");
            }
            else if (P2)
            {
                Console.WriteLine($"Player One has won the game! {totalDestroyed} ships have been sunk in the battle.");
            }
            else
            {
                Console.WriteLine($"It's a draw! Player One has {countForP1} ships left. Player Two has {countForP2} ships left.");
            }
        }
    }
}
