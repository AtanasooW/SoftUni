﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Food_Finder
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<string> words = new List<string>() { "pear", "flour", "pork", "olive" };
            List<string> newWords = new List<string>();
            Queue<char> queue = new Queue<char>(Console.ReadLine().Split(" ").Select(char.Parse));
            Stack<char> stack = new Stack<char>(Console.ReadLine().Split(" ").Select(char.Parse));
            while (stack.Any())
            {
                char currViwels = queue.Dequeue();
                char currConsonant = stack.Pop();
                for (int i = 0; i < words.Count; i++)
                {
                    if (words[i].Contains(currViwels))
                    {
                       words[i] = words[i].Replace(currViwels.ToString(), "");
                    }
                    if (words[i].Contains(currConsonant))
                    {
                        words[i] = words[i].Replace(currConsonant.ToString(), "");
                    }
                }
                queue.Enqueue(currViwels);
            }
            for (int i = 0; i < words.Count; i++)
            {
                if (words[i].Length == 0)
                {
                    if (i == 0)
                    {
                        newWords.Add("pear");
                    }
                    else if (i == 1)
                    {
                        newWords.Add("flour");
                    }
                    else if (i == 2)
                    {
                        newWords.Add("pork");
                    }
                    else if (i == 3)
                    {
                        newWords.Add("olive");
                    }
                }
            }
            Console.WriteLine($"Words found: {newWords.Count}");
            foreach (var item in newWords)
            {
                Console.WriteLine(item);
            }
        }
    }
}
