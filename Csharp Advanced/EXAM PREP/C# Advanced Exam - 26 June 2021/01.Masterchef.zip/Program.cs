﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _01.Masterchef
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SortedDictionary<string, int> dic = new SortedDictionary<string, int>();
            Queue<int> queue = new Queue<int>(Console.ReadLine().Split(" ").Select(int.Parse));
            Stack<int> stack = new Stack<int>(Console.ReadLine().Split(" ").Select(int.Parse));
            while (true)
            {
                if (queue.Count < 1)
                    break;
                if (stack.Count < 1)
                    break;
                if (queue.Peek() == 0)
                {
                    queue.Dequeue();
                    continue;
                }
                else
                {
                    int sum = stack.Peek() * queue.Peek();
                    if (sum == 150)
                    {
                        if (!dic.ContainsKey("Dipping sauce"))
                        {
                            dic["Dipping sauce"] = 1;
                            queue.Dequeue();
                            stack.Pop();
                        }
                        else
                        {
                            dic["Dipping sauce"]++;
                            queue.Dequeue();
                            stack.Pop();
                        }
                    }
                    else if (sum == 250)
                    {
                        if (!dic.ContainsKey("Green salad"))
                        {
                            dic["Green salad"] = 1;
                            queue.Dequeue();
                            stack.Pop();
                        }
                        else
                        {
                            dic["Green salad"]++;
                            queue.Dequeue();
                            stack.Pop();
                        }
                    }
                    else if (sum == 300)
                    {
                        if (!dic.ContainsKey("Chocolate cake"))
                        {
                            dic["Chocolate cake"] = 1;
                            queue.Dequeue();
                            stack.Pop();
                        }
                        else
                        {
                            dic["Chocolate cake"]++;
                            queue.Dequeue();
                            stack.Pop();
                        }
                    }
                    else if (sum == 400)
                    {
                        if (!dic.ContainsKey("Lobster"))
                        {
                            dic["Lobster"] = 1;
                            queue.Dequeue();
                            stack.Pop();
                        }
                        else
                        {
                            dic["Lobster"]++;
                            queue.Dequeue();
                            stack.Pop();
                        }
                    }
                    else
                    {
                        stack.Pop();
                        int save = queue.Dequeue() + 5;
                        queue.Enqueue(save);
                    }
                }
            }
            if (dic.Count() == 4)
            {
                Console.WriteLine("Applause! The judges are fascinated by your dishes!");
                if (queue.Count > 0)
                {
                    Console.WriteLine($"Ingredients left: {queue.Sum()}");
                }
                else
                {

                }
                foreach (var item in dic)
                {
                    Console.WriteLine($"# {item.Key} --> {item.Value}");
                }
            }
            else
            {
                Console.WriteLine("You were voted off. Better luck next year.");
                if (queue.Count > 0)
                {
                    Console.WriteLine($"Ingredients left: {queue.Sum()}");
                }
                else
                {

                }
                foreach (var item in dic)
                {
                    Console.WriteLine($"# {item.Key} --> {item.Value}");
                }
            }
        }
    }
}
