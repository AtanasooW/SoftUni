﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace SkiRental
{
    public class SkiRental
    {
        private List<Ski> data;
        public string Name { get; set; }
        public int Capacity { get; set; }

        public SkiRental(string name, int capasity)
        {
            this.Name = name;
            this.Capacity = capasity;
            this.data = new List<Ski>();
        }
        public void Add(Ski ski)
        {
            if (data.Count < Capacity)
            {
                this.data.Add(ski);
                this.Capacity--;
            }
        }
        public bool Remove(string manufacturer, string model)
        {
            if (data.Count < 1)
                return false;
            else
            {

            var findTheSki = data.FirstOrDefault(x => x.Manufacturer == manufacturer && x.Model == model);
            if (findTheSki == null)
                return false;

            if (findTheSki.Manufacturer == manufacturer && findTheSki.Model == model)
                data.Remove(findTheSki);
            this.Capacity++;
            return true;
            }
        }
        public Ski GetNewestSki()
        {
            if (data.Count < 1)
                return null;
            else
            {
                int NewestSkiByYear = data.Max(x => x.Year);
                Ski theNewestSki = data.FirstOrDefault(x => x.Year == NewestSkiByYear);
                return theNewestSki;
            }
        }
        public Ski GetSki(string manufacturer, string model)
        {
            if (data.Count < 1)
                return null;
            else
            {
                var getTheSki = data.FirstOrDefault(x => x.Manufacturer == manufacturer && x.Model == model);
                if (getTheSki == null)
                    return null;
                if (getTheSki.Manufacturer == manufacturer && getTheSki.Model == model)
                    return getTheSki;
            }
            return null;
        }
        public int Count
        {
            get => data.Count;
        }
        public string GetStatistics()
        {
            return $"The skis stored in {this.Name}:" + Environment.NewLine +
            $"{String.Join(Environment.NewLine, data)}";
        }
    }
}
