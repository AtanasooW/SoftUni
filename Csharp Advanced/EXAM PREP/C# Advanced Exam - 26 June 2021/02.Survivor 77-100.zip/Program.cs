﻿using System;
using System.Linq;

namespace _02.Survivor
{
    internal class Program
    {
        private static char[][] jakedArry;
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            char[][] jakedArry = new char[n][];
            int oursToken = 0;
            int opponentsToken = 0;
            for (int rows = 0; rows < n; rows++)
            {
                char[] arry = Console.ReadLine().Split(" ").Select(char.Parse).ToArray();
                    jakedArry[rows] = arry;
            }
            while (true)
            {
                string[] cmd = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                if (cmd[0] == "Gong")
                    break;
                if (cmd[0] == "Find")
                {
                    if (int.Parse(cmd[1]) <= n)
                    {
                        if (int.Parse(cmd[2]) <= jakedArry[int.Parse(cmd[1])].Length)
                        {
                            if (jakedArry[int.Parse(cmd[1])][int.Parse(cmd[2])] == 'T')
                            {
                                oursToken++;
                                jakedArry[int.Parse(cmd[1])][int.Parse(cmd[2])] = '-';
                            }
                        }
                    }
                }
                else if (cmd[0] == "Opponent")
                {
                    if (int.Parse(cmd[1]) <= n)
                    {
                        if (int.Parse(cmd[2]) <= jakedArry[int.Parse(cmd[1])].Length)
                        {
                            if (jakedArry[int.Parse(cmd[1])][int.Parse(cmd[2])] == 'T')
                            {
                                opponentsToken++;
                                jakedArry[int.Parse(cmd[1])][int.Parse(cmd[2])] = '-';
                                if (cmd[3] == "up")
                                {
                                    int rows = int.Parse(cmd[1]);
                                    int cols = int.Parse(cmd[2]);
                                    for (int i = 0; i < 3; i++)
                                    {
                                        if (rows - 1 <= n)
                                        {
                                            if (cols < jakedArry[rows - 1].Length)
                                            {
                                                if (jakedArry[rows - 1][cols] == 'T')
                                                {
                                                    jakedArry[rows - 1][cols] = '-';
                                                    opponentsToken++;
                                                    rows--;
                                                }
                                                else if (jakedArry[rows - 1][cols] == '-')
                                                {
                                                    rows--;
                                                }
                                            }
                                            else
                                            break;
                                        }
                                        else
                                        break;  
                                    }
                                }
                                else if (cmd[3] == "down")
                                {
                                    int rows = int.Parse(cmd[1]);
                                    int cols = int.Parse(cmd[2]);
                                    for (int i = 0; i < 3; i++)
                                    {
                                        if (rows + 1 <= n)
                                        {
                                            if (cols < jakedArry[rows + 1].Length)
                                            {
                                                if (jakedArry[rows + 1][cols] == 'T')
                                                {
                                                    jakedArry[rows + 1][cols] = '-';
                                                    opponentsToken++;
                                                    rows++;
                                                }
                                                else if (jakedArry[rows + 1][cols] == '-')
                                                {
                                                    rows++;
                                                }
                                            }
                                            else
                                                break;
                                        }
                                        else
                                            break;
                                    }
                                }
                                else if (cmd[3] == "left")
                                {
                                    int rows = int.Parse(cmd[1]);
                                    int cols = int.Parse(cmd[2]);
                                    for (int i = 0; i < 3; i++)
                                    {
                                        if (rows <= n)
                                        {
                                            if (cols - 1 < jakedArry[rows].Length)
                                            {
                                                if (jakedArry[rows][cols - 1] == 'T')
                                                {
                                                    jakedArry[rows][cols - 1] = '-';
                                                    opponentsToken++;
                                                    cols--;
                                                }
                                                else if (jakedArry[rows][cols - 1] == '-')
                                                {
                                                    cols--;
                                                }
                                            }
                                            else
                                                break;
                                        }
                                        else
                                            break;
                                    }
                                }
                                else if (cmd[3] == "right")
                                {
                                    int rows = int.Parse(cmd[1]);
                                    int cols = int.Parse(cmd[2]);
                                    for (int i = 0; i < 3; i++)
                                    {
                                        if (rows <= n)
                                        {
                                            if (cols + 1 < jakedArry[rows].Length)
                                            {
                                                if (jakedArry[rows][cols + 1] == 'T')
                                                {
                                                    jakedArry[rows][cols + 1] = '-';
                                                    opponentsToken++;
                                                    cols++;
                                                }
                                                else if (jakedArry[rows][cols + 1] == '-')
                                                {
                                                    cols++;
                                                }
                                            }
                                            else
                                                break;
                                        }
                                        else
                                            break;
                                    }
                                }
                            }
                            else if (jakedArry[int.Parse(cmd[1])][int.Parse(cmd[2])] == '-')
                            {
                                jakedArry[int.Parse(cmd[1])][int.Parse(cmd[2])] = '-';
                                if (cmd[3] == "up")
                                {
                                    int rows = int.Parse(cmd[1]);
                                    int cols = int.Parse(cmd[2]);
                                    for (int i = 0; i < 3; i++)
                                    {
                                        if (rows - 1 <= n)
                                        {
                                            if (cols < jakedArry[rows - 1].Length)
                                            {
                                                if (jakedArry[rows - 1][cols] == 'T')
                                                {
                                                    jakedArry[rows - 1][cols] = '-';
                                                    opponentsToken++;
                                                    rows--;
                                                }
                                                else if (jakedArry[rows - 1][cols] == '-')
                                                {
                                                    rows--;
                                                }
                                            }
                                            else
                                                break;
                                        }
                                        else
                                            break;
                                    }
                                }
                                else if (cmd[3] == "down")
                                {
                                    int rows = int.Parse(cmd[1]);
                                    int cols = int.Parse(cmd[2]);
                                    for (int i = 0; i < 3; i++)
                                    {
                                        if (rows + 1 <= n)
                                        {
                                            if (cols < jakedArry[rows + 1].Length)
                                            {
                                                if (jakedArry[rows + 1][cols] == 'T')
                                                {
                                                    jakedArry[rows + 1][cols] = '-';
                                                    opponentsToken++;
                                                    rows++;
                                                }
                                                else if (jakedArry[rows + 1][cols] == '-')
                                                {
                                                    rows++;
                                                }
                                            }
                                            else
                                                break;
                                        }
                                        else
                                            break;
                                    }
                                }
                                else if (cmd[3] == "left")
                                {
                                    int rows = int.Parse(cmd[1]);
                                    int cols = int.Parse(cmd[2]);
                                    for (int i = 0; i < 3; i++)
                                    {
                                        if (rows <= n)
                                        {
                                            if (cols - 1 < jakedArry[rows].Length)
                                            {
                                                if (jakedArry[rows][cols - 1] == 'T')
                                                {
                                                    jakedArry[rows][cols - 1] = '-';
                                                    opponentsToken++;
                                                    cols--;
                                                }
                                                else if (jakedArry[rows][cols - 1] == '-')
                                                {
                                                    cols--;
                                                }
                                            }
                                            else
                                                break;
                                        }
                                        else
                                            break;
                                    }
                                }
                                else if (cmd[3] == "right")
                                {
                                    int rows = int.Parse(cmd[1]);
                                    int cols = int.Parse(cmd[2]);
                                    for (int i = 0; i < 3; i++)
                                    {
                                        if (rows <= n)
                                        {
                                            if (cols + 1 < jakedArry[rows].Length)
                                            {
                                                if (jakedArry[rows][cols + 1] == 'T')
                                                {
                                                    jakedArry[rows][cols + 1] = '-';
                                                    opponentsToken++;
                                                    cols++;
                                                }
                                                else if (jakedArry[rows][cols + 1] == '-')
                                                {
                                                    cols++;
                                                }
                                            }
                                            else
                                                break;
                                        }
                                        else
                                            break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            for (int rows = 0; rows < n; rows++)
            {
                foreach (var item in jakedArry[rows])
                {
                    Console.Write(item + " ");
                }
                Console.WriteLine();
            }
            Console.WriteLine($"Collected tokens: {oursToken}");
            Console.WriteLine($"Opponent's tokens: {opponentsToken}");
        }
    }
}
