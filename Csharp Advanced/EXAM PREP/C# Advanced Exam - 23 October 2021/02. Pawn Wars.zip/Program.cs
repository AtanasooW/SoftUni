﻿using System;
using System.Linq;

namespace _02._Pawn_Wars
{
    internal class Program
    {
        static void Main(string[] args)
        {
            char[,] matrix = new char[8, 8];
            int[] cordinatesOfWhite = new int[2];
            int[] cordinatesOfBlack = new int[2];
            for (int rows = 0; rows < 8; rows++)
            {
                string text = Console.ReadLine();
                char[] arry = text.ToCharArray();
                for (int cols = 0; cols < 8; cols++)
                {
                    matrix[rows, cols] = arry[cols];
                    if (matrix[rows, cols] == 'w')
                    {
                        cordinatesOfWhite[0] = rows;
                        cordinatesOfWhite[1] = cols;
                    }
                    else if (matrix[rows, cols] == 'b')
                    {
                        cordinatesOfBlack[0] = rows;
                        cordinatesOfBlack[1] = cols;
                    }
                }
            }
            bool white = false;
            bool black = false;
            while (true)
            {
                white = WhiteMoveFoward(matrix, cordinatesOfWhite, white);
                if (white)
                {
                    return;
                }
                black = BlackMoveDown(matrix, cordinatesOfBlack, black);
                if (black)
                {
                    return;
                }
                //printTheMatrix(matrix);
            }

        }
        private static bool WhiteMoveFoward(char[,] matrix, int[] cordinatesOfWhite, bool white)
        {
            if (cordinatesOfWhite[0] - 1 < 0)
            {
                char c = (char)(cordinatesOfWhite[1] + 97);
                Console.WriteLine($"Game over! White pawn is promoted to a queen at {c}{8 + cordinatesOfWhite[0]}.");
                return white = true;
            }
            if (cordinatesOfWhite[1] + 1 <= 7)
            {

                if (matrix[cordinatesOfWhite[0] - 1, cordinatesOfWhite[1] + 1] == 'b')
                {
                    char c = (char)(cordinatesOfWhite[1] + 1 + 97);
                    Console.WriteLine($"Game over! White capture on {c}{8 - cordinatesOfWhite[0] + 1}.");
                    return white = true;
                }
            }
            if (cordinatesOfWhite[1] - 1 >= 0)
            {
                if (matrix[cordinatesOfWhite[0] - 1, cordinatesOfWhite[1] - 1] == 'b')
                {
                    char c = (char)(cordinatesOfWhite[1] - 1 + 97);
                    Console.WriteLine($"Game over! White capture on {c}{8 - cordinatesOfWhite[0] + 1}.");
                    return white = true;
                }
            }

            if (matrix[cordinatesOfWhite[0] - 1,cordinatesOfWhite[1]] == '-')
            {
                matrix[cordinatesOfWhite[0], cordinatesOfWhite[1]] = '-';
                (cordinatesOfWhite[0], cordinatesOfWhite[1]) = (cordinatesOfWhite[0] - 1, cordinatesOfWhite[1]);
                matrix[cordinatesOfWhite[0], cordinatesOfWhite[1]] = 'w';
            }
            return white;
        }

        private static void printTheMatrix(char[,] matrix)
        {
            for (int rows = 0; rows < 8; rows++)
            {
                for (int cols = 0; cols < 8; cols++)
                {
                    Console.Write(matrix[rows, cols]);
                }
                Console.WriteLine();
            }
            Console.WriteLine();
        }

        private static bool BlackMoveDown(char[,] matrix, int[] cordinatesOfBlack, bool black)
        {
            if (cordinatesOfBlack[0] + 1 > 7)
            {
                char c = (char)(cordinatesOfBlack[1] + 97);
                Console.WriteLine($"Game over! Black pawn is promoted to a queen at {c}{8 - cordinatesOfBlack[0]}.");
                return black = true;
            }
            if (cordinatesOfBlack[1] + 1 <= 7)
            {
                if (matrix[cordinatesOfBlack[0] + 1, cordinatesOfBlack[1] + 1] == 'w')
                {
                    char c = (char)(cordinatesOfBlack[1] + 1 + 97);
                    Console.WriteLine($"Game over! Black capture on {c}{8 - cordinatesOfBlack[0] - 1}.");
                    return black = true;
                }

            }
            if (cordinatesOfBlack[1] - 1 >= 0)
            {
                if (matrix[cordinatesOfBlack[0] + 1, cordinatesOfBlack[1] - 1] == 'w')
                {
                    char c = (char)(cordinatesOfBlack[1] - 1 + 97);
                    Console.WriteLine($"Game over! Black capture on {c}{8 - cordinatesOfBlack[0] - 1}.");
                    return black = true;
                }

            }
            if (matrix[cordinatesOfBlack[0] + 1, cordinatesOfBlack[1]] == '-')
            {
                matrix[cordinatesOfBlack[0], cordinatesOfBlack[1]] = '-';
                (cordinatesOfBlack[0], cordinatesOfBlack[1]) = (cordinatesOfBlack[0] + 1, cordinatesOfBlack[1]);
                matrix[cordinatesOfBlack[0], cordinatesOfBlack[1]] = 'b';
            }
            return black;
        }

    }
}
