﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace StockMarket
{
    public class Investor
    {
        public List<Stock> Portfolio { get; set; }
        public string FullName { get; set; }
        public string EmailAddress { get; set; }
        public decimal MoneyToInvest { get; set; }
        public string BrokerName { get; set; }
        public Investor(string fullName, string emailAdress, decimal moneyToInvest, string brokerName)
        {
            this.Portfolio = new List<Stock>();
            this.FullName = fullName;
            this.EmailAddress = emailAdress;
            this.MoneyToInvest = moneyToInvest;
            this.BrokerName = brokerName;
        }
        public int Count
        {
            get => this.Portfolio.Count;
        }


        public void BuyStock(Stock stock)
        {
            if (stock.MarketCapitalization > 10000)
            {
                if (this.MoneyToInvest >= stock.PricePerShare)
                {
                    this.Portfolio.Add(stock);
                    this.MoneyToInvest -= stock.PricePerShare;
                }
            }
        }

        public string SellStock(string companyName, decimal sellPrice)
        {
            if (this.Portfolio.Count < 1)
            {
                return $"{companyName} does not exist.";
            }
            else
            {

                var sellingStock = this.Portfolio.FirstOrDefault(x => x.CompanyName == companyName);
                if (sellingStock == null)
                    return $"{companyName} does not exist.";
                else
                {
                    if (sellingStock.PricePerShare > sellPrice)
                        return $"Cannot sell {companyName}.";
                    else
                    {
                        this.Portfolio.Remove(sellingStock);
                        this.MoneyToInvest += sellPrice;
                        return $"{companyName} was sold.";
                    }
                }
            }
        }
        public Stock FindStock(string companyName)
        {
            if (this.Portfolio.Count < 1)
            {
                return null;
            }
            else
            {
            var findStock = this.Portfolio.FirstOrDefault(x => x.CompanyName == companyName);
            if (findStock == null)
                return null;
            else
                return findStock;
            }

        }
        public Stock FindBiggestCompany()
        {
            if (this.Portfolio.Count < 1)
            {
                return null;
            }
            else
            {
                var findStock = this.Portfolio.Max(x => x.MarketCapitalization);
                Stock theBiggestCompany = this.Portfolio.FirstOrDefault(x => x.MarketCapitalization == findStock);
                if (theBiggestCompany == null)
                    return null;
                else
                return theBiggestCompany;
                
            }
        }
        public string InvestorInformation()
        {
            return $"The investor {this.FullName} with a broker {this.BrokerName} has stocks:" + Environment.NewLine +
            $"{String.Join(Environment.NewLine, this.Portfolio)}";
        }

    }
}
