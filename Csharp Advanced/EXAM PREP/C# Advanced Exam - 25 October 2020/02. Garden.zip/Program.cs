﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _02._Garden
{
    public class CodinatesOfTheFlowers
    {
        public int Row{ get; set; }
        public int Col{ get; set; }

        public CodinatesOfTheFlowers(int row, int col)
        {
            Row = row;
            Col = col;
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] dimensions = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();
            List<CodinatesOfTheFlowers> list = new List<CodinatesOfTheFlowers>();
            (int row, int col) = (dimensions[0], dimensions[1]);
            int[,] matrix = new int[row, col];
            for (int i = 0; i < row; i++)
            {
                for (int cols = 0; cols < col; cols++)
                {
                    matrix[i, cols] = 0;
                }
            }
            while (true)
            {
                string[] cmd = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                if (cmd[0] == "Bloom" && cmd[1] == "Bloom")
                    break;

                else
                {
                    int curRow = int.Parse(cmd[0]);
                    int curCol = int.Parse(cmd[1]);
                    if (curRow >= 0 && curRow < row)
                    {
                        if (curCol >= 0 && curCol < col)
                        {
                            CodinatesOfTheFlowers curFlower = new CodinatesOfTheFlowers(curRow, curCol);
                            list.Add(curFlower);
                        }
                        else
                        {
                            Console.WriteLine("Invalid coordinates.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid coordinates.");
                    }
                }
            }
            foreach (var item in list)
            {
                int row1 = item.Row;
                int col1 = item.Col;
                matrix[row1, col1] = 1;
                //up
                int rowsForUp = row1;
                while (true)
                {
                    rowsForUp--;
                    if (rowsForUp < 0)
                        break;
                    else
                    {
                        matrix[rowsForUp, col1]++;
                    }
                }
                //right
                int colsForRight = col1;
                while (true)
                {
                    colsForRight++;
                    if (colsForRight == col)
                    break;
                    else
                    {
                        matrix[row1, colsForRight]++;
                    }
                }
                //down
                int rowsForDown = row1;
                while (true)
                {
                    rowsForDown++;
                    if (rowsForDown == row)
                        break;
                    else
                    {
                        matrix[rowsForDown, col1]++;
                    }
                }
                //left
                int colsForLeft = col1;
                while (true)
                {
                    colsForLeft--;
                    if (colsForLeft < 0)
                    break;
                    else
                    {
                        matrix[row1, colsForLeft]++;
                    }
                }
            }
            for (int i = 0; i < row; i++)
            {
                for (int cols = 0; cols < col; cols++)
                {
                    Console.Write(matrix[i,cols] + " ");
                }
                Console.WriteLine();
            }
        }
    }
}
