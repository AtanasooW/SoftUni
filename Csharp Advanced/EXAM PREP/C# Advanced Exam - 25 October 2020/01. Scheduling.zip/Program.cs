﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _01._Scheduling
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var stack = new Stack<int>(Console.ReadLine().Split(", ", StringSplitOptions.RemoveEmptyEntries).Select(int.Parse));
            var queue = new Queue<int>(Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries).Select(int.Parse));
            int kilingNum = int.Parse(Console.ReadLine());
            while (true)
            {
                if (kilingNum == stack.Peek())
                break;

                else
                {
                    if (queue.Peek() >= stack.Peek())
                    {
                        queue.Dequeue();
                        stack.Pop();
                    }
                    else if (queue.Peek() < stack.Peek())
                    {
                        queue.Dequeue();
                    }
                }
            }
            Console.WriteLine($"Thread with value {queue.Peek()} killed task {kilingNum}");
            Console.WriteLine(String.Join(" ", queue));
        }
    }
}
