﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace Bakery_Shop
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SortedDictionary<string, int> dic = new SortedDictionary<string, int>();
           
            Queue<double> queue = new Queue<double>();
            double[] waterNums = Console.ReadLine().Split(" ").Select(double.Parse).ToArray();
            for (int i = 0; i < waterNums.Length; i++)
            {
                queue.Enqueue(waterNums[i]);
            }
            Stack<double> stack = new Stack<double>();
            double[] flourNums = Console.ReadLine().Split(" ").Select(double.Parse).ToArray();
            for (int i = 0; i < flourNums.Length; i++)
            {
                stack.Push(flourNums[i]);
            }
            while (true)
            {
                if (stack.Count == 0)
                    break;
                else if (queue.Count == 0)
                    break;
                double sumOfFlaourAndWater = queue.Peek() + stack.Peek();
                if ((queue.Peek() * 100)/sumOfFlaourAndWater == 40)
                {
                    if (!dic.ContainsKey("Muffin"))
                    {
                        dic["Muffin"] = 1;
                    }
                    else
                    {
                        dic["Muffin"]++;
                    }
                    queue.Dequeue();
                    stack.Pop();
                }
                else if ((queue.Peek() * 100) / sumOfFlaourAndWater == 30)
                {
                    if (!dic.ContainsKey("Baguette"))
                    {
                        dic["Baguette"] = 1;
                    }
                    else
                    {
                        dic["Baguette"]++;
                    }
                    queue.Dequeue();
                    stack.Pop();
                }
                else if ((queue.Peek() * 100) / sumOfFlaourAndWater == 20)
                {
                    if (!dic.ContainsKey("Bagel"))
                    {
                        dic["Bagel"] = 1;
                    }
                    else
                    {
                        dic["Bagel"]++;
                    }
                    queue.Dequeue();
                    stack.Pop();
                }
                else
                {
                    if (queue.Peek() < stack.Peek())
                    {
                        int saveForLeft = 0;
                        double stackNum = stack.Peek();
                        for (int i = 0; i < stack.Peek(); i++)
                        {
                            stackNum--;
                            saveForLeft++;
                            if (stackNum == queue.Peek())
                            {
                                if (!dic.ContainsKey("Croissant"))
                                {
                                    dic["Croissant"] = 1;
                                }
                                else
                                {
                                    dic["Croissant"]++;
                                }
                                stack.Pop();
                                stack.Push(saveForLeft);
                                queue.Dequeue();
                                break;
                            }
                        }
                    }
                    else if (queue.Peek() > stack.Peek())
                    {
                        int saveForLeft = 0;
                        double queueNum = queue.Peek();
                        for (int i = 0; i < queue.Peek(); i++)
                        {
                            queueNum--;
                            saveForLeft++;
                            if (queueNum == queue.Peek())
                            {
                                if (!dic.ContainsKey("Croissant"))
                                {
                                    dic["Croissant"] = 1;
                                }
                                else
                                {
                                    dic["Croissant"]++;
                                }
                                queue.Dequeue();
                                queue.Enqueue(saveForLeft);
                                stack.Pop();
                                break;
                            }
                        }
                    }
                    else if (queue.Peek() == stack.Peek())
                    {
                        if (!dic.ContainsKey("Croissant"))
                        {
                            dic["Croissant"] = 1;
                        }
                        else
                        {
                            dic["Croissant"]++;
                        }
                        queue.Dequeue();
                        stack.Pop();
                        
                    }
                }
            }
            
            foreach (KeyValuePair<string, int> author in dic.OrderByDescending(key => key.Value))
            {
                Console.WriteLine($"{author.Key}: {author.Value}");
            }
            if (queue.Count < 1)
            {
                Console.WriteLine("Water left: None");
            }
            else
            {
                Console.WriteLine($"Water left: {String.Join(", ", queue)}");
            }
            if (stack.Count < 1)
            {
                Console.WriteLine("Flour left: None");
            }
            else
            {
                Console.WriteLine($"Flour left: {String.Join(", ", stack)}");
            }
        }
    }
}
