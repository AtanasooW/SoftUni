﻿using System.Collections.Generic;
using System.Linq;
using System;

namespace FishingNet
{
    public class Net
    {
        public List<Fish> Fish { get; set; }
        public string Material { get; set; }
        public int Capacity { get; set; }
        public int Count => Fish.Count;


        public Net(string Material, int capasity)
        {
            this.Fish = new List<Fish>();
            this.Material = Material;
            this.Capacity = capasity;

        }

        public string Report()
        {
            return $"Into the {this.Material}:" + Environment.NewLine +
                $"{String.Join(Environment.NewLine, Fish.OrderByDescending(x => x.Length))}";

        }
        public Fish GetBiggestFish()
        {
            if (this.Fish.Count < 1)
                return null;
            else
            {
                double TheLongestFish = Fish.Max(fish => fish.Length);
                Fish TheBiggestFihs = Fish.FirstOrDefault(fish => fish.Length == TheLongestFish);
                return TheBiggestFihs;
            }
        }
        public Fish GetFish(string fishType)
        {
            if (this.Fish.Count < 1)
                return null;
            else
            {
                var fish = this.Fish.FirstOrDefault(x => x.FishType == fishType);
                if (fish == null)
                    return null;
                else if(fish.FishType == fishType)
                    return fish;
            }
            return null;
        }
        public bool ReleaseFish(double weight)
        {
            if (this.Fish.Count < 1)
                return false;
            else
            {
            var fishes = this.Fish.FirstOrDefault(e => e.Weight == weight);
            if (fishes == null)
            return false;
                else if (fishes.Weight == weight)
                {
                this.Capacity++;
                this.Fish.Remove(fishes);
                return true;
                }
                return false;
            }
        }
        public string AddFish(Fish Fish)
        {
            if (this.Capacity < 1)
            {
               return "Fishing net is full.";
            }
            else
            {
                if (string.IsNullOrWhiteSpace(Fish.FishType) || Fish.Length <= 0 || Fish.Weight <= 0)
                {
                    return "Invalid fish.";
                }
                this.Fish.Add(Fish);
                this.Capacity--;
                return $"Successfully added {Fish.FishType} to the fishing net.";

            }
            
        }
    }
}
