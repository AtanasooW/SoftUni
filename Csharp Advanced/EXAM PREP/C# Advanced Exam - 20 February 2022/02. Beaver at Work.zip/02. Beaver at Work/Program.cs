﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _02._Beaver_at_Work
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            Stack<char> stack = new Stack<char>();
            int[] cordinatesOfB = new int[2];
            int couterOfLowerCase = 0;
            char[,] matrix = new char[n, n];
            for (int rows = 0; rows < n; rows++)
            {
                string[] arry = Console.ReadLine().Split(" ");
                for (int cols = 0; cols < n; cols++)
                {
                    matrix[rows, cols] = char.Parse(arry[cols]);
                    if (matrix[rows, cols] == 'B')
                    {
                        (cordinatesOfB[0], cordinatesOfB[1]) = (rows, cols);
                    }
                    if (char.IsLower(matrix[rows, cols]))
                    {
                        couterOfLowerCase++;
                    }
                }
            }
            while (true)
            {
                if (couterOfLowerCase < 1)
                    break;
                string cmd = Console.ReadLine();
                if (cmd == "end")
                    break;

                else if (cmd == "up")
                {
                    if (cordinatesOfB[0] - 1 < 0)
                    {
                        if (stack.Count > 0)
                            stack.Pop();
                    }
                    else if (matrix[cordinatesOfB[0] - 1, cordinatesOfB[1]] == 'F')
                    {
                        if (char.IsLower(matrix[3, cordinatesOfB[1]]))
                        {
                            stack.Push(matrix[3, cordinatesOfB[1]]);
                            couterOfLowerCase--;
                        }
                        matrix[3, cordinatesOfB[1]] = 'B';
                        matrix[cordinatesOfB[0], cordinatesOfB[1]] = '-';
                        matrix[cordinatesOfB[0] - 1, cordinatesOfB[1]] = '-';
                        (cordinatesOfB[0], cordinatesOfB[1]) = (3, cordinatesOfB[1]);
                    }
                    else
                    {
                        if (char.IsLower(matrix[cordinatesOfB[0] - 1, cordinatesOfB[1]]))
                        {
                            stack.Push(matrix[cordinatesOfB[0] - 1, cordinatesOfB[1]]);
                            couterOfLowerCase--;
                        }
                        matrix[cordinatesOfB[0], cordinatesOfB[1]] = '-';
                        matrix[cordinatesOfB[0] - 1, cordinatesOfB[1]] = 'B';
                        (cordinatesOfB[0], cordinatesOfB[1]) = (cordinatesOfB[0] - 1, cordinatesOfB[1]);
                    }

                }
                else if (cmd == "right")
                {
                    if (cordinatesOfB[1] + 1 > n - 1)
                    {
                        if (stack.Count > 0)
                            stack.Pop();
                    }
                    else if (matrix[cordinatesOfB[0], cordinatesOfB[1] + 1] == 'F')
                    {
                        if (char.IsLower(matrix[cordinatesOfB[0], 0]))
                        {
                            stack.Push(matrix[cordinatesOfB[0], 0]);
                            couterOfLowerCase--;
                        }
                        matrix[cordinatesOfB[0], 0] = 'B';
                        matrix[cordinatesOfB[0], cordinatesOfB[1]] = '-';
                        matrix[cordinatesOfB[0], cordinatesOfB[1] + 1] = '-';
                        (cordinatesOfB[0], cordinatesOfB[1]) = (cordinatesOfB[0], 0);
                    }
                    else
                    {
                        if (char.IsLower(matrix[cordinatesOfB[0], cordinatesOfB[1] + 1]))
                        {
                            stack.Push(matrix[cordinatesOfB[0], cordinatesOfB[1] + 1]);
                            couterOfLowerCase--;
                        }
                        matrix[cordinatesOfB[0], cordinatesOfB[1]] = '-';
                        matrix[cordinatesOfB[0], cordinatesOfB[1] + 1] = 'B';
                        (cordinatesOfB[0], cordinatesOfB[1]) = (cordinatesOfB[0], cordinatesOfB[1] + 1);
                    }
                }
                else if (cmd == "down")
                {
                    if (cordinatesOfB[0] + 1 > n - 1)
                    {
                        if (stack.Count > 0)
                            stack.Pop();
                    }
                    else if (matrix[cordinatesOfB[0] + 1, cordinatesOfB[1]] == 'F')
                    {
                        if (char.IsLower(matrix[0, cordinatesOfB[1]]))
                        {
                            stack.Push(matrix[0, cordinatesOfB[1]]);
                            couterOfLowerCase--;
                        }
                        matrix[0, cordinatesOfB[1]] = 'B';
                        matrix[cordinatesOfB[0], cordinatesOfB[1]] = '-';
                        matrix[cordinatesOfB[0] + 1, cordinatesOfB[1]] = '-';
                        (cordinatesOfB[0], cordinatesOfB[1]) = (0, cordinatesOfB[1]);
                    }
                    else
                    {
                        if (char.IsLower(matrix[cordinatesOfB[0] + 1, cordinatesOfB[1]]))
                        {
                            stack.Push(matrix[cordinatesOfB[0] + 1, cordinatesOfB[1]]);
                            couterOfLowerCase--;
                        }
                        matrix[cordinatesOfB[0], cordinatesOfB[1]] = '-';
                        matrix[cordinatesOfB[0] + 1, cordinatesOfB[1]] = 'B';
                        (cordinatesOfB[0], cordinatesOfB[1]) = (cordinatesOfB[0] + 1, cordinatesOfB[1]);
                    }
                }
                else if (cmd == "left")
                {
                    if (cordinatesOfB[1] - 1 < 0)
                    {
                        if (stack.Count > 0)
                            stack.Pop();
                    }
                    else if (matrix[cordinatesOfB[0], cordinatesOfB[1] - 1] == 'F')
                    {
                        if (char.IsLower(matrix[cordinatesOfB[0], 3]))
                        {
                            stack.Push(matrix[cordinatesOfB[0], 3]);
                            couterOfLowerCase--;
                        }
                        matrix[cordinatesOfB[0], 3] = 'B';
                        matrix[cordinatesOfB[0], cordinatesOfB[1]] = '-';
                        matrix[cordinatesOfB[0], cordinatesOfB[1] - 1] = '-';
                        (cordinatesOfB[0], cordinatesOfB[1]) = (cordinatesOfB[0], 3);
                    }
                    else
                    {
                        if (char.IsLower(matrix[cordinatesOfB[0], cordinatesOfB[1] - 1]))
                        {
                            stack.Push(matrix[cordinatesOfB[0], cordinatesOfB[1] - 1]);
                            couterOfLowerCase--;
                        }
                        matrix[cordinatesOfB[0], cordinatesOfB[1]] = '-';
                        matrix[cordinatesOfB[0], cordinatesOfB[1] - 1] = 'B';
                        (cordinatesOfB[0], cordinatesOfB[1]) = (cordinatesOfB[0], cordinatesOfB[1] - 1);
                    }
                }
            }
            List<char> penis = new List<char>();
            foreach (var item in stack)
            {
                penis.Add(item);
            }
            penis.Reverse();
            if (couterOfLowerCase > 0)
            {
                Console.WriteLine($"The Beaver failed to collect every wood branch. There are {couterOfLowerCase} branches left.");
            }
            else
            {
                Console.WriteLine($"The Beaver successfully collect {stack.Count} wood branches: {String.Join(", ", penis)}.");
            }
            for (int i = 0; i < n; i++)
            {
                char[] charArry = new char[n];
                for (int cols = 0; cols < n; cols++)
                {

                    charArry[cols] = matrix[i,cols];
                }
                Console.WriteLine(String.Join(" ", charArry));
            }
        }
    }
}
