﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DefiningClasses
{
    public class Family
    {
        public List<Person> Members { get; set; }
        public Family()
        {
            Members = new List<Person>();
        }
        public void AddMember(string name, int age)
        {
            Members.Add(new Person(name, age));
        }
        public Person GetOldestMember()
        {
            foreach (var item in Members)
            {
                if (item.Age == Members.Max(x => x.Age))
                {
                Person OldestMember = new Person(item.Name, item.Age);
                return OldestMember;
                    
                }

            }
            return null;
        }
    }
}
