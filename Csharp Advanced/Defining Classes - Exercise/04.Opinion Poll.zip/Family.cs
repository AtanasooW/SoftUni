﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DefiningClasses
{
    public class Family
    {
        public List<Person> Members { get; set; }
        public Family()
        {
            Members = new List<Person>();
        }
        public void AddMember(string name, int age)
        {
            Members.Add(new Person(name, age));
        }
        public List<Person> GetOldestMember()
        {
            List<Person> PersonMoreThan = new List<Person>();
            foreach (var item in Members)
            {
                if (item.Age > 30)
                {
                    PersonMoreThan.Add(item);

                }

            }

            return PersonMoreThan;
        }
    }
}
