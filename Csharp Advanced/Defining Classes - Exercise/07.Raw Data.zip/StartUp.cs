﻿using System;
using System.Collections.Generic;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<Car> cars = new List<Car>();
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string[] cmd = Console.ReadLine().Split();
                var engine = new Engine(int.Parse(cmd[1]), int.Parse(cmd[2]));
                var cargo = new Cargo(int.Parse(cmd[3]), cmd[4]);
                var tyres = new List<Tires>();
                var Tire1 = new Tires(double.Parse(cmd[5 ]), int.Parse(cmd[6]));
                var Tire2 = new Tires(double.Parse(cmd[7]), int.Parse(cmd[8]));
                var Tire3 = new Tires(double.Parse(cmd[9]), int.Parse(cmd[10]));
                var Tire4 = new Tires(double.Parse(cmd[11]), int.Parse(cmd[12]));
                tyres.Add(Tire1);
                tyres.Add(Tire2);
                tyres.Add(Tire3);
                tyres.Add(Tire4);

                var car = new Car(cmd[0], engine, cargo, tyres);
                cars.Add(car);
            }
            string command = Console.ReadLine();
            bool isThereSmallTire = false;
            if (command == "fragile")
            {
                foreach (var item in cars)
                {
                    if (item.Cargo.Type == "fragile")
                    {
                        for (int i = 0; i < 4; i++)
                        {
                            if (item.Tires[i].Pressure < 1)
                            {
                                isThereSmallTire = true;
                            }

                        }
                        if (isThereSmallTire)
                        {
                            Console.WriteLine(item.Model);
                        }

                    }
                    isThereSmallTire = false;
                }
            }
            else if (command == "flammable")
            {
                foreach (var item in cars)
                {
                    if (item.Cargo.Type == "flammable")
                    {
                        if (item.Engine.Power > 250)
                        {
                            Console.WriteLine(item.Model);
                        }

                    }
                }
            }
        }
    }
}
