﻿namespace P04.WildFarm.Models.Feline
{
    public class Cat : Feline
    {
        public Cat(string name, double weight, string livinRegion, string breed) : base(name, weight, livinRegion, breed)
        {
        }
        public override string MakeASound()
        {
            return "Meow";
        }
        public override void Eat(int quantity)
        {
            Weight += 0.30 * quantity;
            FoodEaten += quantity;
        }
    }
}
