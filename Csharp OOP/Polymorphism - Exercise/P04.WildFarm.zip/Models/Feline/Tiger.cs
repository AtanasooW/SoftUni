﻿namespace P04.WildFarm.Models.Feline
{
    public class Tiger : Feline
    {
        public Tiger(string name, double weight, string livinRegion, string breed) : base(name, weight, livinRegion, breed)
        {
        }
        public override string MakeASound()
        {
            return "ROAR!!!";
        }
        public override void Eat(int quantity)
        {
            Weight += 1.0 * quantity;
            FoodEaten += quantity;
        }
    }
}
