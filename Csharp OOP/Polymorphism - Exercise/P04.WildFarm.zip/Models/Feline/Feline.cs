﻿namespace P04.WildFarm.Models.Feline
{
    using P04.WildFarm.Models.Mammal;
    using Interfaces;
    public class Feline : Mammal, IFeline
    {
        public Feline(string name, double weight, string livinRegion, string breed) : base(name, weight, livinRegion)
        {
            this.Breed = breed;
        }

        public string Breed { get; private set; }
        public override string ToString()
        {
            return $"{this.GetType().Name} [{Name}, {Breed}, {Weight}, {LivinRegion}, {FoodEaten}]";
        }
    }
}
