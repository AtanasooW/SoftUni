﻿namespace P04.WildFarm.Models.Mammal
{
    public class Dog : Mammal
    {
        public Dog(string name, double weight, string livinRegion) : base(name, weight, livinRegion)
        {
        }
        public override string MakeASound()
        {
            return "Woof!";
        }
        public override void Eat(int quantity)
        {
            Weight += 0.40 * quantity;
            FoodEaten += quantity;
        }
    }
}
