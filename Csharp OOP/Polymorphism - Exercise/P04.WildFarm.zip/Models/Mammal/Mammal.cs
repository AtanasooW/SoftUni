﻿namespace P04.WildFarm.Models.Mammal
{
    using Interfaces;
    public class Mammal : Animal, IMammal
    {
        public Mammal(string name, double weight, string livinRegion) : base(name, weight)
        {
            this.LivinRegion = livinRegion;
        }
        public string LivinRegion { get; private set; } //mammal done
        public override string ToString()
        {
            return base.ToString() + $"{ Weight}, { this.LivinRegion}, {FoodEaten}]";
        }
    }
}
