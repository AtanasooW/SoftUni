﻿namespace P04.WildFarm.Models.Mammal
{
    public class Mouse : Mammal
    {
        public Mouse(string name, double weight, string livinRegion) : base(name, weight, livinRegion)
        {
        }
        public override string MakeASound()
        {
            return "Squeak";
        }
        public override void Eat(int quantity)
        {
            Weight += 0.10 * quantity;
            FoodEaten += quantity;
        }
    }
}
