﻿namespace P04.WildFarm.Models.Interfaces
{
    public interface IFeline
    {
        public string Breed { get; }
    }
}
