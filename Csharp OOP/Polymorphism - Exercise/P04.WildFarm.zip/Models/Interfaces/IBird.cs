﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P04.WildFarm.Models.Interfaces
{
    public interface IBird
    {
        public double WingSize { get; }
    }
}
