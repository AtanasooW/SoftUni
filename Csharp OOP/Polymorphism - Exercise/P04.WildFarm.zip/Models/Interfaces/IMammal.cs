﻿namespace P04.WildFarm.Models.Interfaces
{
    public interface IMammal
    {
        public string LivinRegion { get; }
    }
}
