﻿namespace P04.WildFarm.Models.Bird
{
    public class Owl : Bird
    {
        public Owl(string name, double weight, double wingSize) : base(name, weight, wingSize)
        {
        }
        public override string MakeASound()
        {
            return "Hoot Hoot";
        }
        public override void Eat(int quantity)
        {
            Weight += 0.25 * quantity;
            FoodEaten += quantity;
        }
    }
}
