﻿namespace P04.WildFarm.Models.Bird
{
    using Interfaces;
    public class Bird : Animal, IBird
    {
        public Bird(string name, double weight, double wingSize) : base(name, weight)
        {
            this.WingSize = wingSize;
        }

        public double WingSize {get;private set;}
        public override string ToString()
        {
            return base.ToString() + $"{this.WingSize}, {Weight}, {FoodEaten}]";
        }
    }
}
