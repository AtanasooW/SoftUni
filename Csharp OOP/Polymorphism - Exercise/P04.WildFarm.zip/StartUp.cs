﻿namespace P04.WildFarm
{
    using System;
    using System.Collections.Generic;

    using Models.Interfaces;
    using Models.Feline;
    using Models.Bird;
    using Models.Mammal;

    public class StartUp
    {
        static void Main(string[] args)
        {
            List<IAnimal> list = new List<IAnimal>();
            while (true)
            {
                string[] cmd = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                if (cmd[0] == "End")
                    break;
                string[] food = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);

                if (cmd[0] == "Cat")//Feline
                {
                    IAnimal animal = new Cat(cmd[1], double.Parse(cmd[2]), cmd[3], cmd[4]);
                    list.Add(animal);
                    if (food[0] == "Meat" || food[0] == "Vegetable")
                    {
                        animal.Eat(int.Parse(food[1]));
                        Console.WriteLine(animal.MakeASound());
                    }
                    else
                    {
                        Console.WriteLine($"Cat does not eat {food[0]}!");
                    }
                }
                else if (cmd[0] == "Tiger")//Feline
                {
                    IAnimal animal = new Tiger(cmd[1], double.Parse(cmd[2]), cmd[3], cmd[4]);
                    list.Add(animal);
                    if (food[0] == "Meat")
                    {
                        animal.Eat(int.Parse(food[1]));
                        Console.WriteLine(animal.MakeASound());
                    }
                    else
                    {
                        Console.WriteLine(animal.MakeASound());
                        Console.WriteLine($"Tiger does not eat {food[0]}!");
                    }
                }
                else if (cmd[0] == "Owl")//bird
                {
                    IAnimal animal = new Owl(cmd[1], double.Parse(cmd[2]), double.Parse(cmd[3]));
                    list.Add(animal);
                    if (food[0] == "Meat")
                    {
                        animal.Eat(int.Parse(food[1]));
                        Console.WriteLine(animal.MakeASound());
                    }
                    else
                    {
                        Console.WriteLine(animal.MakeASound());
                        Console.WriteLine($"Owl does not eat {food[0]}!");
                    }
                }
                else if (cmd[0] == "Hen")//bird
                {
                    IAnimal animal = new Hen(cmd[1], double.Parse(cmd[2]), double.Parse(cmd[3]));
                    list.Add(animal);
                    if (food[0] == "Vegetable" || food[0] == "Fruit" || food[0] == "Meat" || food[0] == "Seeds")
                    {

                    animal.Eat(int.Parse(food[1]));
                    Console.WriteLine(animal.MakeASound());
                    }
                    else
                    {
                        Console.WriteLine(animal.MakeASound());
                        Console.WriteLine($"Hen does not eat {food[0]}!");
                    }

                }
                else if (cmd[0] == "Mouse")//mammal
                {
                    IAnimal animal = new Mouse(cmd[1], double.Parse(cmd[2]), cmd[3]);
                    list.Add(animal);
                    if (food[0] == "Vegetable" || food[0] == "Fruit")
                    {
                        animal.Eat(int.Parse(food[1]));
                        Console.WriteLine(animal.MakeASound());
                    }
                    else
                    {
                        Console.WriteLine(animal.MakeASound());
                        Console.WriteLine($"Mouse does not eat {food[0]}!");
                    }
                }
                else if (cmd[0] == "Dog")//mammal
                {
                    IAnimal animal = new Dog(cmd[1], double.Parse(cmd[2]), cmd[3]);
                    list.Add(animal);
                    if (food[0] == "Meat")
                    {
                        animal.Eat(int.Parse(food[1]));
                        Console.WriteLine(animal.MakeASound());
                    }
                    else
                    {
                        Console.WriteLine(animal.MakeASound());
                        Console.WriteLine($"Dog does not eat {food[0]}!");
                    }
                }
            }
            foreach (var item in list)
            {
                Console.WriteLine(item.ToString());
            }
        }
    }
}
