﻿namespace P03.Raiding.Core.Interfaces
{
    public interface IEngine
    {
        void Start();
    }
}
