﻿namespace P03.Raiding.Core
{
    using System;
    using System.Collections.Generic;

    using Models;
    using Interfaces;
    using System.Linq;

    public class Engine : IEngine
    {
        private BaseHero druid;
        private BaseHero paladin;
        private BaseHero rogue;
        private BaseHero warrior;
        private List<BaseHero> list;

        public Engine()
        {
            this.list = new List<BaseHero>();
        }

        public void Start()
        {
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string name = Console.ReadLine();
                string type = Console.ReadLine();
                if (type.ToLower() == "druid")
                {
                    this.druid = new Druid(name);
                    this.list.Add(this.druid);
                   
                }
                else if (type.ToLower() == "paladin")
                {
                    this.paladin = new Paladin(name);
                    this.list.Add(this.paladin);
                }
                else if (type.ToLower() == "rogue") //D rock
                {
                    this.rogue = new Rogue(name);
                    this.list.Add(this.rogue);
                }
                else if (type.ToLower() == "warrior")
                {
                    this.warrior = new Warrior(name);
                    this.list.Add(this.warrior);
                }
                else
                {
                    Console.WriteLine("Invalid hero!");
                    i--;
                }
            }
            foreach (var item in list)
            {
                Console.WriteLine(item.CastAbility());
            }
            long powerOfTheBoss = long.Parse(Console.ReadLine());
            long sum = list.Select(x => x.Power).Sum();
            if (sum >= powerOfTheBoss)
            {
                Console.WriteLine("Victory!");
            }
            else
            {
                Console.WriteLine("Defeat...");
            }

        }
    }
}
