﻿namespace P03.Raiding.Models
{
    public class Druid : BaseHero
    {
        private const int powerForTheDruid = 80;
        public Druid(string name) : base(name, powerForTheDruid)
        {
        }
        public override string CastAbility()
        {
            return base.CastAbility() + $"healed for {powerForTheDruid}";
        }
    }
}
