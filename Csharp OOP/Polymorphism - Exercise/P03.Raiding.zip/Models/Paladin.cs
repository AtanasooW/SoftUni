﻿namespace P03.Raiding.Models
{
    public class Paladin : BaseHero
    {
        private const int powerForThePaladin = 100;
        public Paladin(string name) : base(name, powerForThePaladin)
        {
        }
        public override string CastAbility()
        {
            return base.CastAbility() + $"healed for {powerForThePaladin}";
        }
    }
}
