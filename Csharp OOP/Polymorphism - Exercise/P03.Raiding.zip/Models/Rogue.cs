﻿namespace P03.Raiding.Models
{
    public class Rogue : BaseHero
    {
        private const int powerForTheRogue = 80;
        public Rogue(string name) : base(name, powerForTheRogue)
        {
        }
        public override string CastAbility()
        {
            return base.CastAbility() + $"hit for {powerForTheRogue} damage";
        }
    }
}
