﻿namespace P03.Raiding.Models
{
    public class Warrior : BaseHero
    {
        private const int powerForTheWarrior = 100;
        public Warrior(string name) : base(name, powerForTheWarrior)
        {
        }
        public override string CastAbility()
        {
            return base.CastAbility() + $"hit for {powerForTheWarrior} damage";
        }
    }
}
