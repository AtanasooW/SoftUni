﻿
namespace P01.Vehicles.Core.Interfaces
{
using System;
using System.Collections.Generic;
using System.Text;
    public interface IEngine
    {
        void Start();
    }
}
