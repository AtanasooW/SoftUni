﻿
namespace P01.Vehicles.Core
{
    using System;
    using Vehicles.Models;
    using Interfaces;
    public class Engine : IEngine
    {
        private Vehicle car;
        private Vehicle truck;
        private Bus bus;

        public Engine(Vehicle car, Vehicle truck, Bus bus)
        {
            this.car = car;
            this.truck = truck;
            this.bus = bus;
        }

        public void Start()
        {
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string[] cmd = Console.ReadLine().Split();
                try
                {
                    if (cmd[0] == "Drive")
                    {
                        if (cmd[1] == "Car")
                        {
                            Console.WriteLine(car.Drive(double.Parse(cmd[2])));
                        }
                        else if (cmd[1] == "Truck")
                        {
                            Console.WriteLine(truck.Drive(double.Parse(cmd[2])));
                        }
                        else if (cmd[1] == "Bus")
                        {
                            Console.WriteLine(bus.Drive(double.Parse(cmd[2])));
                        }
                    }
                    else if (cmd[0] == "Refuel")
                    {
                        if (cmd[1] == "Car")
                        {
                            car.Refuel(double.Parse(cmd[2]));
                        }
                        else if (cmd[1] == "Truck")
                        {
                            truck.Refuel(double.Parse(cmd[2]));
                        }
                        else if (cmd[1] == "Bus")
                        {
                            bus.Refuel(double.Parse(cmd[2]));
                        }
                    }
                    else if (cmd[0] == "DriveEmpty")
                    {
                        if (cmd[1] == "Bus")
                        {

                            Console.WriteLine(bus.DriveEmpty(double.Parse(cmd[2])));
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                   
                }
            }
            Console.WriteLine(car.ToString());
            //Console.WriteLine($"Truck: {Math.Round(truck.FuelQuantity, 2, MidpointRounding.AwayFromZero)}");
            Console.WriteLine(truck.ToString());
            Console.WriteLine(bus.ToString());
        }
    }
}
