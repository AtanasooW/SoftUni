﻿namespace P01.Vehicles.Models.Interfaces
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    public interface IVehicle
    {
        public double FuelQuantity { get; }
        public double FuelConsumption { get; }
        public double TankCapacity { get; }
        public string Drive(double kmToDrive);
        public void Refuel(double litters);
    }
}
