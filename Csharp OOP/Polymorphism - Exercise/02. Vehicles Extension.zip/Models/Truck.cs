﻿namespace P01.Vehicles.Models
{
    public class Truck : Vehicle
    {
        private const double tankCanStore = 0.05;
        private const double addConsumption = 1.6;
        public Truck(double fuelQuantity, double fuelConsumption, double TankCapacity) : base(fuelQuantity,fuelConsumption + addConsumption, TankCapacity)
        {
        }
        public override void Refuel(double litters)
        {
            base.Refuel(litters);
            FuelQuantity -= litters * tankCanStore;
        }
    }
}
