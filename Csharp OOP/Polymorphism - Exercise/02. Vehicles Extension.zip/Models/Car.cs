﻿
namespace P01.Vehicles.Models
{
    public class Car : Vehicle
    {
        private const double addConsumption = 0.9;
        public Car(double fuelQuantity, double fuelConsumption, double TankCapacity) : base(fuelQuantity, fuelConsumption + addConsumption, TankCapacity)
        {
        }
    }
}
