﻿
namespace P01.Vehicles.Models
{
    using System;
    using Interfaces;

    public class Vehicle : IVehicle
    {
        private double fuelQuantity;
        private double fuelConsumption;
        private double tankCapacity;

        public Vehicle(double fuelQuantity, double fuelConsumption, double tankCapacity)
        {
            this.TankCapacity = tankCapacity;
            this.FuelQuantity = fuelQuantity;
            this.FuelConsumption = fuelConsumption;
        }

        public double TankCapacity
        {
            get
            {
                return this.tankCapacity;
            }
            protected set
            {
                this.tankCapacity = value;
            }
        }
        public double FuelQuantity
        {
            get => fuelQuantity;

            set
            {
                if (value > TankCapacity)
                {
                    fuelQuantity = 0;
                }
                else
                {
                    fuelQuantity = value;
                }
            }
        }
        public double FuelConsumption
        {
            get
            {
                return this.fuelConsumption;
            }
            protected set
            {
                this.fuelConsumption = value;
            }
        }


        public virtual string Drive(double kmToDrive)
        {
            double liters = kmToDrive * this.FuelConsumption;
            if (liters > this.FuelQuantity)
            {
                return $"{this.GetType().Name} needs refueling";
            }
            this.FuelQuantity -= liters;
            return $"{this.GetType().Name} travelled {kmToDrive} km";
        }

        public virtual void Refuel(double litters)
        {

            if (litters < 1)
            {
                throw new Exception("Fuel must be a positive number");
            }
            else if (this.TankCapacity < litters + this.FuelQuantity)
            {
                throw new Exception($"Cannot fit {litters} fuel in the tank");
            }
            this.fuelQuantity += litters;
        }
        public override string ToString()
        {
            return $"{this.GetType().Name}: {this.FuelQuantity:F2}";
        }
    }
}
