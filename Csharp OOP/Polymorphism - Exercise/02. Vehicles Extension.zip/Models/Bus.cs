﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01.Vehicles.Models
{
    public class Bus : Vehicle
    {
        private const double addConsumation = 1.4;
        public Bus(double fuelQuantity, double fuelConsumption, double TankCapacity) : base(fuelQuantity, fuelConsumption, TankCapacity)
        {
        }
        public override string Drive(double distance)
        {
            double fuelNeed = distance * (FuelConsumption + addConsumation);
            return CalculateQuantity(distance, fuelNeed);
        }

        public string DriveEmpty(double distance)
        {
            double fuelNeed = distance * FuelConsumption;
            return CalculateQuantity(distance, fuelNeed);
        }

        private string CalculateQuantity(double distance, double fuelNeed)
        {
            if (FuelQuantity >= fuelNeed)
            {
                FuelQuantity -= fuelNeed;

                return $"Bus travelled {distance} km";
            }
            else
            {
                return "Bus needs refueling";
            }
        }
    }
}
