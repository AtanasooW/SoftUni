﻿
namespace P01.Vehicles.Models
{
using Interfaces;
    public class Vehicle : IVehicle
    {
        public Vehicle(double fuelQuantity, double fuelConsumption)
        {
            this.FuelQuantity = fuelQuantity;
            this.FuelConsumption = fuelConsumption;
        }

        public double FuelQuantity { get; private set;}

        public double FuelConsumption { get; private set; }

        public string Drive(double kmToDrive)
        {
            double liters = kmToDrive * this.FuelConsumption;
            if (liters > this.FuelQuantity)
            {
                return $"{this.GetType().Name} needs refueling";
            }
            this.FuelQuantity -= liters;
            return $"{this.GetType().Name} travelled {kmToDrive} km";
        }

        public virtual void Refuel(double litters)
        {
            this.FuelQuantity += litters;
        }
    }
}
