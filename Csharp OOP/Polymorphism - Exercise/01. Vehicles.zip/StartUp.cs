﻿namespace P01.Vehicles
{
    using System;
    using P01.Vehicles.Models;
    using Core;
    public class StartUp
    {
        static void Main(string[] args)
        {
            string[] inputForCar = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            string[] inputForTruck = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            Vehicle car = VehicleFactory(inputForCar);
            Vehicle truck = VehicleFactory(inputForTruck);
            Engine engine = new Engine(car, truck);
            engine.Start();
        }

        private static Vehicle VehicleFactory(string[] inputForVehicle)
        {
            if (inputForVehicle[0] == "Car")
            {
                Vehicle car = new Car(double.Parse(inputForVehicle[1]), double.Parse(inputForVehicle[2]));
                return car;
            }
            else if (inputForVehicle[0] == "Truck")
            {
                Vehicle truck = new Truck(double.Parse(inputForVehicle[1]), double.Parse(inputForVehicle[2]));
                return truck;
            }
            return null;
        }
    }
}
