﻿
namespace P01.Vehicles.Core
{
    using System;
    using Vehicles.Models;
    using Interfaces;
    public class Engine : IEngine
    {
        private Vehicle car;
        private Vehicle truck;

        public Engine(Vehicle car, Vehicle truck)
        {
            this.car = car;
            this.truck = truck;
        }

        public void Start()
        {
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string[] cmd = Console.ReadLine().Split();
                if (cmd[0] == "Drive")
                {
                    if (cmd[1] == "Car")
                    {
                        Console.WriteLine(car.Drive(double.Parse(cmd[2])));
                    }
                    else if (cmd[1] == "Truck")
                    {
                        Console.WriteLine(truck.Drive(double.Parse(cmd[2])));
                    }
                }
                else if (cmd[0] == "Refuel")
                {
                    if (cmd[1] == "Car")
                    {
                        car.Refuel(double.Parse(cmd[2]));
                    }
                    else if (cmd[1] == "Truck")
                    {
                        truck.Refuel(double.Parse(cmd[2]));
                    }
                }
            }
            Console.WriteLine($"Car: {car.FuelQuantity:F2}");
            //Console.WriteLine($"Truck: {Math.Round(truck.FuelQuantity, 2, MidpointRounding.AwayFromZero)}");
            Console.WriteLine($"Truck: {truck.FuelQuantity:F2}");
        }
    }
}
