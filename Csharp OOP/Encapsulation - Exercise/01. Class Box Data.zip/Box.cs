﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassBoxData
{
    public class Box
    {
        private const double MinValueForTheProps = 0;
        private const string ErrorCommand = "{0} cannot be zero or negative.";
        private double lenght;
        private double width;
        private double height;

        public Box(double length, double width, double height)
        {
            this.Length = length;
            this.Width = width;
            this.Height = height;
        }

        public double Length
        {
            get
            {
                return lenght;
            }
            private set
            {
                if (value <= MinValueForTheProps)
                {
                    throw new ArgumentException(String.Format(ErrorCommand, nameof(this.Length)));
                }
                lenght = value;
            }
        }
        public double Width
        {
            get
            {
                return width;
            }
            private set
            {
                if (value <= MinValueForTheProps)
                {
                    throw new ArgumentException(String.Format(ErrorCommand, nameof(this.Width)));
                }
                width = value;
            }
        }
        public double Height
        {
            get
            {
                return height;
            }
            private set
            {
                if (value <= MinValueForTheProps)
                {
                    throw new ArgumentException(String.Format(ErrorCommand, nameof(this.Height)));
                }
                height = value;
            }
        }
        public double SurfaceArea()
         => 2 * (this.Length * this.Width) + 2 * (this.Length * this.Height) + 2 * (this.Height * this.Width);
        public double LateralSurfaceArea()
            => (2 * this.Height) *(this.Length + this.Width);
        public double Volume()
            => this.Length * this.Width * this.Height;
        public override string ToString()
        {
            return $"Surface Area - {SurfaceArea():F2}" + Environment.NewLine +
                $"Lateral Surface Area - {LateralSurfaceArea():F2}" + Environment.NewLine +
                $"Volume - {Volume():F2}";
        }
    }
}
