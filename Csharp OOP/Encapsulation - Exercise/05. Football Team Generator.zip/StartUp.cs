﻿using System;
using System.Collections.Generic;

namespace P05.FootballTeamGenerator
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<Team> teams = new List<Team>();

            while (true)
            {
                string[] cmd = Console.ReadLine().Split(";");
                try
                {
                    if (cmd[0] == "END")
                        break;
                    else if (cmd[0] == "Team")
                    {
                        var team = new Team(cmd[1]);
                        teams.Add(team);
                    }
                    else if (cmd[0] == "Add")
                    {
                        bool isItHere = false;
                        foreach (var item in teams)
                        {
                            if (item.Name == cmd[1])
                            {
                                isItHere = true;
                            }
                        }
                        if (isItHere)
                        {
                            string name = cmd[2];//Endurance};{Sprint};{Dribble};{Passing};{Shooting}" 
                            int endurance = int.Parse(cmd[3]);
                            int sprint = int.Parse(cmd[4]);
                            int dribble = int.Parse(cmd[5]);
                            int passing = int.Parse(cmd[6]);
                            int shooting = int.Parse(cmd[7]);
                            var player = MakeThePlayer(name, endurance, sprint, dribble, passing, shooting);
                            foreach (var item in teams)
                            {
                                if (item.Name == cmd[1])
                                {
                                    item.AddPlayer(player);
                                }
                            }
                        }
                        else
                        {
                            throw new ArgumentException(String.Format(ErrorMassages.TeamDoesNotExist, cmd[1]));
                        }
                    }
                    else if (cmd[0] == "Remove")
                    {
                        bool isItHere = false;
                        foreach (var item in teams)
                        {
                            if (item.Name == cmd[1])
                            {
                                isItHere = true;
                            }
                        }
                        if (isItHere)
                        {
                            foreach (var item in teams)
                            {
                                if (item.Name == cmd[1])
                                {
                                    item.RemovePlayer(cmd[2]);
                                }
                            }
                        }
                        else
                        {
                            throw new ArgumentException(String.Format(ErrorMassages.TeamDoesNotExist, cmd[1]));
                        }
                    }
                    else if (cmd[0] == "Rating")
                    {
                        bool isItHere = false;
                        foreach (var item in teams)
                        {
                            if (item.Name == cmd[1])
                            {
                                isItHere = true;
                            }
                        }
                        if (isItHere)
                        {
                            foreach (var item in teams)
                            {
                                if (item.Name == cmd[1])
                                {
                                    Console.WriteLine($"{cmd[1]} - " + item.Rating());
                                }
                            }
                        }
                        else
                        {
                            throw new ArgumentException(String.Format(ErrorMassages.TeamDoesNotExist, cmd[1]));
                        }
                    }
                }
                catch (Exception ae)
                {

                    Console.WriteLine(ae.Message);
                }
            }
        }

        private static Player MakeThePlayer(string name, int endurance, int sprint, int dribble, int passing, int shooting)
        {
            var stats = new Stats(endurance, sprint, dribble, passing, shooting);
            var player = new Player(name, stats);
            return player;
        }
    }
}
