﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace P05.FootballTeamGenerator
{
    public class Team
    {
        private readonly List<Player> players;
        private string name;
        private Team()
        {
            players = new List<Player>();
        }
        public Team(string name) :this()
        {
           this.Name = name;
        }

        public string Name
        {
            get
            {
                return this.name;
            }
            private set
            {
                if (String.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException(String.Format(ErrorMassages.PlayerNameIsEmptyOrNull));
                }
                this.name = value;
            }
        }
        public int Rating()
        {
            if (players.Count < 1)
            {
                return 0;
            }
            return (int)Math.Round(this.players.Average(p => p.Stats.GetTheOverallSkillLevel()), 0);
        }
        public void AddPlayer(Player player)
        {
           this.players.Add(player);
        }
        public void RemovePlayer(string playerName)
        {
            Player playerToFind = this.players.FirstOrDefault(p => p.Name == playerName);
            if (playerToFind == null)
            {
                throw new ArgumentException(String.Format(ErrorMassages.PlayerIsNotInTheTeam, playerName, this.Name));
            }
            this.players.Remove(playerToFind);
        }
            
    }
}
