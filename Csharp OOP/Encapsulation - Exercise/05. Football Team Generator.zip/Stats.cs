﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P05.FootballTeamGenerator
{
    public class Stats
    {
        private const int MinValueOfTheStats = 0;
        private const int MaxValueOfTheStats = 100;

        //endurance, sprint, dribble, passing, and shooting
        private int endurance;
        private int sprint;
        private int dribble;
        private int passing;
        private int shooting;

        public Stats(int endurance, int sprint, int dribble, int passing, int shooting)
        {
            this.Endurance = endurance;
            this.Sprint = sprint;
            this.Dribble = dribble;
            this.Passing = passing;
            this.Shooting = shooting;
        }

        public int Endurance
        {
            get
            {
                return endurance;
            }
            private set
            {
                if (value < MinValueOfTheStats || value > MaxValueOfTheStats)
                {
                    throw new ArgumentException(String.Format(ErrorMassages.StatOutOfRange, nameof(this.Endurance)));
                }
                endurance = value;
            }
        }
        public int Sprint
        {
            get
            {
                return sprint;
            }
            private set
            {
                if (value < MinValueOfTheStats || value > MaxValueOfTheStats)
                {
                    throw new ArgumentException(String.Format(ErrorMassages.StatOutOfRange, nameof(this.Sprint)));
                }
                this.sprint = value;
            }
        }
        public int Dribble
        {
            get
            {
                return dribble;
            }
            private set
            {
                if (value < MinValueOfTheStats || value > MaxValueOfTheStats)
                {
                    throw new ArgumentException(String.Format(ErrorMassages.StatOutOfRange, nameof(this.Dribble)));
                }
                this.dribble = value;
            }
        }
        public int Passing
        {
            get
            {
                return passing;
            }
            private set
            {
                if (value < MinValueOfTheStats || value > MaxValueOfTheStats)
                {
                    throw new ArgumentException(String.Format(ErrorMassages.StatOutOfRange, nameof(this.Passing)));
                }
                this.passing = value;
            }
        }
        public int Shooting
        {
            get
            {
                return shooting;
            }
            private set
            {
                if (value < MinValueOfTheStats || value > MaxValueOfTheStats)
                {
                    throw new ArgumentException(String.Format(ErrorMassages.StatOutOfRange, nameof(this.Shooting)));
                }
                this.shooting = value;
            }
        }
        public double GetTheOverallSkillLevel()
            => (this.Endurance + this.Sprint + this.Dribble + this.Passing + this.Shooting) / 5.0;
    }
}
