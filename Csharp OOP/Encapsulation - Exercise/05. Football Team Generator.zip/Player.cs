﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P05.FootballTeamGenerator
{
    public class Player
    {
        private string name;
        public Stats Stats { get; set; }

        public Player(string name, Stats stats)
        {
            this.Name = name;
            this.Stats = stats;
        }

        public string Name
        {
            get
            {
                return name;
            }
            private set
            {
                if (String.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException(String.Format(ErrorMassages.PlayerNameIsEmptyOrNull));
                }
                this.name = value;
            }
        }

    }
}
