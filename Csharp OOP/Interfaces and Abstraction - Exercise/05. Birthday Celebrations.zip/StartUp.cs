﻿using System;
using System.Collections.Generic;

namespace BirthdayCelebrations
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<IBirthdate> list = new List<IBirthdate>();
            while (true)
            {
                string[] cmd = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                IBirthdate birthdate;
                if (cmd[0] == "End")
                    break;
                else if (cmd[0] == "Pet")
                {
                    birthdate = new Pet(cmd[1], cmd[2]);
                    list.Add(birthdate);
                }
                else if (cmd[0] == "Citizen")
                {
                    birthdate = new Citizen(cmd[1], int.Parse(cmd[2]), cmd[3], cmd[4]);
                    list.Add(birthdate);
                }
            }
            string year = Console.ReadLine();
           // bool isThereOne = false;
            foreach (var item in list)
            {
                if (item.BirthDate.EndsWith(year))
                {
                    Console.WriteLine(item.BirthDate);
                    //isThereOne = true;
                }
            }
            //if (!isThereOne)
            //{
            //    Console.WriteLine();
            //}
        }
    }
}
