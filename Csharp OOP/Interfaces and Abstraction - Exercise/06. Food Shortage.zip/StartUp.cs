﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace FoodShortage
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<IBuyer> buyers = new List<IBuyer>();
            IBuyer buyer;
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                string[] cmd = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                bool isItHere = false;
                foreach (var item in buyers)
                {
                    if (item.Name == cmd[0])
                    {
                        isItHere = true;
                    }
                }
                if (!isItHere)
                {
                    if (cmd[2].Any(x => Char.IsDigit(x)))
                    {
                        buyer = new Citizen(cmd[0], int.Parse(cmd[1]), cmd[2], cmd[3]);
                        buyers.Add(buyer);
                    }
                    else
                    {
                        buyer = new Rebel(cmd[0], int.Parse(cmd[1]), cmd[2]);
                        buyers.Add(buyer);
                    }
                }
            }
            while (true)
            {
                string[] cmd = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                if (cmd[0] == "End")
                    break;

                foreach (var item in buyers)
                {
                    if (item.Name == cmd[0])
                    {
                        item.BuyFood();
                    }
                }
            }
            int sum = 0;
            foreach (var item in buyers)
            {
                sum += item.Food;
            }
            Console.WriteLine(sum);
        }
    }
}
