﻿using System;
using System.Collections.Generic;

namespace BorderControl
{
    internal class StartUp
    {
        static void Main(string[] args)
        {
            List<IhasId> list = new List<IhasId>();
            while (true)
            {
                string[] cmd = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                IhasId hasId;
                if (cmd[0] == "End")
                    break;
                else if (cmd[1].Length > 3)
                {
                    hasId = new Robot(cmd[0], cmd[1]);
                    list.Add(hasId);
                }
                else
                {
                    hasId = new Citizen(cmd[0], int.Parse(cmd[1]), cmd[2]);
                    list.Add(hasId);
                }
            }
            string endOfFakes = Console.ReadLine();
            foreach (var item in list)
            {
                if (item.Id.EndsWith(endOfFakes))
                {
                    Console.WriteLine(item.Id);
                }
            }
        }
    }
}
