﻿using System;

namespace Telephony
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string[] numbers = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            string[] urls = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            ICallable callable;
            foreach (var item in numbers)
            {
                if (item.Length == 10)
                {
                    callable = new Smartphone();
                    Console.WriteLine(callable.Call(item));
                }
                else if (item.Length == 7)
                {
                    callable = new StationaryPhone();
                    Console.WriteLine(callable.Call(item)); 
                }
                else
                {
                    Console.WriteLine("Invalid number!");
                }
            }
            IBrowseable browseable;
            foreach (var item in urls)
            {
                browseable = new Smartphone();
                Console.WriteLine(browseable.BrowseURL(item));
            }
        }
    }
}
