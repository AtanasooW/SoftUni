﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Telephony
{
    public class Smartphone : ICallable, IBrowseable
    {

        public string BrowseURL(string url)
        {
            if (url.Any(x => Char.IsDigit(x)))
            {
                return "Invalid URL!";
            }
            return $"Browsing: {url}!";
        }

        public string Call(string number)
        {
            if (number.Any(x => !Char.IsDigit(x)))
            {
                return "Invalid number!";
            }
            return $"Calling... {number}";
        }
    }
}
