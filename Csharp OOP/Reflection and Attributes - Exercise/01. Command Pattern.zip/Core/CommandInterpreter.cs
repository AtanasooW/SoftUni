﻿namespace CommandPattern.Core
{
    using System;
    using System.Linq;
    using System.Reflection;
    using Contracts;
    public class CommandInterpreter : ICommandInterpreter
    {
        public string Read(string args)
        {
            string[] cmd = args.Split();
            string typeName = cmd[0];
            string[] argumets = cmd.Skip(1).ToArray();
            Assembly assembly = Assembly.GetCallingAssembly();
            Type type = assembly.GetTypes().FirstOrDefault(a => a.Name == $"{typeName}Command" &&
            a.GetInterfaces().Any(i => i == typeof(ICommand)));

            if (type == null)
            {
                 return "Invalid type";
            }
            object instanse = Activator.CreateInstance(type);

            MethodInfo executeMethod = type.GetMethods().First(m => m.Name == "Execute");

            string output = executeMethod.Invoke(instanse, new object[] { argumets}) as string;
            return output;
        }
    }
}
