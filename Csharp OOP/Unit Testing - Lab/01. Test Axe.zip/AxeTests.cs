using NUnit.Framework;
using System;

namespace Skeleton.Tests
{
    [TestFixture]
    public class AxeTests
    {
        [Test]
        public void LoosesDurabilityAfterAttack()
        {
            Axe axe = new Axe(10, 10);
            var dummy = new Dummy(10, 10);
            axe.Attack(dummy);
            Assert.That(axe.DurabilityPoints, Is.EqualTo(9));
        }
        [Test]
        public void attackingWithABrokenAxe()
        {
            Assert.That(() =>
            {
                var axe = new Axe(1, 2);
                var dummy = new Dummy(3, 2);
                axe.Attack(dummy);
                axe.Attack(dummy);
                axe.Attack(dummy);
            },
            Throws.Exception.TypeOf<InvalidOperationException>(),
            "Axe is broken.");
            
        }
    }
}