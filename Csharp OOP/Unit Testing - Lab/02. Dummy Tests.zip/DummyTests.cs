﻿using NUnit.Framework;
using System;

namespace Skeleton.Tests
{
    [TestFixture]
    public class DummyTests
    {
        [Test]
        public void LoosesHealth_ShoudBeTrue()
        {
            var axe = new Axe(1, 10);
            var dummy = new Dummy(10, 10);
            axe.Attack(dummy);
            Assert.That(dummy.Health, Is.EqualTo(9));
        }
        [Test]
        public void DeadAndThrowsEx_ShoudBeTrue()
        {
            Assert.That(() =>
            {

                var axe = new Axe(10, 10);
                var dummy = new Dummy(10, 10);
                axe.Attack(dummy);
                axe.Attack(dummy);
            },
            Throws.Exception.TypeOf<InvalidOperationException>(),
            "Dummy is dead.");
        }
        [Test]
        public void DeadAndGiveXP_ShoudBeTrue()
        {
            var axe = new Axe(10, 10);
            var dummy = new Dummy(10, 10);
            axe.Attack(dummy);
            Assert.That(10, Is.EqualTo(dummy.GiveExperience()));
        }
        [Test]
        public void AliveCantDropXP_ShoudThrowEx()
        {
            Assert.That(() =>
            {
                var axe = new Axe(10, 10);
                var dummy = new Dummy(10, 10);
                dummy.GiveExperience();

            }, Throws.Exception.TypeOf<InvalidOperationException>(),
            "Target is not dead.");
        }
    }
}