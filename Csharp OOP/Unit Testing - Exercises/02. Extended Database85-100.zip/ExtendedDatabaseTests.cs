namespace DatabaseExtended.Tests
{
    using ExtendedDatabase;
    using NUnit.Framework;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;

    [TestFixture]
    public class ExtendedDatabaseTests
    {
        private Database database;
        private Person[] people;
        [SetUp]
        public void StartUp()
        {
            Person[] person = new Person[]
            { new Person(1,"Pesho"),
              new Person (2,"Misho"),
              new Person (3,"Gosho"),
              new Person (4,"Mimi"),
              new Person (5,"Rosana"),
              new Person(6,"Peshito"),
              new Person (7,"Mishto"),
              new Person (8,"Goshko"),
              new Person (9,"Mimito"),
              new Person (10, "Roxana"),
              new Person(11,"Pepi"),
              new Person (12,"Mishko"),
              new Person (13,"Gosheto"),
              new Person (14,"Mitko"),
              new Person (15, "Roximira"),
              new Person (16, "Nikolina"),
            };
            this.people = person;
            this.database = new Database(people);

        }
        [Test]
        public void TetsThePersonConstructorShouldWork_Successfully()
        {
            Person person = new Person(8484, "pesho");
            FieldInfo infoForId = person.GetType().GetFields(BindingFlags.Instance | BindingFlags.NonPublic)
                .First(f => f.Name == "id");
            long expectedId = (long)infoForId.GetValue(person);
            FieldInfo infoForUserName = person.GetType().GetFields(BindingFlags.Instance | BindingFlags.NonPublic)
                .First(f => f.Name == "userName");
            string expectedName = (string)infoForUserName.GetValue(person);
            Assert.That(expectedId, Is.EqualTo(8484));
            Assert.That(expectedName, Is.EqualTo("pesho"));
        }//Person

        [Test]
        public void TestPersonUserNameGetter()
        {
            Person person = new Person(8484, "pesho");
            Assert.That(person.UserName, Is.EqualTo("pesho"));
        }//Person
        [Test]
        public void TestPersonIDGetter()
        {
            Person person = new Person(8484, "pesho");
            Assert.That(person.Id, Is.EqualTo(8484));
        }//Person

        [Test]
        public void ConstructorShouldAddThePersonsToTheArray_Successfully()
        {
            Person[] people = new Person[]
             { new Person(1,"Pesho"),
              new Person (2,"Misho"),
              new Person (3,"Gosho"),
              new Person (4,"Mimi"),
              new Person (5,"Rosana"),
              new Person(6,"Peshito"),
              new Person (7,"Mishto"),
              new Person (8,"Goshko"),
              new Person (9,"Mimito"),
              new Person (10, "Roxana"),
              new Person(11,"Pepi"),
              new Person (12,"Mishko"),
              new Person (13,"Gosheto"),
              new Person (14,"Mitko"),
              new Person (15, "Roximira"),
              new Person (16, "Nikolina"),
             };
            var database = new Database(people);
            FieldInfo infoForPersons = database.GetType()
                .GetFields(BindingFlags.Instance | BindingFlags.NonPublic)
                .First(f => f.Name == "persons");
            Person[] actual = (Person[])infoForPersons.GetValue(database);
            FieldInfo infoForCount = database.GetType()
                .GetFields(BindingFlags.Instance | BindingFlags.NonPublic)
                .First(f => f.Name == "count");
            int count = (int)infoForCount.GetValue(database);
            CollectionAssert.AreEqual(actual, people);
            Assert.That(count, Is.EqualTo(people.Length));
        }

        [Test]
        public void TestDatabaseCountGetter()
        {
            Person[] people = new Person[]
             { new Person(1,"Pesho"),
              new Person (2,"Misho"),
             };
            var database = new Database(people);
            Assert.That(database.Count, Is.EqualTo(people.Length));

        }

        [Test]
        public void AddRangeShouldThrowArgumentException()
        {
            Assert.Throws<ArgumentException>(() =>
            {
                Person[] people = new Person[]
              { new Person(1,"Pesho"),
              new Person (2,"Misho"),
              new Person (3,"Gosho"),
              new Person (4,"Mimi"),
              new Person (5,"Rosana"),
              new Person(6,"Peshito"),
              new Person (7,"Mishto"),
              new Person (8,"Goshko"),
              new Person (9,"Mimito"),
              new Person (10, "Roxana"),
              new Person(11,"Pepi"),
              new Person (12,"Mishko"),
              new Person (13,"Gosheto"),
              new Person (14,"Mitko"),
              new Person (15, "Roximira"),
              new Person (16, "Nikolina"),
              new Person (17, "Vodka"),
              new Person (18, "Vladi")
              };
                var database = new Database(people);
            }, "Provided data length should be in range [0..16]!");
        }

        public void AddShouldAddPeopleToTheCollection_Successfully()
        {
            Person[] people = new Person[]
          { new Person(1,"Pesho"),
              new Person (2,"Misho"),
              new Person (3,"Gosho"),
              new Person (4,"Mimi"),
              new Person (5,"Rosana"),
              new Person(6,"Peshito"),
              new Person (7,"Mishto"),
              new Person (8,"Goshko"),
              new Person (9,"Mimito"),
              new Person (10, "Roxana"),
              new Person(11,"Pepi"),
              new Person (12,"Mishko"),
              new Person (13,"Gosheto"),
              new Person (14,"Mitko"),
              new Person (15, "Roximira"),
              new Person (16, "Nikolina"),
          };
            var database = new Database();
            foreach (var item in people)
            {
                database.Add(item);
            }
            FieldInfo infoForPersons = database.GetType()
                .GetFields(BindingFlags.Instance | BindingFlags.NonPublic)
                .First(f => f.Name == "persons");
            Person[] actual = (Person[])infoForPersons.GetValue(database);
            CollectionAssert.AreEqual(people, actual);
            Assert.That(database.Count, Is.EqualTo(people.Length));
        }

        [Test]
        public void AddShouldThrowInvalidOperationException()
        {
            Assert.Throws<InvalidOperationException>(() =>
            {
                Person[] people = new Person[]
              { new Person(1,"Pesho"),
              new Person (2,"Misho"),
              new Person (3,"Gosho"),
              new Person (4,"Mimi"),
              new Person (5,"Rosana"),
              new Person(6,"Peshito"),
              new Person (7,"Mishto"),
              new Person (8,"Goshko"),
              new Person (9,"Mimito"),
              new Person (10, "Roxana"),
              new Person(11,"Pepi"),
              new Person (12,"Mishko"),
              new Person (13,"Gosheto"),
              new Person (14,"Mitko"),
              new Person (15, "Roximira"),
              new Person (16, "Nikolina"),
              new Person (17, "Vodka"),
              new Person (18, "Vladi")
              };
                var database = new Database();
                foreach (var item in people)
                {
                    database.Add(item);
                }
            }, "Array's capacity must be exactly 16 integers!");
        }

        [Test]
        public void AddShouldThrowInvalidOperationException_TwoPeopleWithTheSameUsername()
        {
            Assert.Throws<InvalidOperationException>(() =>
            {

                Person[] people = new Person[]
                  { new Person(1,"Pesho"),
              new Person (2,"Misho"),
              new Person (3,"Gosho"),
              new Person (4,"Mimi"),
              new Person (5,"Misho"),
                  };
                var database = new Database();
                foreach (var item in people)
                {
                    database.Add(item);
                }
            }, "There is already user with this username!");
        }

        [Test]
        public void AddShouldThrowInvalidOperationException_TwoPeopleWithTheSameId()
        {
            Assert.Throws<InvalidOperationException>(() =>
            {

                Person[] people = new Person[]
                  { new Person(1,"Pesho"),
              new Person (2,"Misho"),
              new Person (3,"Gosho"),
              new Person (4,"Mimi"),
              new Person (3,"Pencho"),
                  };
                var database = new Database();
                foreach (var item in people)
                {
                    database.Add(item);
                }
            }, "There is already user with this Id!");
        }

        [Test]
        public void RemoveShouldThrowInvalidOperationException()
        {
            var database = new Database();
            Assert.Throws<InvalidOperationException>(() =>
            {
                database.Remove();
            }, "The collection is empty!");
        }


        [Test]
        public void RemoveShouldRemoveElement_Successfully()
        {
            Person[] people = new Person[]
            { new Person(1,"Pesho"),
              new Person (2,"Misho"),
              new Person (3,"Gosho"),
              new Person (4,"Mimi"),
              new Person (5,"Rosana"),
              new Person(6,"Peshito"),
              new Person (7,"Mishto"),
              new Person (8,"Goshko"),
              new Person (9,"Mimito"),
              new Person (10, "Roxana"),
              new Person(11,"Pepi"),
              new Person (12,"Mishko"),
              new Person (13,"Gosheto"),
              new Person (14,"Mitko"),
              new Person (15, "Roximira"),
              new Person (16, "Nikolina"),
            };
            var database = new Database(people);
            database.Remove();
            List<Person> exepted = people.ToList();
            exepted.RemoveAt(exepted.Count - 1);
            exepted.Add(null);
            FieldInfo infoForPersons = database.GetType()
                .GetFields(BindingFlags.Instance | BindingFlags.NonPublic)
                .First(f => f.Name == "persons");
            Person[] actual = (Person[])infoForPersons.GetValue(database);
            CollectionAssert.AreEqual(exepted, actual);
            Assert.That(database.Count, Is.EqualTo(people.Length - 1));
        }

        [Test]
        public void RemoveShouldRemoveElements_Successfully()
        {
            Person[] people = new Person[]
            { new Person(1,"Pesho"),
              new Person (2,"Misho"),
              new Person (3,"Gosho"),
              new Person (4,"Mimi"),
              new Person (5,"Rosana"),
              new Person(6,"Peshito"),
              new Person (7,"Mishto"),
              new Person (8,"Goshko"),
              new Person (9,"Mimito"),
              new Person (10, "Roxana"),
              new Person(11,"Pepi"),
              new Person (12,"Mishko"),
              new Person (13,"Gosheto"),
              new Person (14,"Mitko"),
              new Person (15, "Roximira"),
              new Person (16, "Nikolina"),
            };
            int count = people.Length;
            var database = new Database(people);
            for (int i = people.Length - 1; i >= people.Length - 4; i--)
            {
                database.Remove();
                people[i] = null;
                count--;

            }
            FieldInfo infoForPersons = database.GetType()
                .GetFields(BindingFlags.Instance | BindingFlags.NonPublic)
                .First(f => f.Name == "persons");
            Person[] actual = (Person[])infoForPersons.GetValue(database);
            CollectionAssert.AreEqual(people, actual);
            Assert.That(database.Count, Is.EqualTo(count));
        }

        [TestCase("Pesho")]
        [TestCase("Goshko")]
        [TestCase("Pepi")]
        public void SurchByUserNameShouldWork_Succesffully(string nameForSearch)
        {
            Person name = database.FindByUsername(nameForSearch);
            Person person = people.First(p => p.UserName == nameForSearch);
            Assert.AreEqual(name, person);
            Assert.That(database.Count, Is.EqualTo(people.Length));
        }

        [TestCase("")]
        [TestCase(null)]
        public void SearchByUserNameShouldThrowArgumentNullException(string nameForSearch)
        {
            Assert.Throws<ArgumentNullException>(() =>
            {
                Person name = database.FindByUsername(nameForSearch);
            }, "Username parameter is null!");

        }

        [TestCase("Vasil")]
        [TestCase("KakaRosi :) za stase")]
        public void SearchByUserNameShouldThrowInvalidOperationException(string nameForSearch)
        {
            //InvalidOperationException("No user is present by this username!"
            Assert.Throws<InvalidOperationException>(() =>
            {
                Person name = database.FindByUsername(nameForSearch);
            }, "No user is present by this username!");
        }

        [TestCase(5)]
        [TestCase(9)]
        [TestCase(10)]
        public void SurchByIDShouldWork_Succesffully(long idForSearch)
        {
            Person id = database.FindById(idForSearch);
            Person person = people.First(p => p.Id == idForSearch);
            Assert.AreEqual(id, person);
            Assert.That(database.Count, Is.EqualTo(people.Length));
        }

        [TestCase(513)]
        [TestCase(19)]
        public void SearchByIDShouldThrowInvalidOperationException(long idForSearch)
        {
            //InvalidOperationException("No user is present by this ID!");
            Assert.Throws<InvalidOperationException>(() =>
            {
                Person name = database.FindById(idForSearch);
            }, "No user is present by this ID!");
        }
        [TestCase(-1)]
        [TestCase(-20)]
        public void SearchByIdShouldThrowArgumentOutOfRangeException(long idForSearch)
        {
            Assert.Throws<ArgumentOutOfRangeException>(() =>
            {
                Person name = database.FindById(idForSearch);
            }, "Id should be a positive number!");
        }
    }
}