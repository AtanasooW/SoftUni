namespace CarManager.Tests
{
    using NUnit.Framework;
    using System;

    [TestFixture]
    public class CarManagerTests
    {
        private Car car;
        [SetUp]
        public void SetUp()
        {
            this.car = new Car("Dodge", "Charger", 0.15, 90);
        }
        [Test]
        public void TestTheConstructors()
        {
            Assert.AreEqual(("Dodge", "Charger", 0.15, 90, 0), (car.Make, car.Model, car.FuelConsumption, car.FuelCapacity, car.FuelAmount));
        }
        [Test]
        public void MakeGetter()
        {
            Assert.AreEqual("Dodge", car.Make);
        }
        [Test]
        [TestCase(null)]
        [TestCase("")]
        public void MakeSetterShouldThrowArgumentExceptionForNullValue(string make)
        {
            Assert.Throws<ArgumentException>(() =>
            {
                Car myCar = new Car(make, "Charger", 0.15, 90);
            }, "Make cannot be null or empty!");
        }
        [Test]
        public void ModelGetter()
        {
            Assert.AreEqual("Charger", car.Model);
        }
        [Test]
        [TestCase(null)]
        [TestCase("")]
        public void ModelSetterShouldThrowArgumentExceptionForNullValue(string model)
        {
            Assert.Throws<ArgumentException>(() =>
            {
                Car myCar = new Car("Dodge", model, 0.15, 90);
            }, "Model cannot be null or empty!");
        }
        [Test]
        public void FuelConsumptionGetter()
        {
            Assert.AreEqual(0.15, car.FuelConsumption);
        }
        [Test]
        [TestCase(-51)]
        [TestCase(-1)]
        [TestCase(0)]
        public void FuelCosumptionShouldThrowArgumentExceptionForNegativeValue(double consumption)
        {
            //ArgumentException("Fuel consumption cannot be zero or negative!");
            Assert.Throws<ArgumentException>(() =>
            {
                Car myCar = new Car("Dodge", "Charger", consumption, 90);
            }, "Fuel consumption cannot be zero or negative!");
        }

        [Test]
        public void FuelCapacityGetter()
        {
            Assert.AreEqual(90, car.FuelCapacity);
        }
        [Test]
        [TestCase(-51)]
        [TestCase(-1)]
        [TestCase(0)]
        public void FuelCapacityShouldThrowArgumentExceptionForNegativeValue(double capacity)
        {
            //ArgumentException("Fuel consumption cannot be zero or negative!");
            Assert.Throws<ArgumentException>(() =>
            {
                Car myCar = new Car("Dodge", "Charger", 0.15, capacity);
            }, "Fuel capacity cannot be zero or negative!");
        }

        [Test]
        [TestCase(-51)]
        [TestCase(-1)]
        [TestCase(0)]
        public void RefuelMethodShouldThrowArgumentExceptionForNegativeValue(double refuel)
        {
            //ArgumentException("Fuel consumption cannot be zero or negative!");
            Assert.Throws<ArgumentException>(() =>
            {
                Car myCar = new Car("Dodge", "Charger", 0.15, 90);
                myCar.Refuel(refuel);
            }, "Fuel amount cannot be zero or negative!");
        }
        [Test]
        [TestCase(40)]
        [TestCase(100)]
        [TestCase(1)]
        public void RefuelMethodShouldWork_Correctly(double refuel)
        {
            car.Refuel(refuel);
            if (refuel > 90)
            {
                refuel = 90;
            }
            Assert.AreEqual(refuel, car.FuelAmount);
        }
        [Test]
        public void DriveMethodShouldThrowInvalidOperationExceptionNotEnoughFuel()
        {
            Assert.Throws<InvalidOperationException>(() =>
            {
                car.Drive(500);
            }, "You don't have enough fuel to drive!");
        }
        [Test]
        public void DriveMethodShouldThrowInvalidOperationExceptionNotEnoughFuel2()
        {
            Assert.Throws<InvalidOperationException>(() =>
            {
                car.Refuel(20);
                car.Drive(20000);
            }, "You don't have enough fuel to drive!");
        }
        [Test]
        public void DriveMethodShouldWork_Correctly()
        {
            car.Refuel(120);
            car.Drive(150);
            double needed = 1.5 * 0.15;
            double expected = 90 - needed;
            Assert.AreEqual(expected, car.FuelAmount);
        }
    }
}