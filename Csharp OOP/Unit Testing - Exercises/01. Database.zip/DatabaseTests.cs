namespace Database.Tests
{
    using NUnit.Framework;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    [TestFixture]
    public class DatabaseTests
    {
        private Database data;
        [SetUp]
        public void MakeAInstance()
        {
            data = new Database();
        }

        [TestCase(new int[] {})]
        [TestCase(new int[] {1, 2, 3})]
        [TestCase(new int[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14 ,15 ,16})]
        public void ConstructorShouldWork(int[] input)
        {
            var database = new Database(input);
            int[] actualArray = database.Fetch();
            int actualCount = input.Length;
            CollectionAssert.AreEqual(input, actualArray);
            Assert.That(database.Count, Is.EqualTo(actualCount));
        }

        [TestCase(new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17})]
        [TestCase(new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20})]
        public void ConstructorShouldAddLessThan16Elements(int[] input)
        {
            Assert.Throws<InvalidOperationException>(() =>
            {
            var database = new Database(input);
            },"Array's capacity must be exactly 16 integers!");
        }

        [Test]
        public void CounthShouldReturnCorrectValue()
        {
            int[] input = new int[16] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 };
            var database = new Database(input);
            Assert.That(database.Count, Is.EqualTo(input.Length));
        }

        [TestCase(new int[] { })]
        [TestCase(new int[] { 1, 2, 3 })]
        [TestCase(new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 })]
        public void AddShouldAddElementsToData_Correct(int[] input)
        {
            foreach (var item in input)
            {
                data.Add(item);
            }
            int[] actualArray = data.Fetch();
            int actualCount = input.Length;
            CollectionAssert.AreEqual(input, actualArray);
            Assert.That(data.Count, Is.EqualTo(actualCount));
        }

        [Test]
        public void AddShouldThrowInvalidOperationException()
        {
            int[] input = new int[16] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 };
            foreach (var item in input)
            {
                data.Add(item);
            }
            Assert.Throws<InvalidOperationException>(() =>
            {
                data.Add(17);
            }, "Array's capacity must be exactly 16 integers!");
        }
        [Test]
        public void RemoveShouldRemoveElement_Correct()
        {
            int[] input = new int[16] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 };
            foreach (var item in input)
            {
                data.Add(item);
            }
            data.Remove();
            List<int> exepted = input.ToList();
            exepted.RemoveAt(exepted.Count - 1);

            CollectionAssert.AreEqual(exepted, data.Fetch());
        }

        [Test]
        public void RemoveMultipleTimesShouldRemoveElements_Correct()
        {
            int[] input = new int[16] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 };
            foreach (var item in input)
            {
                data.Add(item);
            }
            List<int> exepted = input.ToList();
            for (int i = 0; i < 3; i++)
            {
            data.Remove();
            exepted.RemoveAt(exepted.Count - 1);
            }

            CollectionAssert.AreEqual(exepted, data.Fetch());
        }

        [Test]
        public void RemoveShouldThrowInvalidOperationException()
        {
            Assert.Throws<InvalidOperationException>(() =>
            {
                data.Remove();
            }, "The collection is empty!");
        }

        [TestCase(new int[] { })]
        [TestCase(new int[] { 1, 2, 3 })]
        [TestCase(new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 })]
        public void FetchShouldWork_Correct(int[] input)
        {
            var database = new Database(input);
            int[] actualArray = database.Fetch();
            int actualCount = input.Length;
            CollectionAssert.AreEqual(input, actualArray);
            Assert.That(database.Count, Is.EqualTo(actualCount));
        }
    }
}
