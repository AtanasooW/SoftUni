namespace FightingArena.Tests
{
    using NUnit.Framework;
    using System;

    [TestFixture]
    public class WarriorTests
    {
        private Warrior warrior;
        [SetUp]
        public void SetUp()
        {
            warrior = new Warrior("Pesho", 10, 100);
        }
        [Test]
        public void TestTheConstructor()
        {
            var warrior = new Warrior("gosho", 12, 120);
            Assert.AreEqual(("gosho", 12, 120), (warrior.Name, warrior.Damage, warrior.HP));
        }
        [Test]
        public void NameGetter()
        {
            Assert.AreEqual("Pesho", warrior.Name);
        }
        [Test]
        [TestCase(null)]
        [TestCase("")]
        [TestCase("      ")]
        public void NameSetterShouldThrowsArgumentExceptionsForInvalidName(string name)
        {//ArgumentException("Name should not be empty or whitespace!");
            Assert.Throws<ArgumentException>(() =>
            {
                var warrior = new Warrior(name, 10, 100);
            }, "Name should not be empty or whitespace!");
        }     
        [Test]
        public void DamageGetter()
        {
            Assert.AreEqual(10, warrior.Damage);
        }
        [Test]
        [TestCase(0)]
        [TestCase(-1)]
        [TestCase(-50)]
        public void DamageSetterShouldThrowsArgumentExceptionsForNegativeValue(int damage)
        {//ArgumentException("Damage value should be positive!");
            Assert.Throws<ArgumentException>(() =>
            {
                var warrior = new Warrior("Pesho", damage, 100);
            }, "Damage value should be positive!");
        }  
        [Test]
        public void HPGetter()
        {
            Assert.AreEqual(100, warrior.HP);
        }
        [Test]
        [TestCase(-12)]
        [TestCase(-1)]
        [TestCase(-50)]
        public void HpSetterShouldThrowsArgumentExceptionsForNegativeValue(int HP)
        {//ArgumentException("HP should not be negative!");
            Assert.Throws<ArgumentException>(() =>
            {
                var warrior = new Warrior("Pesho", 10, HP);
            }, "HP should not be negative!");
        }

        [Test]
        [TestCase(30)]
        [TestCase(1)]
        [TestCase(0)]
        public void AttackerHPIsTooLowToAttack(int HP)
        {
            //InvalidOperationException("Your HP is too low in order to attack other warriors!"
            Assert.Throws<InvalidOperationException>(() =>
            {
                var warrior = new Warrior("Pesho", 10, HP);
                var warriorG = new Warrior("Gosho", 12, 100);
                warrior.Attack(warriorG);
            }, "Your HP is too low in order to attack other warriors!");
        }       
        [Test]
        [TestCase(30)]
        [TestCase(1)]
        [TestCase(0)]
        public void AttackedEnemyHPIsTooLowToDefence(int HP)
        {
            //InvalidOperationException("Your HP is too low in order to attack other warriors!"
            Assert.Throws<InvalidOperationException>(() =>
            {
                var warrior = new Warrior("Pesho", 10, 100);
                var warriorG = new Warrior("Gosho", 12, HP);
                warrior.Attack(warriorG);
            }, $"Enemy HP must be greater than 30 in order to attack him!");
        }     
        [Test]
        [TestCase(41)]
        [TestCase(67)]
        [TestCase(111)]
        public void AttackedEnemyHasBiggerDamageThanAttackerHP(int damage)
        {
            //InvalidOperationException("Your HP is too low in order to attack other warriors!"
            Assert.Throws<InvalidOperationException>(() =>
            {
                var warrior = new Warrior("Pesho", 10, 40);
                var warriorG = new Warrior("Gosho", damage, 100);
                warrior.Attack(warriorG);
            }, $"You are trying to attack too strong enemy");
        }
        [Test]
        [TestCase(51)]
        [TestCase(67)]
        [TestCase(111)]
        public void AttackMethodShouldWork_Successfully(int damage)
        {
            var warrior = new Warrior("Pesho", damage, 90);
            var warriorG = new Warrior("Gosho", 10, 50);
            warrior.Attack(warriorG);
            Assert.AreEqual((warrior.HP, warriorG.HP), (80, 0));
        }       
        [Test]
        [TestCase(80)]
        [TestCase(67)]
        [TestCase(20)]
        public void AttackMethodShouldWork_Successfully2(int damage)
        {
            var warrior = new Warrior("Pesho", damage, 90);
            var warriorG = new Warrior("Gosho", 10, 80);
            warrior.Attack(warriorG);
            Assert.AreEqual((warrior.HP, warriorG.HP), (80, 80 - damage));
        }
    }
}