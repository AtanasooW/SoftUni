﻿namespace FightingArena.Tests
{
    using NUnit.Framework;
    using System;
    using System.Collections.Generic;

    [TestFixture]
    public class ArenaTests
    {
        private Arena arena;
        private Warrior warrior;
        private Warrior warriorG;
        [SetUp]
        public void SetUp()
        {
            this.arena = new Arena();
            warrior = new Warrior("Pesho", 10, 100);
            warriorG = new Warrior("Gosho", 15, 100);
        }
        [Test]
        public void ConstructorShouldWork_Successfully()
        {
            List<Warrior> list = new List<Warrior>();
            Assert.AreEqual(list, arena.Warriors);
            Assert.AreEqual(list.Count, arena.Count);
        }
        [Test]
        public void CountGetter()
        {
            Assert.AreEqual(0, arena.Count);
        }
        [Test]
        public void EnrollMethodSholdThroExceptionForWarriorWhosIsEnrolled()
        {
            //InvalidOperationException("Warrior is already enrolled for the fights!")
            Assert.Throws<InvalidOperationException>(() =>
            {
                arena.Enroll(warrior);
                arena.Enroll(warrior);
            }, "Warrior is already enrolled for the fights!");
        }
        [Test]
        public void FightMethodShouldThrowExceptionForInvalidName()
        {
            //InvalidOperationException($"There is no fighter with name {missingName} enrolled for the fights!");
            Assert.Throws<InvalidOperationException>(() =>
            {
                Warrior warrior = new Warrior("Viktor", 10, 100);
                Warrior warrior2 = new Warrior("Vasil", 10, 100);
                arena.Enroll(warrior);
                arena.Fight("Viktor", "Vasil");
            }, $"There is no fighter with name Vasil enrolled for the fights!");
        }    
        [Test]
        public void FightMethodShouldThrowExceptionForInvalidName2()
        {
            //InvalidOperationException($"There is no fighter with name {missingName} enrolled for the fights!");
            Assert.Throws<InvalidOperationException>(() =>
            {
                Warrior warrior = new Warrior("Viktor", 10, 100);
                Warrior warrior2 = new Warrior("Vasil", 10, 100);
                arena.Enroll(warrior2);
                arena.Fight("Viktor", "Vasil");
            }, $"There is no fighter with name Viktor enrolled for the fights!");
        }   
        [Test]
        public void FightMethodShouldWork_Successfully()
        {
                Warrior warrior = new Warrior("Viktor", 10, 100);
                Warrior warrior2 = new Warrior("Vasil", 10, 100);
                arena.Enroll(warrior);
                arena.Enroll(warrior2);
                arena.Fight("Viktor", "Vasil");
            Assert.AreEqual((90, 90), (warrior.HP, warrior2.HP));
        }
    }
}
