﻿namespace Gym.Models.Athletes
{
    using Utilities.Messages;

    using System;
    public class Boxer : Athlete
    {
        private const int staminaOfTheBoxer = 60;
        private const int exerciseStaminaIncrease = 15;

        public Boxer(string fullName, string motivation, int numberOfMedals) : base(fullName, motivation, numberOfMedals, staminaOfTheBoxer)
        {
        }
        public override void Exercise()
        {
            Stamina += exerciseStaminaIncrease;
            if (Stamina > 100)
            {
                Stamina = 100;
                throw new ArgumentException(String.Format(ExceptionMessages.InvalidStamina));
            }
        }
    }
}
