﻿namespace Gym.Models.Athletes
{
    using Utilities.Messages;
    using System;

    public class Weightlifter : Athlete
    {
        private const int staminaOfTheWeightLifter = 50;
        private const int exerciseStaminaIncrease = 10;


        public Weightlifter(string fullName, string motivation, int numberOfMedals) : base(fullName, motivation, numberOfMedals, staminaOfTheWeightLifter)
        {
        }
        public override void Exercise()
        {
            Stamina += exerciseStaminaIncrease;
            if (Stamina > 100)
            {
                Stamina = 100;
                throw new ArgumentException(String.Format(ExceptionMessages.InvalidStamina));
            }
        }
    }
}
