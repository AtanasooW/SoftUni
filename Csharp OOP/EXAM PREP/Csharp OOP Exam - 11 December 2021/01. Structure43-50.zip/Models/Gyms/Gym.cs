﻿namespace Gym.Models.Gyms
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    using Contracts;
    using Athletes.Contracts;
    using Equipment.Contracts;
    using Utilities.Messages;

    public abstract class Gym : IGym
    {
        private string name;
        private int capacity;
        private ICollection<IEquipment> equipment;
        private ICollection<IAthlete> athletes;

        protected Gym(string name, int capacity)
        {
            this.Name = name;
            this.Capacity = capacity;
            this.equipment = new List<IEquipment>();
            this.athletes = new List<IAthlete>();
        }

        public string Name
        {
            get { return this.name; }
            private set
            {
                if (String.IsNullOrEmpty(value))//maybe bug
                {
                    throw new ArgumentException(String.Format(ExceptionMessages.InvalidGymName));
                }
                this.name = value;
            }
        }

        public int Capacity
        {
            get { return this.capacity; }
            private set { this.capacity = value; }
        }

        public double EquipmentWeight
        {
            get
            {
                double sum = 0;
                foreach (var item in Equipment)
                {
                    sum += item.Weight;
                }
                double pen = Equipment.Sum(x => x.Weight);//maybe bug
                return sum;
            }
        }

        public ICollection<IEquipment> Equipment
        {
            get
            {
                return this.equipment;
            }
            private set
            {
                this.equipment = value;
            }
        }

        public ICollection<IAthlete> Athletes
        {
            get
            {
                return this.athletes;
            }
            private set
            {
                this.athletes = value;
            }
        }

        public void AddAthlete(IAthlete athlete)
        {
            if (this.Capacity == Athletes.Count)
            {
                throw new InvalidOperationException(String.Format(ExceptionMessages.NotEnoughSize));
            }
            athletes.Add(athlete);
        }

        public void AddEquipment(IEquipment equipment)
        {
            this.equipment.Add(equipment);
        }

        public void Exercise()
        {
            int counter = 0;
            foreach (var item in athletes)
            {
                item.Exercise();
                counter++;
            }
            this.Counter = counter;
        }
        public int Counter { get; private set; }
        public string GymInfo()
        {
            var sb = new StringBuilder();
            sb.AppendLine($"{this.Name} is a {this.GetType().Name}:");
            if (this.athletes.Count < 1)
            {
                sb.AppendLine("Athletes: No athletes");
            }
            else
            {
                sb.AppendLine($"Athletes: {String.Join(", ", athletes.Select(x => x.FullName))}");
            }
            sb.AppendLine($"Equipment total count: {this.equipment.Count}");
            sb.AppendLine($"Equipment total weight: {this.EquipmentWeight:F2} grams");
            return sb.ToString().Trim();

        }

        public bool RemoveAthlete(IAthlete athlete)
        => athletes.Remove(athlete);
    }
}
