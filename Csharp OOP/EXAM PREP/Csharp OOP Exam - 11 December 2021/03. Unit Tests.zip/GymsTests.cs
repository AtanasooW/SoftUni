﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace Gyms.Tests
{
    public class GymsTests
    {
        private Athlete athlete;
        private Athlete athlete1;
        private Athlete athlete2;
        private Athlete athlete3;
        private Gym gym;
        [SetUp]
        public void SetUp()
        {
            athlete = new Athlete("Pesho");
            athlete1 = new Athlete("Gosho");
            athlete2 = new Athlete("Petar");
            athlete3 = new Athlete("Vasil");

            gym = new Gym("ZonaSport", 16);

        }
        [Test]
        public void testAthleteConstructorShouldWork_Successfully()
        {
            Athlete athlete = new Athlete("Pesho");
            Assert.AreEqual("Pesho", athlete.FullName);
            Assert.AreEqual(false, athlete.IsInjured);
        }
        [Test]
        public void TestFullNameGetter()
        {
            Assert.AreEqual("Pesho", athlete.FullName);
        }
        [Test]
        public void TestFullNameSetter()
        {
            athlete.FullName = "Gosho";
            Assert.AreEqual("Gosho", athlete.FullName);
        }
        [Test]
        public void TestIsInjuredGetter()
        {
            Assert.AreEqual(false, athlete.IsInjured);
        }
        [Test]
        public void TestIsInjuredSetter()
        {
            athlete.IsInjured = true;
            Assert.AreEqual(true, athlete.IsInjured);
        }
        [Test]
        public void TestGymConstructorShouldWork_Successfully()
        {
            Gym gym = new Gym("ZonaSport", 16);
            List<Athlete> list = new List<Athlete>();
            FieldInfo fl = gym.GetType().GetFields(BindingFlags.Instance | BindingFlags.NonPublic).FirstOrDefault(x => x.Name == "athletes");
            List<Athlete> actual = (List<Athlete>)fl.GetValue(gym);
            CollectionAssert.AreEqual(list, actual);
            Assert.AreEqual("ZonaSport", gym.Name);
            Assert.AreEqual(16, gym.Capacity);
            Assert.AreEqual(0, gym.Count);

        }
        [Test]
        public void TestNameGetter()
        {
            Assert.AreEqual("ZonaSport", gym.Name);
        }
        [Test]
        [TestCase(null)]
        [TestCase("")]
        public void NameShouldThrowArgumentNullException_ForNullValueOrSpace(string name)
        {
            Assert.Throws<ArgumentNullException>(() =>
            {
                Gym gym = new Gym(name, 16);
            }, "Invalid gym name.");

        }
        [Test]
        public void TestCapacityGetter()
        {
            Assert.AreEqual(16, gym.Capacity);
        }
        [Test]
        [TestCase(-1)]
        [TestCase(-57)]
        [TestCase(-19)]
        public void CapacityShouldThrowArgumentException_ForNegativeValue(int capacity)
        {
            //"Invalid gym capacity."
            Assert.Throws<ArgumentException>(() =>
            {
                Gym gym = new Gym("Pesho", capacity);
            }, "Invalid gym capacity.");
        }
        [Test]
        public void TestCountGetter()
        {
            Assert.AreEqual(0, gym.Count);
        }
        [Test]
        public void AddAthleteShouldWork_Successfully()
        {
            List<Athlete> list = new List<Athlete>();
            gym.AddAthlete(athlete);
            list.Add(athlete);
            FieldInfo fl = gym.GetType().GetFields(BindingFlags.Instance | BindingFlags.NonPublic).FirstOrDefault(x => x.Name == "athletes");
            List<Athlete> actual = (List<Athlete>)fl.GetValue(gym);
            CollectionAssert.AreEqual(list, actual);
        }
        [Test]
        public void AddAthleteMethodShouldThrowInvalidOperationException_ForFullGym()
        {
            //"The gym is full."
            Gym gym = new Gym("ZonaSport", 1);
            Athlete athlete1 = new Athlete("Gosho");
            Assert.Throws<InvalidOperationException>(() =>
            {
                gym.AddAthlete(athlete);
                gym.AddAthlete(athlete1);
            }, "The gym is full.");
        }
        [Test]
        public void RemoveAthleteShouldThrowInvalidOperationException_ForAthleteDoesntExist()
        {
            //$"The athlete {fullName} doesn't exist."
            Assert.Throws<InvalidOperationException>(() =>
            {
                gym.AddAthlete(athlete);
                gym.RemoveAthlete("Gosho");
            }, $"The athlete Gosho doesn't exist.");
        }
        [Test]
        public void RemoveAthleteShouldWork_Successfully()
        {
            gym.AddAthlete(athlete);
            gym.RemoveAthlete("Pesho");
            List<Athlete> list = new List<Athlete>();
            FieldInfo fl = gym.GetType().GetFields(BindingFlags.Instance | BindingFlags.NonPublic).FirstOrDefault(x => x.Name == "athletes");
            List<Athlete> actual = (List<Athlete>)fl.GetValue(gym);
            CollectionAssert.AreEqual(list, actual);
        }
        [Test]
        public void RemoveAthleteShouldRemoveMultipleTimes_Work_Successfully()
        {
            List<Athlete> list = new List<Athlete>();
            gym.AddAthlete(athlete);
            gym.AddAthlete(athlete1);
            gym.AddAthlete(athlete2);
            gym.AddAthlete(athlete3);
            gym.RemoveAthlete("Vasil");
            gym.RemoveAthlete("Gosho");
            gym.RemoveAthlete("Petar");
            list.Add(athlete);
            FieldInfo fl = gym.GetType().GetFields(BindingFlags.Instance | BindingFlags.NonPublic).FirstOrDefault(x => x.Name == "athletes");
            List<Athlete> actual = (List<Athlete>)fl.GetValue(gym);
            CollectionAssert.AreEqual(list, actual);
        }
        [Test]
        public void InjureAthleteShouldThrowInvalidOperationException_ForAthleteDoenstExist()
        {
            //$"The athlete {fullName} doesn't exist."
            Assert.Throws<InvalidOperationException>(() =>
            {
                gym.AddAthlete(athlete);
                gym.InjureAthlete("Gosho");
            }, $"The athlete Gosho doesn't exist.");
        }
        [Test]
        public void InjureAthleteShouldWork_Successfully()
        {
            gym.AddAthlete(athlete);
           Athlete actual = gym.InjureAthlete("Pesho");
            Assert.AreEqual(("Pesho", true), (actual.FullName, actual.IsInjured));
        }
        [Test]
        public void ReportShouldWork_Successfully()
        {
            gym.AddAthlete(athlete);
            gym.AddAthlete(athlete1);
            gym.AddAthlete(athlete2);
            gym.InjureAthlete("Petar");
            string gymReport = gym.Report();
            Assert.AreEqual("Active athletes at ZonaSport: Pesho, Gosho", gymReport);
        }
    }
}
