﻿namespace Gym.Repositories
{
using System;
    using System.Collections.Generic;
    using System.Linq;
    using Contracts;
    using Models.Equipment.Contracts;
    public class EquipmentRepository : IRepository<IEquipment>
    {
        private readonly ICollection<IEquipment> models;
        public IReadOnlyCollection<IEquipment> Models => (IReadOnlyCollection<IEquipment>)models;
        public EquipmentRepository()
        {
            this.models = new List<IEquipment>();
        }
        public void Add(IEquipment model)
        => models.Add(model);

        public IEquipment FindByType(string type)
        => models.FirstOrDefault(x => x.GetType().Name == type);

        public bool Remove(IEquipment model)
        => models.Remove(model);
    }
}
