﻿namespace Gym.Models.Gyms
{
using System;
    public class BoxingGym : Gym
    {
        private const int capacityForBoxingGym = 15;
        public BoxingGym(string name) : base(name, capacityForBoxingGym)
        {
        }
    }
}
