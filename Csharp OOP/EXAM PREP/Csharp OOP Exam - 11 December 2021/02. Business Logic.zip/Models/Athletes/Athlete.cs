﻿namespace Gym.Models.Athletes
{
    using System;

    using Contracts;
    using Utilities.Messages;
    public abstract class Athlete : IAthlete
    {
        private string fullName;
        private string motivation;
        private int stamina;
        private int numberOfMedals;

        protected Athlete(string fullName, string motivation, int numberOfMedals, int stamina)
        {
            this.FullName = fullName;
            this.Motivation = motivation;
            this.NumberOfMedals = numberOfMedals;
            this.Stamina = stamina;
        }

        public string FullName
        {
            get { return this.fullName; }
            private set
            {
                if (String.IsNullOrEmpty(value))//maybe bug
                {
                    throw new ArgumentException(String.Format(ExceptionMessages.InvalidAthleteName));
                }
                this.fullName = value;
            }
        }

        public string Motivation
        {
            get { return this.motivation; }
            private set
            {
                if (String.IsNullOrEmpty(value))//maybe bug
                {
                    throw new ArgumentException(String.Format(ExceptionMessages.InvalidAthleteMotivation));
                }
                this.motivation = value;
            }
        }

        public int Stamina
        {
            get
            {
                return this.stamina;
            }
            protected set
            {
                this.stamina = value;
            }
        }

        public int NumberOfMedals
        {
            get
            {
                return this.numberOfMedals;
            }
            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException(String.Format(ExceptionMessages.InvalidAthleteMedals));
                }
                this.numberOfMedals = value;//yes
            }
        }

        public abstract void Exercise();//maybe
        public override string ToString()
        {
            return this.FullName;
        }
    }
}
