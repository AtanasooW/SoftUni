﻿namespace CarRacing.Core
{
using System;
using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using CarRacing.Models.Cars;
    using CarRacing.Models.Cars.Contracts;
    using CarRacing.Models.Maps;
    using CarRacing.Models.Maps.Contracts;
    using CarRacing.Models.Racers;
    using CarRacing.Models.Racers.Contracts;
    using CarRacing.Repositories;
    using CarRacing.Repositories.Contracts;
    using CarRacing.Utilities.Messages;
    using Contracts;
    public class Controller : IController
    {
        private readonly IRepository<ICar> carRepository;
        private readonly IRepository<IRacer> racerRepository;
        private readonly IMap map;

        public Controller()
        {
            this.carRepository = new CarRepository();
            this.racerRepository = new RacerRepository();
            this.map = new Map();
        }
        public string AddCar(string type, string make, string model, string VIN, int horsePower)
        {
            if (type == "SuperCar")
            {
                ICar car = new SuperCar(make, model, VIN, horsePower);
                this.carRepository.Add(car);
                return String.Format(OutputMessages.SuccessfullyAddedCar, make, model, VIN);
            }
            else if (type == "TunedCar")
            {
                ICar car = new TunedCar(make, model, VIN, horsePower);
                this.carRepository.Add(car);
                return String.Format(OutputMessages.SuccessfullyAddedCar, make, model, VIN);
            }
            else
            {
                throw new ArgumentException(String.Format(ExceptionMessages.InvalidCarType));
            }
        }

        public string AddRacer(string type, string username, string carVIN)
        {
            if (type == "ProfessionalRacer")
            {
                ICar car = this.carRepository.Models.FirstOrDefault(x => x.VIN == carVIN);
                if (car == null)
                {
                    throw new ArgumentException(String.Format(ExceptionMessages.CarCannotBeFound));
                }
                IRacer racer = new ProfessionalRacer(username, car);
                this.racerRepository.Add(racer);
                return String.Format(OutputMessages.SuccessfullyAddedRacer, username);
            }
            else if (type == "StreetRacer")
            {
                ICar car = this.carRepository.Models.FirstOrDefault(x => x.VIN == carVIN);
                if (car == null)
                {
                    throw new ArgumentException(String.Format(ExceptionMessages.CarCannotBeFound));
                }
                IRacer racer = new StreetRacer(username, car);
                this.racerRepository.Add(racer);
                return String.Format(OutputMessages.SuccessfullyAddedRacer, username);
            }
            else
            {
                throw new ArgumentException(String.Format(ExceptionMessages.InvalidRacerType));

            }
        }

        public string BeginRace(string racerOneUsername, string racerTwoUsername)
        {
            IRacer racer1 = this.racerRepository.Models.FirstOrDefault(x => x.Username == racerOneUsername);
            if (racer1 == null)
            {
                throw new ArgumentException(String.Format(ExceptionMessages.RacerCannotBeFound, racerOneUsername));
            }
            IRacer racer2 = this.racerRepository.Models.FirstOrDefault(x => x.Username == racerTwoUsername);
            if (racer2 == null)
            {
                throw new ArgumentException(String.Format(ExceptionMessages.RacerCannotBeFound, racerTwoUsername));
            }
            return map.StartRace(racer1, racer2);
        }

        public string Report()
        {
            var sb = new StringBuilder();
            foreach (var item in racerRepository.Models.OrderByDescending(x => x.DrivingExperience).ThenBy(x => x.Username))
            {
                sb.AppendLine(item.ToString());
            }
            return sb.ToString().TrimEnd();
        }
    }
}
