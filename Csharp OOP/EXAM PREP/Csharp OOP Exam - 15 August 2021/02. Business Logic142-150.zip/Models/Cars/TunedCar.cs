﻿using System;

namespace CarRacing.Models.Cars
{
    public class TunedCar : Car
    {
        private const double fuelAvailableForTunedCar = 65;
        private const double fuelConsumptionPerRaceForTunedCar = 7.5;
        public TunedCar(string make, string model, string vIN, int horsePower) : base(make, model, vIN, horsePower, fuelAvailableForTunedCar, fuelConsumptionPerRaceForTunedCar)
        {
        }
        public override void Drive()
        {
            base.Drive();
            int reduceHP = (int)Math.Round(HorsePower * 0.03);
            HorsePower -= reduceHP;
        }
    }
}
