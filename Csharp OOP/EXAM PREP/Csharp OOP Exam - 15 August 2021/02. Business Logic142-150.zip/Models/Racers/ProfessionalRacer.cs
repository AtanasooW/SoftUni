﻿using CarRacing.Models.Cars.Contracts;

namespace CarRacing.Models.Racers
{
    public class ProfessionalRacer : Racer
    {
        private const int drivingExperienceForProfessionalRacer = 30;
        private const string racingBehaviorForProfessionalRacer = "strict";
        public ProfessionalRacer(string username, ICar car) : base(username, racingBehaviorForProfessionalRacer, drivingExperienceForProfessionalRacer, car)
        {
        }
        public override void Race()
        {
            base.Race();
            DrivingExperience += 10;
        }
    }
}
