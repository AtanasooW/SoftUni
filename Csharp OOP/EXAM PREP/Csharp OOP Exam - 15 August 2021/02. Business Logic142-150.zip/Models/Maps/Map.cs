﻿namespace CarRacing.Models.Maps
{
using System;
using System.Collections.Generic;
    using CarRacing.Models.Racers.Contracts;
    using Contracts;
    using Utilities.Messages;
    public class Map : IMap
    {
        public string StartRace(IRacer racerOne, IRacer racerTwo)
        {
            //1 ne > 2da > 2 ne
            if (racerOne.IsAvailable() && racerTwo.IsAvailable())
            {
                double racingBehaviorMultiplier = 0;
                if (racerOne.RacingBehavior == "strict")
                {
                    racingBehaviorMultiplier = 1.2;
                }
                else if (racerOne.RacingBehavior == "aggressive")
                {
                    racingBehaviorMultiplier = 1.1;
                }
                double chanceOfWinningOne = racerOne.Car.HorsePower * racerOne.DrivingExperience * racingBehaviorMultiplier;
                racerOne.Race();
                double racingBehaviorMultiplierTwo = 0;
                if (racerTwo.RacingBehavior == "strict")
                {
                    racingBehaviorMultiplierTwo = 1.2;
                }
                else if (racerTwo.RacingBehavior == "aggressive")
                {
                    racingBehaviorMultiplierTwo = 1.1;
                }
                double chanceOfWinningTwo = racerTwo.Car.HorsePower * racerTwo.DrivingExperience * racingBehaviorMultiplierTwo;
                racerTwo.Race();
                if (chanceOfWinningOne > chanceOfWinningTwo)
                {
                    return String.Format(OutputMessages.RacerWinsRace, racerOne.Username, racerTwo.Username, racerOne.Username);
                }
                else if (chanceOfWinningOne < chanceOfWinningTwo)
                {
                    return String.Format(OutputMessages.RacerWinsRace, racerOne.Username, racerTwo.Username, racerTwo.Username);
                }
            }
            else if (racerOne.IsAvailable() == false)
            {
                if (racerTwo.IsAvailable())
                {
                    return String.Format(OutputMessages.OneRacerIsNotAvailable, racerTwo.Username, racerOne.Username);
                }
                else
                {
                    return String.Format(OutputMessages.RaceCannotBeCompleted);
                }
            }
            //1 da> 2ne 
            else if (racerOne.IsAvailable())
            {
                if (racerTwo.IsAvailable() == false)
                {
                    return String.Format(OutputMessages.OneRacerIsNotAvailable, racerOne.Username, racerTwo.Username);
                }
            }
            return null;
        }
    }
}
