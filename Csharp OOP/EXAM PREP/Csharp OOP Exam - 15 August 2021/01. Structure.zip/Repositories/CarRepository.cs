﻿namespace CarRacing.Repositories
{
using System;
using System.Collections.Generic;
    using Contracts;
    using Utilities.Messages;
    using Models.Cars.Contracts;
    using System.Linq;

    public class CarRepository : IRepository<ICar>
    {
        private ICollection<ICar> models;
        public IReadOnlyCollection<ICar> Models => (IReadOnlyCollection<ICar>)this.models;

        public void Add(ICar model)
        {
            if (model == null)
            {
                throw new ArgumentException(String.Format(ExceptionMessages.InvalidAddCarRepository));
            }
            this.models.Add(model);
        }

        public ICar FindBy(string property)
        => this.models.FirstOrDefault(x => x.VIN == property);

        public bool Remove(ICar model)
            => this.models.Remove(model);
    }
}
