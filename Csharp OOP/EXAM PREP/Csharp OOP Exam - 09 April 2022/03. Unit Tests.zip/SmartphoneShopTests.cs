﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;

namespace SmartphoneShop.Tests
{
    [TestFixture]
    public class SmartphoneShopTests
    {
        private Smartphone smartPhone;
        private Shop shop;
        [SetUp]
        public void SetUp()
        {
            smartPhone = new Smartphone("Samsung", 100);
            shop = new Shop(16);

        }
        [Test]
        public void TestContructorOfTheSmartphoneClassShouldWork_Successfully()
        {
            Smartphone smartphone = new Smartphone("Samsung", 100);
            Assert.AreEqual(("Samsung", 100, 100), (smartphone.ModelName, smartphone.MaximumBatteryCharge, smartphone.CurrentBateryCharge));
        }
        [Test]
        public void TestSmartphoneModelNameGetter()
        {
            Assert.AreEqual("Samsung", smartPhone.ModelName);
        }
        [Test]
        public void TestSmartphoneMaximumBatteryChargeGetter()
        {
            Assert.AreEqual(100, smartPhone.MaximumBatteryCharge);
        }
        [Test]
        public void TestSmartphoneCurrentBateryChargeGetter()
        {
            Assert.AreEqual(100, smartPhone.CurrentBateryCharge);
        }
        [Test]
        public void TestSmartphoneModelNameSetter()
        {
            smartPhone.ModelName = "Nokia";
            Assert.AreEqual("Nokia", smartPhone.ModelName);
        }
        [Test]
        public void TestSmartphoneCurrentBateryChargeSetter()
        {
            smartPhone.CurrentBateryCharge = 85;
            Assert.AreEqual(85, smartPhone.CurrentBateryCharge);
        }
        [Test]
        public void TestShopContructorShouldWork_Successfully()
        {
            Shop shop = new Shop(16);
            List<Smartphone> list = new List<Smartphone>();
            FieldInfo fl = shop.GetType().GetFields(BindingFlags.Instance | BindingFlags.NonPublic).FirstOrDefault(x => x.Name == "phones");
            Assert.AreEqual(list, fl.GetValue(shop));
            Assert.AreEqual(16, shop.Capacity);
            Assert.AreEqual(0, shop.Count);
        }
        [Test]
        public void TestCapacityGetter()
        {
            Assert.AreEqual(16, shop.Capacity);
        }
        [Test]
        [TestCase(-1)]
        [TestCase(-58)]
        [TestCase(-7)]
        public void CapacityShouldThrowArgumentException_ForNegativeValue(int capacity)
        {
            Assert.Throws<ArgumentException>(() =>
            {
                Shop shop = new Shop(capacity);
            }, "Invalid capacity.");
        }
        [Test]
        public void TestCountGetter()
        {
            Assert.AreEqual(0, shop.Count);
        }
        [Test]
        public void TestAddMethodShouldWork_Successfully()
        {
            FieldInfo fl = shop.GetType().GetFields(BindingFlags.Instance | BindingFlags.NonPublic).FirstOrDefault(x => x.Name == "phones");
            shop.Add(smartPhone);
            List<Smartphone> list = new List<Smartphone>();
            list.Add(smartPhone);
            List<Smartphone> actual = (List<Smartphone>)fl.GetValue(shop);
            CollectionAssert.AreEqual(list, actual);
        }
        [Test]
        public void AddMethodShouldThrowInvalidOperationException_ForAlreadyExistPhone()
        {
            Assert.Throws<InvalidOperationException>(() =>
            {
                shop.Add(smartPhone);
                shop.Add(smartPhone);
            }, $"The phone model {smartPhone.ModelName} already exist.");
        }
        [Test]
        public void AddMethodShouldThrowInvalidOperationException_ForFullCapacity() 
        {
            //Arragne
            Smartphone smartphone1 = new Smartphone("Nokia", 120);
            Shop shop = new Shop(1);
            //Assert
            Assert.Throws<InvalidOperationException>(() =>
            {
                //Act
                shop.Add(smartPhone);
                shop.Add(smartphone1);

            }, "The shop is full.");
        }
        [Test]
        public void RemoveMethodShouldThrowInvalidOperationException_ForPhoneDoesntContainsInTheShop()
        {
            //$"The phone model {modelName} doesn't exist."
            Assert.Throws<InvalidOperationException>(() =>
            {
                shop.Add(smartPhone);
                shop.Remove("Nokia");
            }, $"The phone model Nokia doesn't exist.");
        }
        [Test]
        public void RemoveMethodShouldWork_Successfully()
        {
            shop.Add(smartPhone);
            shop.Remove("Samsung");
            List<Smartphone> list = new List<Smartphone>();
            FieldInfo fl = shop.GetType().GetFields(BindingFlags.Instance | BindingFlags.NonPublic).FirstOrDefault(x => x.Name == "phones");
            List<Smartphone> actual = (List<Smartphone>)fl.GetValue(shop);
            CollectionAssert.AreEqual(list, actual);
        }
        [Test]
        public void RemoveMethodShouldRemovesMultipleTimes_Work_Successfully2()
        {
            Smartphone smartphone1 = new Smartphone("Nokia", 100);
            Smartphone smartphone2 = new Smartphone("Iphone", 100);
            Smartphone smartphone3 = new Smartphone("S60", 100);
            shop.Add(smartPhone);
            shop.Add(smartphone1);
            shop.Add(smartphone2);
            shop.Add(smartphone3);
            shop.Remove("Samsung");
            shop.Remove("Nokia");
            shop.Remove("Iphone");
            List<Smartphone> list = new List<Smartphone>();
            list.Add(smartphone3);
            FieldInfo fl = shop.GetType().GetFields(BindingFlags.Instance | BindingFlags.NonPublic).FirstOrDefault(x => x.Name == "phones");
            List<Smartphone> actual = (List<Smartphone>)fl.GetValue(shop);
            CollectionAssert.AreEqual(list, actual);
        }
        [Test]
        public void TestPhoneMethodShouldThrowInvalidOperationException_ForPhoneDoesntContainsInTheShop()
        {
            //$"The phone model {modelName} doesn't exist."
            Assert.Throws<InvalidOperationException>(() =>
            {
                shop.Add(smartPhone);
                shop.TestPhone("Nokia", 2);
            }, $"The phone model Nokia doesn't exist.");
        }
        [Test]
        [TestCase(101)]
        [TestCase(150)]
        [TestCase(127)]
        public void TestPhoneMethodShouldThrowInvalidOperationException_ForLowPhoneBattery(int usage)
        {
            shop.Add(smartPhone);
            Assert.Throws<InvalidOperationException>(() =>
            {
                shop.TestPhone("Samsung", usage);
            }, $"The phone model Samsung is low on batery.");
        }
        [Test]
        public void TestPhoneMethodShouldWork_Successfully()
        {
            shop.Add(smartPhone);
            shop.TestPhone("Samsung", 10);
            FieldInfo fl = shop.GetType().GetFields(BindingFlags.Instance | BindingFlags.NonPublic).FirstOrDefault(x => x.Name == "phones");
            List<Smartphone> actual = (List<Smartphone>)fl.GetValue(shop);
            Smartphone actualSmartphone = actual.First(x => x.ModelName == "Samsung");
            Assert.AreEqual(90, actualSmartphone.CurrentBateryCharge);
        }
        [Test]
        public void ChargePhoneMethodShouldThrowInvalidOperationException_ForPhoneDoesntContainsInTheShop()
        {
            //$"The phone model {modelName} doesn't exist."
            Assert.Throws<InvalidOperationException>(() =>
            {
                shop.Add(smartPhone);
                shop.ChargePhone("Nokia");
            }, $"The phone model Nokia doesn't exist.");
        }
        [Test]
        public void ChargePhoneShouldWork_Successfully()
        {
            shop.Add(smartPhone);
            shop.TestPhone("Samsung", 10);
            shop.ChargePhone("Samsung");
            FieldInfo fl = shop.GetType().GetFields(BindingFlags.Instance | BindingFlags.NonPublic).FirstOrDefault(x => x.Name == "phones");
            List<Smartphone> actual = (List<Smartphone>)fl.GetValue(shop);
            Smartphone actualSmartphone = actual.First(x => x.ModelName == "Samsung");
            Assert.AreEqual(100, actualSmartphone.CurrentBateryCharge);
        }
    }
}