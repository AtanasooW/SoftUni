﻿namespace Formula1.Repositories
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    using Contracts;
    using Models.Contracts;
    using Utilities;
    public class PilotRepository : IRepository<IPilot>
    {
        private ICollection<IPilot> models;
        public IReadOnlyCollection<IPilot> Models => (IReadOnlyCollection<IPilot>)this.models;

        public void Add(IPilot model)
        {
            this.models.Add(model);
        }

        public IPilot FindByName(string name)
        {
            IPilot pilot = this.models.FirstOrDefault(c => c.FullName == name);
            if (pilot == null)
            {
                return null;
            }
            return pilot;
        }

        public bool Remove(IPilot model)
        {
            if (models.Count < 1)
            {
                return false;
            }
            string name = model.FullName;
            IPilot pilot = this.models.FirstOrDefault(c => c.FullName == name);
            if (pilot == null)
            {
                return false;
                
            }
            return true;
        }
    }
}
