﻿namespace Formula1.Repositories
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    using Contracts;
    using Models.Contracts;
    using Utilities;
    public class FormulaOneCarRepository : IRepository<IFormulaOneCar>
    {
        private ICollection<IFormulaOneCar> models;
        public IReadOnlyCollection<IFormulaOneCar> Models => (IReadOnlyCollection<IFormulaOneCar>)this.models;

        public void Add(IFormulaOneCar model)
        {
            this.models.Add(model);
        }

        public IFormulaOneCar FindByName(string name)
        {
            IFormulaOneCar car = this.models.FirstOrDefault(c => c.Model == name);
            if (car == null)
            {
                return null;
            }
            return car;
        }

        public bool Remove(IFormulaOneCar model)
        {
            if (models.Count < 1)
            {
                return false;
            }
            string name = model.Model;
            IFormulaOneCar car = this.models.FirstOrDefault(c => c.Model == name);
            if (car == null)
            {
                return false;
                //throw new ArgumentException(String.Format(ExceptionMessages.CarDoesNotExistErrorMessage, model));
            }
            return true;
        }
    }
}
