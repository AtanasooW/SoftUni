﻿namespace Formula1.Repositories
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    using Contracts;
    using Models.Contracts;
    using Utilities;
    internal class RaceRepository : IRepository<IRace>
    {
        private ICollection<IRace> models;
        public IReadOnlyCollection<IRace> Models => (IReadOnlyCollection<IRace>)this.models;

        public void Add(IRace model)
        {
            this.models.Add(model);
        }

        public IRace FindByName(string name)
        {
            IRace race = this.models.FirstOrDefault(c => c.RaceName == name);
            if (race == null)
            {
                return null;
            }
            return race;
        }

        public bool Remove(IRace model)
        {
            if (models.Count < 1)
            {
                return false;
            }
            string name = model.RaceName;
            IRace race = this.models.FirstOrDefault(c => c.RaceName == name);
            if (race == null)
            {
                return false;
            }
            return true;
        }
    }
}
