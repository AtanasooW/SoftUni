﻿namespace Formula1.Repositories
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    using Contracts;
    using Models.Contracts;
    using Utilities;
    public class PilotRepository : IRepository<IPilot>
    {
        private readonly ICollection<IPilot> models;
        public IReadOnlyCollection<IPilot> Models => (IReadOnlyCollection<IPilot>)this.models;

        public PilotRepository()
        {
            this.models = new List<IPilot>();
        }

        public void Add(IPilot pilot)
            => this.models.Add(pilot);

        public IPilot FindByName(string fullName)
            => this.models.FirstOrDefault(x => x.FullName == fullName);

        public bool Remove(IPilot model)
            => this.models.Remove(model);
    }
}
