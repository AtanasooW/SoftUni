﻿namespace Formula1.Repositories
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    using Contracts;
    using Models.Contracts;
    using Utilities;
    internal class RaceRepository : IRepository<IRace>
    {
        private readonly ICollection<IRace> models;
        public IReadOnlyCollection<IRace> Models => (IReadOnlyCollection<IRace>)this.models;

        public RaceRepository()
        {
            this.models = new List<IRace>();
        }

        public void Add(IRace rece)
            => this.models.Add(rece);

        public IRace FindByName(string raceName)
             => this.models.FirstOrDefault(x => x.RaceName == raceName);

        public bool Remove(IRace rece)
            => this.models.Remove(rece);
    }
}
