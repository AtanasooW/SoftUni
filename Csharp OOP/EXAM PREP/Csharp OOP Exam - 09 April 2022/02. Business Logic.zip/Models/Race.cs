﻿namespace Formula1.Models
{
    using System;
    using System.Collections.Generic;
    using Contracts;
    using Utilities;
    public class Race : IRace
    {
        private ICollection<IPilot> pilots;
        private string raceName;
        private int numberOfLaps;

        public ICollection<IPilot> Pilots => this.pilots;
        public Race(string raceName, int numberOfLaps)
        {
            this.RaceName = raceName;
            this.NumberOfLaps = numberOfLaps;
            this.TookPlace = false;
            this.pilots = new List<IPilot>();

        }

        public string RaceName
        {
            get
            {
                return this.raceName;
            }
            private set
            {
                if (String.IsNullOrWhiteSpace(value) || value.Length < 5)
                {
                    throw new ArgumentException(String.Format(ExceptionMessages.InvalidRaceName, value));
                }
                this.raceName = value;
            }
        }

        public int NumberOfLaps
        {
            get
            {
                return this.numberOfLaps;
            }
            private set
            {
                if (value < 1)
                {
                    throw new ArgumentException(String.Format(ExceptionMessages.InvalidLapNumbers, value));
                }
                this.numberOfLaps = value;
            }
        }

        public bool TookPlace { get; set; }

        public void AddPilot(IPilot pilot)
        {
            this.pilots.Add(pilot);
        }

        public string RaceInfo()
        {
            string word = "";
            if (this.TookPlace)
            {
                word = "Yes";
            }
            else
            {
                word = "No";
            }
            return $"The {this.RaceName } race has:" + Environment.NewLine +
           $"Participants: {this.Pilots.Count}" + Environment.NewLine +
           $"Number of laps: { this.NumberOfLaps}" + Environment.NewLine +
           $"Took place: {word}";

        }
    }
}
