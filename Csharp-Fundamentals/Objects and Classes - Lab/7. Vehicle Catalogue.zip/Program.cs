﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _7._Vehicle_Catalogue
{
    class Car
    {
        public Car(string brand, string model, int horseOrWeight)
        {
            this.Brand = brand;
            this.Model = model;
            this.HorsePower = horseOrWeight;
        }
        public string Brand { get; set; }
        public string Model { get; set; }
        public int HorsePower { get; set; }
    }
    class Truck
    {
        public Truck(string brand, string model, int horseOrWeight)
        {
            this.Brand = brand;
            this.Model = model;
            this.Weight = horseOrWeight;
        }
        public string Brand { get; set; }
        public string Model { get; set; }
        public int Weight { get; set; }
    }
    class Catalog
    {
        public Catalog()
        {
            this.Cars = new List<Car>();
            this.Trucks = new List<Truck>();
        }
        public List<Car> Cars { get; set; }
        public List<Truck> Trucks { get; set; }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] command = Console.ReadLine().Split('/');
            Catalog catalog = new Catalog();
            while (command[0] != "end")
            {
                string type = command[0];
                string brand = command[1];
                string model = command[2];
                int horseOrWeight = int.Parse(command[3]);
                if (type == "Car")
                {
                   Car newCar = new Car(brand, model, horseOrWeight);
                    catalog.Cars.Add(newCar);
                }
                if (type == "Truck")
                {
                    Truck newTruck = new Truck(brand, model, horseOrWeight);
                    catalog.Trucks.Add(newTruck);
                }
                command = Console.ReadLine().Split('/');
            }
            if (catalog.Cars.Count > 0)
            {
                Console.WriteLine("Cars:");
                    List<Car> orderCars = catalog.Cars.OrderBy(Car => Car.Brand).ToList();
                foreach (var car in orderCars)
                {
                    Console.WriteLine($"{car.Brand}: {car.Model} - {car.HorsePower}hp");
                }
            }
            if (catalog.Trucks.Count > 0)
            {
                Console.WriteLine("Trucks:");
                List<Truck> orderTrucks = catalog.Trucks.OrderBy(Truck => Truck.Brand).ToList();
                foreach (var car in orderTrucks)
                {
                    Console.WriteLine($"{car.Brand}: {car.Model} - {car.Weight}kg");
                }
            }

        }
    }
}
