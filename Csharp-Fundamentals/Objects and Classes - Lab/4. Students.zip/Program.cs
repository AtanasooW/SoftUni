﻿using System;
using System.Collections.Generic;

namespace _4._Students
{
    class Student
    {
        public string FirstName { get; set; }
        public string SecondName { get; set; }
        public int Age { get; set; }
        public string HomeTown { get; set; }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] command = Console.ReadLine().Split();
            List<Student> students = new List<Student>();
            while (command[0] != "end")
            {
                Student student = new Student();

                student.FirstName = command[0];
                student.SecondName = command[1];
                student.Age = int.Parse(command[2]);
                student.HomeTown = command[3];
                
                students.Add(student);

                command = Console.ReadLine().Split();
            }
            string cityName = Console.ReadLine();
            foreach (Student student in students)
            {
                if (student.HomeTown == cityName)
                {
                    Console.WriteLine($"{student.FirstName} {student.SecondName} is {student.Age} years old.");
                }
            }
        }
    }
}
