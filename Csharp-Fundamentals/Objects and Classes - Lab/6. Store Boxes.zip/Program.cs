﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _6._Store_Boxes
{
    class Item
    {
        public Item(string itemName, double itemPrice)
        {
            this.ItemName = itemName;
            this.ItemPrice = itemPrice;
        }
        public string ItemName { get; set; }
        public double ItemPrice { get; set; }
    }
    class Box
    {
        public Box(int serialNumber, int itemQuantity, double priceForABox, string itemName, double price)
        {
            this.SerialNumber = serialNumber;
            this.ItemQuantity = itemQuantity;
            this.PriceForABox = priceForABox;
            Item = new Item(itemName, price);
        }
        public int SerialNumber { get; set; }
        public Item Item { get; set; }
        public int ItemQuantity { get; set; }
        public double PriceForABox { get; set; }

    }
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Box> boxes = new List<Box>();
            string[] command = Console.ReadLine().Split(' ');
            while (command[0] != "end")
            {
                int serialNumber = int.Parse(command[0]);
                string itemName = command[1];
                int itemQuantity = int.Parse(command[2]);
                double itemPrice = double.Parse(command[3]);
                double price = itemPrice;
                Box box = new Box(serialNumber, itemQuantity, PriceForABox(itemPrice, itemQuantity), itemName, price);
                box.Item = new Item(itemName, itemPrice);
                boxes.Add(box);
                command = Console.ReadLine().Split(' ');

            }
            IOrderedEnumerable<Box> boxes1 = boxes.OrderByDescending(Box => Box.PriceForABox);
            boxes1.Reverse();
            foreach (Box Box in boxes1)
            {
                Console.WriteLine($"{Box.SerialNumber}");
                Console.WriteLine($"-- {Box.Item.ItemName} - ${Box.Item.ItemPrice:F2}: {Box.ItemQuantity}");
                Console.WriteLine($"-- ${Box.PriceForABox:F2}");

            }
            static double PriceForABox(double itemPrice, int itemQuantity)
            {
                return itemPrice * itemQuantity;

            }
        }
    }
}
