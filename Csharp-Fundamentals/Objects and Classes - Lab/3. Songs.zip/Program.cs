﻿using System;
using System.Collections.Generic;

namespace _3._Songs
{
    class Song
    {
        public string TypeOfList { get; set; }

        public string Name { get; set; }

        public string Time { get; set; }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            int num = int.Parse(Console.ReadLine());
            List<Song> songs = new List<Song>();
            for (int i = 0; i < num; i++)
            {
                string[] token = Console.ReadLine().Split('_');
                Song song = new Song();
                song.TypeOfList = token[0];
                song.Name = token[1];
                song.Time = token[2];

                songs.Add(song);
            }
            string command = Console.ReadLine();
            if (command == "all")
            {
                foreach (Song song in songs)
                {
                    Console.WriteLine(song.Name);
                }
            }
            else
            {
                foreach (Song song in songs)
                {
                    if (command == song.TypeOfList)
                    {
                        Console.WriteLine(song.Name);
                    }
                }
            }
        }
    }
}
