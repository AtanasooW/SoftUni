﻿using System;
using System.Collections.Generic;

namespace _4._Students
{
    class Student
    {
        public string FirstName { get; set; }
        public string SecondName { get; set; }
        public int Age { get; set; }
        public string HomeTown { get; set; }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] command = Console.ReadLine().Split();
            bool penis = false;
            List<Student> students = new List<Student>();
            while (command[0] != "end")
            {
                if (isStudentExists(students, command[0], command[1]))
                {
                    foreach (Student student in students)
                    {
                        if (student.FirstName == command[0] && student.SecondName == command[1])
                        {
                            students.Remove(student);
                            penis = true;
                            break;
                        }
                    }
                    if (penis)
                    {
                        Student student = new Student();

                        student.FirstName = command[0];
                        student.SecondName = command[1];
                        student.Age = int.Parse(command[2]);
                        student.HomeTown = command[3];

                        students.Add(student);

                    }

                }
                else
                {
                    Student student = new Student();

                    student.FirstName = command[0];
                    student.SecondName = command[1];
                    student.Age = int.Parse(command[2]);
                    student.HomeTown = command[3];

                    students.Add(student);


                }
                command = Console.ReadLine().Split();
            }
            string cityName = Console.ReadLine();
            foreach (Student student in students)
            {
                if (student.HomeTown == cityName)
                {
                    Console.WriteLine($"{student.FirstName} {student.SecondName} is {student.Age} years old.");
                }
            }
        }
        static bool isStudentExists(List<Student> students, string FistName, string SecondName)
        {
            foreach (Student student in students)
            {
                if (student.FirstName == FistName && student.SecondName == SecondName)
                {
                    return true;
                }
            }
            return false;
        }
        //static bool IsStudentChange(List<Student> students, string FistName, string SecondName, bool penis)
        //{
        //    foreach (Student student in students)
        //    {
        //        if (student.FirstName == FistName && student.SecondName == SecondName)
        //        {
        //            students.Remove(student);
        //            return penis = true;
        //        }
        //    }
        //}
    }
}
