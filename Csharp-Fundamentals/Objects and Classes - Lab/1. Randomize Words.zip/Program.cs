﻿using System;
using System.Collections.Generic;

namespace _1._Randomize_Words
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] words = Console.ReadLine().Split(' ');
                Random penis = new Random();
            
            for (int i = 0; i < words.Length; i++)
            {
                int randomindex = penis.Next(0, words.Length);
                string word = words[i];
                words[i] = words[randomindex];
                word = words[randomindex];
            }
            foreach (string word in words)
            {
                Console.WriteLine(word);
            }
        }
    }
}
