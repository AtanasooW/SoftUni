﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _3._Legendary_Farming
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //•Shadowmourne - requires 250 Shards;
            //•	Valanyr - requires 250 Fragments;
            //•	Dragonwrath - requires 250 Motes
            Dictionary<string, int> keyMatirials = new Dictionary<string, int>();
            //keyMatirials.Add("shards", 0);
            //keyMatirials.Add("fragments", 0);
            //keyMatirials.Add("motes", 0);

            Dictionary<string, int> junk = new Dictionary<string, int>();
            string matirialToLower = string.Empty;
            bool flag = false;
            for (int i = 0; i < 58184181; i++)
            {
                List<string> list = Console.ReadLine().Split().ToList();
                for (int j = 0; j < list.Count - 1; j++)
                {
                    if (j + 1 % 2 != 0)
                    {
                        //matirial
                        matirialToLower = list[j + 1].ToLower();
                        if (matirialToLower == "shards")
                        {
                            if (keyMatirials.ContainsKey(matirialToLower))
                            {

                            }
                            else
                            {
                                keyMatirials.Add(matirialToLower, 0);
                            }
                        }
                        else if (matirialToLower == "fragments")
                        {
                            if (keyMatirials.ContainsKey(matirialToLower))
                            {

                            }
                            else
                            {
                                keyMatirials.Add(matirialToLower, 0);
                            }
                        }
                        else if (matirialToLower == "motes")
                        {
                            if (keyMatirials.ContainsKey(matirialToLower))
                            {

                            }
                            else
                            {
                                keyMatirials.Add(matirialToLower, 0);
                            }
                        }
                        else
                        {
                            if (junk.ContainsKey(matirialToLower))
                            {

                            }
                            else
                            {
                                junk.Add(matirialToLower, 0);
                            }
                        }
                    }
                    if (j % 2 == 0)
                    {
                        //quantity
                        if (matirialToLower == "shards" || matirialToLower == "fragments" || matirialToLower == "motes")
                        {
                            keyMatirials[matirialToLower] += int.Parse(list[j]);
                            if (keyMatirials[matirialToLower] >= 250)
                            {
                                flag = true;
                                break;
                            }
                        }
                        else
                        {
                            junk[matirialToLower] = int.Parse(list[j]);
                        }
                        
                        j++;
                    }
                }
                if (flag)
                {
                    break;
                }
            }
            if (keyMatirials.ContainsKey("fragments") == false)
            {
                keyMatirials.Add("fragments", 0);
            }
            if (flag)
            {
                switch (matirialToLower)
                {
                    case "shards":
                        Console.WriteLine("Shadowmourne obtained!");
                        break;
                    case "fragments":
                        Console.WriteLine("Valanyr obtained!");
                        break;
                    case "motes":
                        Console.WriteLine("Dragonwrath obtained!");
                        break;
                }
                keyMatirials[matirialToLower] -= 250;
                foreach (var goodStuff in keyMatirials)
                {
                    if (goodStuff.Key == "shards")
                    {
                    Console.WriteLine($"{goodStuff.Key}: {goodStuff.Value}");
                    }
                }
                foreach (var goodStuff in keyMatirials)
                {
                    if (goodStuff.Key == "motes")
                    {
                        Console.WriteLine($"{goodStuff.Key}: {goodStuff.Value}");
                    }

                }
                foreach (var goodStuff in keyMatirials)
                {
                    if (goodStuff.Key == "fragments")
                    {
                        Console.WriteLine($"{goodStuff.Key}: {goodStuff.Value}");
                    }

                }
                foreach (var junkItems in junk)
                {
                    Console.WriteLine($"{junkItems.Key}: {junkItems.Value}");
                }
            }
        }
    }
}
