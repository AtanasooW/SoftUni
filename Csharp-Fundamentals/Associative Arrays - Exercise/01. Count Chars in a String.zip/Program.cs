﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace _01._Count_Chars_in_a_String
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string word = Console.ReadLine();
            char[] wordButInChar = word.ToCharArray();
            Dictionary<char, int> finalNums = new Dictionary<char, int>();
            foreach (char count in wordButInChar)
            {
                if (count != ' ')
                {
                    if (finalNums.ContainsKey(count))
                    {
                        finalNums[count]++;
                    }
                    else
                    {
                        finalNums.Add(count, 1);
                    }
                }
            }
            foreach (var chars in finalNums)
            {
                Console.WriteLine($"{chars.Key} -> {chars.Value}");
            }
        }
    }
}
