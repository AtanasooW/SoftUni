﻿using System;
using System.Collections.Generic;

namespace _2._A_Miner_Task
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string command = Console.ReadLine();
            Dictionary<string, int> resources = new Dictionary<string, int>();
            int i = 1;
            while (command != "stop")
            {
                if (resources.ContainsKey(command))
                {
                    int quantity = int.Parse(Console.ReadLine());
                    resources[command] += quantity;
                }
                else
                {

                    int quantity = int.Parse(Console.ReadLine());
                    resources.Add(command, quantity);
                }
                command = Console.ReadLine();
            }
            foreach (var resource in resources)
            {
                Console.WriteLine($"{resource.Key} -> {resource.Value}");
            }
        }
    }
}
