﻿using System;
using System.Collections.Generic;

namespace _07_Student_Academy
{
    class Student
    {
        public double Grade { get; set; }
        public int Counter { get; set; }
        public Student(double grade)
        {

            this.Grade = grade;
            this.Counter++;
        }
        public void AddGrade(double grade)
        {
            this.Grade += grade;
            this.Counter++;
        }
        public double AverageGrade()
        {
            return this.Grade / this.Counter;
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            Dictionary<string, Student> dic = new Dictionary<string, Student>();
            for (int i = 0; i < n; i++)
            {
                string name = Console.ReadLine();
                double grade = double.Parse(Console.ReadLine());
                if (!dic.ContainsKey(name))
                {
                    Student student = new Student(grade);
                    dic.Add(name, student);
                }
                else
                {
                    Student curItem = dic[name];
                    curItem.AddGrade(grade);
                }
            }
            Dictionary<string, double> final = new Dictionary<string, double>();
            foreach (var item in dic)
            {
                if (item.Value.AverageGrade() >= 4.5)
                {
                    final.Add(item.Key, item.Value.AverageGrade());
                }
            }
            foreach (var grade in final)
            {
                Console.WriteLine($"{grade.Key} -> {grade.Value:F2}");
            }
        }
    }
}
