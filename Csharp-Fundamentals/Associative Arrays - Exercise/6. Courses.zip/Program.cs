﻿using System;
using System.Collections.Generic;

namespace _6._Courses
{
    class Courses
    {
        public string NameOfCourse { get; set; }
        public string NameOfStudent { get; set; }
        public Courses(string nameOfCourse, string nameOfStudent)
        {
            NameOfCourse = nameOfCourse;
            NameOfStudent = nameOfStudent;
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, List<string>> dic = new Dictionary<string, List<string>>();
            string[] command = Console.ReadLine().Split(" : ");
            while (command[0] != "end")
            {
                if (dic.ContainsKey(command[0]))
                {
                    dic[command[0]].Add(command[1]);
                }
                else
                {
                    List<string> list = new List<string>();
                    list.Add(command[1]);
                dic.Add(command[0], list);
                }

                command = Console.ReadLine().Split(" : ");
            }
            foreach (var item in dic)
            {
                Console.WriteLine($"{item.Key}: {item.Value.Count}");
               
                foreach (var penq in item.Value)
                {
                    Console.WriteLine($"-- {penq}");
                }
            }
        }
    }
}
