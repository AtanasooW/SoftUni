﻿using System;
using System.Collections.Generic;

namespace _8._Company_Users
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] command = Console.ReadLine().Split(" -> ");
            bool isItHere = false;
            Dictionary<string, List<string>> dic = new Dictionary<string, List<string>>();
            while (command[0] != "End")
            {
                if (!dic.ContainsKey(command[0]))
                {
             
                    List<string> list = new List<string>();
                    list.Add(command[1]);
                    dic.Add(command[0], list);
                }
                else
                {
                    foreach (var item in dic)
                    {
                        if (item.Value.Contains(command[1]))
                        {
                            isItHere = true;
                        }
                    }
                    if (isItHere)
                    {

                    }
                    else
                    {
                    dic[command[0]].Add(command[1]);
                    }
                }
                isItHere = false;
                command = Console.ReadLine().Split(" -> ");
            }
            foreach (var item in dic)
            {
                Console.WriteLine(item.Key);
                foreach (var penq in item.Value)
                {
                    Console.WriteLine($"-- {penq}");
                }
            }
        }
    }
}
