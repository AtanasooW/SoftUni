﻿using System;

namespace Multiplication_Table_2._0
{
    class Program
    {
        static void Main(string[] args)
        {
            int number = int.Parse(Console.ReadLine());
            int number2 = int.Parse(Console.ReadLine());
            if (number2 > 10)
            {
                Console.WriteLine($"{number} X {number2} = {number * number2}");
                return;
            }
            else
            {
                for (int i = number2; i <= 10; i++)
                {
                    Console.WriteLine($"{number} X {i} = {number * i}");
                }
            }
        }
    }
}
