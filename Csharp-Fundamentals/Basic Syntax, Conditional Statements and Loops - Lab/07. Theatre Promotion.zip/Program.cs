﻿using System;

namespace Theatre_Promotion
{
    class Program
    {
        static void Main(string[] args)
        {
            // Day / Age   0 <= age <= 18  18 < age <= 64  64 < age <= 122
            //Weekday           12$	            18$	            12$
            //Weekend           15$	            20$	            15$
            //Holiday           5$	            12$	            10$

            string typeOfDay = Console.ReadLine();
            int age = int.Parse(Console.ReadLine());
            double price = 0;
            if (0 <= age && age <= 18)
            {
                if (typeOfDay == "Weekday")
                {
                    price = 12;
                }
                if (typeOfDay == "Weekend")
                {
                    price = 15;
                }
                if (typeOfDay == "Holiday")
                {
                    price = 5;
                }
                Console.WriteLine($"{price}$");
            }
            else if (18 < age && age <= 64)
            {
                if (typeOfDay == "Weekday")
                {
                    price = 18;
                }
                if (typeOfDay == "Weekend")
                {
                    price = 20;
                }
                if (typeOfDay == "Holiday")
                {
                    price = 12;
                }
                Console.WriteLine($"{price}$");
            }
            else if (64 < age && age <= 122)
            {
                if (typeOfDay == "Weekday")
                {
                    price = 12;
                }
                if (typeOfDay == "Weekend")
                {
                    price = 15;
                }
                if (typeOfDay == "Holiday")
                {
                    price = 10;
                }
                Console.WriteLine($"{price}$");
            }
            else
            {
                Console.WriteLine("Error!");
            }
        }
    }
}
