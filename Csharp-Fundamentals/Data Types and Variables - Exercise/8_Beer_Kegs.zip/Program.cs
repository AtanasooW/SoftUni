﻿using System;

namespace _8_Beer_Kegs
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            double sum = 0;
            double maxvalue = int.MinValue;
            string penis = string.Empty;
            string name = string.Empty;


            for (int k = 0; k < n; k++)
            {
                name = Console.ReadLine();
                double radius = double.Parse(Console.ReadLine());
                double height = double.Parse(Console.ReadLine());
                sum = Math.PI * (radius * radius) * height;
                if (maxvalue < sum)
                {
                    maxvalue = sum;
                    penis = name;
                }
            }

            Console.WriteLine(penis);
        }
    }
}
