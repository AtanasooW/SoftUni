﻿using System;

namespace _05_Print_Part_Of_ASCII_Table
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int firstInput = int.Parse(Console.ReadLine());
            int secondInput = int.Parse(Console.ReadLine());
            for (int i = firstInput; i <= secondInput; i++)
            {
                char currnetchar = (char)i;
                Console.Write($"{currnetchar} ");
            }
        }
    }
}
