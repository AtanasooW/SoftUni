﻿using System;

namespace _01_nteger_Operations
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num1 = int.Parse(Console.ReadLine());
            int num2 = int.Parse(Console.ReadLine());
            int num3 = int.Parse(Console.ReadLine());
            int num4 = int.Parse(Console.ReadLine());
            int sum = num1 + num2;
            int sum2 = sum / num3;
            int sum3 = sum2 * num4;
            Console.WriteLine(sum3);
        }
    }
}
