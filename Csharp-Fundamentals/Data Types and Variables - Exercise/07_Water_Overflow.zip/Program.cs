﻿using System;

namespace _07_Water_Overflow
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int penis = int.Parse(Console.ReadLine());
            int sum = 0;
            int litersInTheTank = 255;
            for (int i = 0; i < penis; i++)
            {
                int currnetLiter = int.Parse(Console.ReadLine());
                sum += currnetLiter;
                if (sum > litersInTheTank)
                {
                    sum -= currnetLiter;
                    Console.WriteLine("Insufficient capacity!");
                }

            }
            Console.WriteLine(sum);
        }
    }
}
