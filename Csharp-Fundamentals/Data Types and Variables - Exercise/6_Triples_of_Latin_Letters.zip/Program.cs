﻿using System;

namespace _6_Triples_of_Latin_Letters
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    for (int k = 0; k < n; k++)
                    {
                        int first = 97 + i;
                        int second = 97 + j;
                        int third = 97 + k;

                        char firstchar = (char)first;
                        char secondchar = (char)second;
                        char thirdchar = (char)third;
                        Console.WriteLine($"{firstchar}{secondchar}{thirdchar}");
                    }
                }
            }
        }
    }
}
