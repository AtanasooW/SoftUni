﻿using System;

namespace _6._Middle_Characters
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string word = Console.ReadLine();
            PrintTheMiddleChar(word);
        }
        static void PrintTheMiddleChar(string word)
        {
            char[] chars = word.ToCharArray();
            char fistOne = ' ';
            char socondOne = ' ';
            int counter = 0;
            if (word.Length % 2 == 0)
            {
                for (int i = word.Length / 2; i > 0; i--)
                {
                    if (counter == 2)
                    {
                        break;
                    }
                    if (counter == 0)
                    {
                        fistOne = chars[i];
                    }
                    else if (counter == 1)
                    {
                        socondOne = chars[i];
                    }
                    counter++;
                }
                    Console.Write(socondOne);
                Console.Write(fistOne);
            }
            else if (word.Length % 2 != 0)
            {
                for (int i = word.Length / 2; i > 0; i--)
                {
                    Console.WriteLine(chars[i]);
                    break;
                }
            }
        }
    }
}
