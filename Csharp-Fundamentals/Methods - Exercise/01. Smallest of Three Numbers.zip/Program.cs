﻿using System;
using System.Linq;

namespace _01._Smallest_of_Three_Numbers
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num = int.Parse(Console.ReadLine());
            int num1 = int.Parse(Console.ReadLine());
            int num2 = int.Parse(Console.ReadLine());
            int[] penis = new int[3];
            penis[0] = num;
            penis[1] = num1;
            penis[2] = num2;
            Console.WriteLine(penis.Min());
        }
    }
}
