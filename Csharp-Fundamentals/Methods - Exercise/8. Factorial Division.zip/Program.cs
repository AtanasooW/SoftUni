﻿using System;

namespace _8._Factorial_Division
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num = int.Parse(Console.ReadLine());
            int num1 = int.Parse(Console.ReadLine());
            PrintTheResult(num, num1);
        }
        static void PrintTheResult(int num, int num1)
        {
            int firstSum = 1;
            int SecondSum = 1;
            for (int i = num; i >= 1; i--)
            {
            firstSum *= i;
            }
            for (int i = num1; i >= 1; i--)
            {
            SecondSum *= i;

            }
            Console.WriteLine($"{(firstSum / SecondSum):F2}");
        }
    }
}
