﻿using System;

namespace _5._Add_and_Subtract
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num = int.Parse(Console.ReadLine());
            int num1 = int.Parse(Console.ReadLine());
            int num2 = int.Parse(Console.ReadLine());
            int sum = SumTheFirstTwo(num, num1);
            Console.WriteLine(Subtract(sum, num2));
        }
        static int SumTheFirstTwo(int num, int num1)
        {
            return num + num1;
        }
        static int Subtract(int sum, int num2)
        {
            return sum - num2;
        }
    }
}
