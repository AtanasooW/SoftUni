﻿using System;
using System.Linq;
namespace _2._Vowels_Count
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string word = Console.ReadLine();
            ChekHowManyVowels(word);
        }
        static void ChekHowManyVowels(string word)
        {
            int counter = 0;
            for (int i = 0; i < word.Length; i++)
            {
                char[] penq = word.ToCharArray();
              
                switch (penq[i])
                {
                    case 'a':
                    case 'e':
                    case 'i':
                    case 'o':
                    case 'u':
                    case 'A':
                    case 'E':
                    case 'I':
                    case 'O':
                    case 'U':
                        counter++;
                        break;
                }

            }
            Console.WriteLine(counter);
        }
    }
}
