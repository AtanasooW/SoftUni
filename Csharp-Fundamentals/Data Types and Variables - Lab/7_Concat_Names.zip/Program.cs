﻿using System;

namespace _7_Concat_Names
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string name1 = Console.ReadLine();
            string name2 = Console.ReadLine();
            var znak = Console.ReadLine();
            Console.WriteLine(name1 + znak + name2);
        }
    }
}
