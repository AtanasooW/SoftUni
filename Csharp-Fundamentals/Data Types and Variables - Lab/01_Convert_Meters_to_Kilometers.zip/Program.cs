﻿using System;

namespace _01_Convert_Meters_to_Kilometers
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int meters = int.Parse(Console.ReadLine());
            decimal km = (decimal)meters / 1000;
            Console.WriteLine($"{km:F2}");
        }
    }
}
