﻿using System;

namespace _02._Pounds_to_Dollars
{
    internal class Program
    {
        static void Main(string[] args)
        {
            decimal british_Pound = decimal.Parse(Console.ReadLine());
            decimal dolar = british_Pound * (decimal)1.31;
            Console.WriteLine($"{dolar:F3}");
        }
    }
}
