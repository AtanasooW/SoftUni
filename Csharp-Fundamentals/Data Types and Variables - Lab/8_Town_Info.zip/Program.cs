﻿using System;

namespace _8_Town_Info
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string cityName = Console.ReadLine();
            int polulation = int.Parse(Console.ReadLine());
            int squareKm = int.Parse(Console.ReadLine());
            Console.WriteLine($"Town {cityName} has population of {polulation} and area {squareKm} square km.");
        }
    }
}
