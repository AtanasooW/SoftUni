﻿using System;

namespace _2_Divison
{
    class Program
    {
        static void Main(string[] args)
        {
            int input = int.Parse(Console.ReadLine());
            int divedednum = -1;
            if (input % 10 == 0)
            {
                divedednum = 10;
            }
            else if (input % 7 == 0)
            {
                divedednum = 7;
            }
            else if (input % 6 == 0)
            {
                divedednum = 6;
            }
            else if (input % 3 == 0)
            {
                divedednum = 3;
            }
            else if (input % 2 == 0)
            {
                divedednum = 2;
            }
            if (divedednum == -1)
            {
                Console.WriteLine("Not divisible");
            }
            else
            {
                Console.WriteLine($"The number is divisible by {divedednum}");
            }
        }
    }
}
