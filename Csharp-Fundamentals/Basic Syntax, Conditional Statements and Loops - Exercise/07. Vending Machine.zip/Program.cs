﻿using System;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            double sum = 0;
            double price = 0;
            string product = string.Empty;
            bool penis = true;
            bool penq = true;
            while (input != "Start")
            {
                double currnetCoin = double.Parse(input);
                if (currnetCoin == 0.1 || currnetCoin == 0.2 || currnetCoin == 0.5 || currnetCoin == 1 || currnetCoin == 2)
                {
                    sum += currnetCoin;
                }
                else
                {
                    Console.WriteLine($"Cannot accept {currnetCoin}");
                }
                input = Console.ReadLine();
            }
            while (input != "End")
            {
                input = Console.ReadLine();
                string currnetProduct = (input);
                switch (currnetProduct)
                {
                    case "Nuts":
                        price = 2;
                        sum -= price;
                        product = "nuts";
                        break;
                    case "Water":
                        price = 0.7;
                        sum -= price;
                        product = "water";
                        break;
                    case "Crisps":
                        price = 1.5;
                        sum -= price;
                        product = "crisps";
                        break;
                    case "Soda":
                        price = 0.8;
                        sum -= price;
                        product = "soda";
                        break;
                    case "Coke":
                        price = 1;
                        sum -= price;
                        product = "coke";
                        break;
                    case "End":
                        penis = false;
                        break;
                    default:
                        Console.WriteLine("Invalid product");
                        penq = false;
                        break;
                }
                if (penis)
                {
                    if (sum < 0)
                    {
                        sum += price;
                        Console.WriteLine("Sorry, not enough money");
                    }
                    else
                    {
                        if (penis = false)
                        {
                            Console.WriteLine($"Purchased {product}");
                        }
                       
                    }
                }
            }
                    Console.WriteLine($"Change: {sum:F2}");
        }
    }
}
