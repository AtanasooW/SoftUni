﻿using System;

namespace _5_Login
{
    class Program
    {
        static void Main(string[] args)
        {
            string username = Console.ReadLine();
            string password = string.Empty;
            bool isItTheSame = false;
            int counter = 0;
            for (int revurse = username.Length - 1; revurse >= 0; revurse--)
            {
                password += username[revurse];
            }
            for (int i = 1; i <= 4; i++)
            {
                string currentPass = Console.ReadLine();
                counter++;
                if (currentPass == password)
                {
                    isItTheSame = true;
                    break;
                }
                else if (currentPass != password)
                {
                    if (counter == 4)
                    {
                        break;
                    }
                    Console.WriteLine("Incorrect password. Try again.");
                }
            }
            if (isItTheSame)
            {
                Console.WriteLine($"User {username} logged in.");
            }
            else
            {
                Console.WriteLine($"User {username} blocked!");
            }
        }
    }
}
