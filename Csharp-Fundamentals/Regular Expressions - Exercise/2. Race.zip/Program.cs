﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace _2._Race
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] names = Console.ReadLine().Split(", ");
            string command = Console.ReadLine();
            int sum = 0;
            Dictionary<string, List<int>> racers = new Dictionary<string, List<int>>();
            while (command != "end of race")
            {
                //surch the name in the shit
                string regexName = string.Empty;
                for (int i = 0; i < command.Length; i++)
                {
                    if (Char.IsLetter(command[i]))
                    {
                        regexName += command[i];
                    }
                }
                for (int i = 0; i < names.Length; i++)
                {
                    if (regexName == names[i])
                    {
                        string patern = @"\d";
                        MatchCollection maches = Regex.Matches(command, patern);
                        List<string> list = new List<string>();

                        for (int j = 0; j < maches.Count; j++)
                        {

                        }
                    }
                }
            }
        }
    }
}
