﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace _01._Furniture
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string patern = @">>([A-Za-z]{2,})<<(\d+(.\d+)?)!(\d+)";
            string command = Console.ReadLine();
            double totalSum = 0;
            List<string> names = new List<string>();
            while (command != "Purchase")
            {
                Match maches = Regex.Match(command, patern);
                if (maches.Success)
                {
                    string name = maches.Groups[1].Value;
                    double price = double.Parse(maches.Groups[2].Value);
                    double quantity = double.Parse(maches.Groups[4].Value);
                    names.Add(name);
                    totalSum += price * quantity;
                }
                command = Console.ReadLine();
            }

            Console.WriteLine("Bought furniture:");
            foreach (var name in names)
            {
                Console.WriteLine(name);
            }
            Console.WriteLine($"Total money spend: {totalSum:F2}");
        }
    }
}
