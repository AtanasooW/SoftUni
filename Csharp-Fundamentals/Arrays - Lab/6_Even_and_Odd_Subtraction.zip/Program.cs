﻿using System;
using System.Linq;

namespace _6_Even_and_Odd_Subtraction
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] nums = Console.ReadLine()
                .Split()
                .Select(int.Parse)
                .ToArray();
            int evensum = 0;
            int oddsum = 0;
            for (int i = 0; i < nums.Length; i++)
            {
                if (nums[i] % 2 == 0)
                {
                    evensum += nums[i];
                }
                else
                {
                    oddsum += nums[i];
                }
            }
            Console.WriteLine(evensum - oddsum);
        }
    }
}
