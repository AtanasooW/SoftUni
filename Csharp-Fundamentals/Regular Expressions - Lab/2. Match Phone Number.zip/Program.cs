﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace _2._Match_Phone_Number
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string patern = @"\+359( |-)2\1\d{3}\1\d{4}\b";
            string phone = Console.ReadLine();
            MatchCollection maches = Regex.Matches(phone, patern);
            List<string> final = new List<string>(); 
            foreach (Match item in maches)
            {
                final.Add(item.Value);
            }
            Console.WriteLine(String.Join(", ", final));
        }
    }
}
