﻿using System;
using System.Text.RegularExpressions;

namespace _01._Match_Full_Name
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string patern = @"\b([A-Z][a-z]{1,}) [A-Z][a-z]{1,}\b";
            string names = Console.ReadLine();
            MatchCollection maches = Regex.Matches(names, patern);
            foreach (Match item in maches)
            {
                Console.Write($"{item} ");
            }
        }
    }
}
