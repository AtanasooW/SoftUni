﻿using System;
using System.Text.RegularExpressions;

namespace _3._Match_Dates
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string patern = @"\b(\d{2})(.|-|\/)([A-Z][a-z]{2})\2(\d{4})\b";
            string dates = Console.ReadLine();
            MatchCollection maches = Regex.Matches(dates, patern);
            foreach (Match item in maches)
            {
                string day = item.Groups[1].Value;
                string month = item.Groups[3].Value;
                string year = item.Groups[4].Value;
                Console.WriteLine($"Day: {day}, Month: {month}, Year: {year}");
            }
           
        }
    }
}
