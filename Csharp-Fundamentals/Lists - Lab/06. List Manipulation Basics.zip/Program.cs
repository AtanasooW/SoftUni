﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _06._List_Manipulation_Basics
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> num = Console.ReadLine()
          .Split(' ')
          .Select(int.Parse)
          .ToList();
            string command = string.Empty;
            while ((command = Console.ReadLine()) != "end")
            {
                string[] token = command.Split(' ');
                string action = token[0];
                switch (action)
                {
                    case "Add":
                        int num1 = int.Parse(token[1]);
                        num.Add(num1);
                        break;
                    case "Remove":
                        int num2 = int.Parse(token[1]); 
                        num.Remove(num2);
                        break;
                    case "RemoveAt":
                        int num3 = int.Parse(token[1]);
                        num.RemoveAt(num3);
                        break;
                    case "Insert":
                        int num4 = int.Parse(token[1]);
                        int num5 = int.Parse(token[2]);
                        num.Insert(num5, num4);
                        break;
                }
                
            }
            Console.WriteLine(String.Join(" ", num));
        }
    }
}
