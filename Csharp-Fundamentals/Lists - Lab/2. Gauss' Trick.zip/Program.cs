﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _2._Gauss__Trick
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> num = Console.ReadLine()
                .Split(' ')
                .Select(int.Parse)
                .ToList();
            int penis = num.Count;
            for (int i = 0; i < penis / 2 ; i++)
            {
               
                    num[i] += num[num.Count - 1]; 
                    num.RemoveAt(num.Count - 1);
            }
            Console.WriteLine(String.Join(" ", num));
        }
    }
}
