﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _4._List_of_Products
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num = int.Parse(Console.ReadLine());
            List<string> products = new List<string>();
            for (int i = 0; i < num; i++)
            {
                string currnetProduct = Console.ReadLine();
                products.Add(currnetProduct);
            }
            products.Sort();
            for (int i = 0; i < num; i++)
            {
                Console.WriteLine($"{i + 1}.{products[i]}");
            }
        }
    }
}
