﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Meging_Lists
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> num = Console.ReadLine()
      .Split(' ')
      .Select(int.Parse)
      .ToList();
            List<int> num2 = Console.ReadLine()
    .Split(' ')
    .Select(int.Parse)
    .ToList();
            List<int> merge = new List<int>();
            int biggerList = Math.Max(num.Count, num2.Count);
            for (int i = 0; i < biggerList; i++)
            {
                if (i < num.Count) 
                {
                    merge.Add(num[i]);
                }
                if (i < num2.Count)
                {
                    merge.Add(num2[i]);
                }
            }
            Console.WriteLine(String.Join(" ", merge));
        }
    }
}
