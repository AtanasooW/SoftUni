﻿using System;

namespace _2.__Character_Multiplier
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] words = Console.ReadLine().Split(' ');
            int totalSum = 0;
            int counterFirst = 0;
            int counterSecond = 0;
                    char[] firstWord = words[0].ToCharArray();
                    char[] secondWord = words[1].ToCharArray();
                    counterSecond = secondWord.Length;
                    counterFirst = firstWord.Length;
            if (words[0].Length >= words[1].Length)
            {
                for (int i = 0; i < words[0].Length; i++)
                {
                    if (counterSecond != 0)
                    {
                        totalSum += firstWord[i] * secondWord[i];
                        counterSecond--;
                    }
                    else
                    {
                        totalSum += firstWord[i];   
                    }
                }
            }
            else if (words[0].Length < words[1].Length)
            {
                for (int i = 0; i < words[1].Length; i++)
                {
                    if (counterFirst != 0)
                    {
                        totalSum += firstWord[i] * secondWord[i];
                        counterFirst--;
                        
                    }
                    else
                    {
                        totalSum += secondWord[i];
                    }
                }
            }
            Console.WriteLine(totalSum);
        }
    }
}
