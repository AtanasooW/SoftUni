﻿using System;

namespace _3.__Extract_File
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string file = Console.ReadLine();
            
            int index = file.LastIndexOf('\\');
            string fullFile = file.Substring(index + 1);
            string fileName = fullFile.Substring(0, fullFile.LastIndexOf('.'));
            string extension = fullFile.Substring(fullFile.LastIndexOf('.') + 1);
            Console.WriteLine($"File name: {fileName}");
            Console.WriteLine($"File extension: {extension}");
        }
    }
}
