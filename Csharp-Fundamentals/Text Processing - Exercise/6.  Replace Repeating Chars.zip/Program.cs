﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _6.__Replace_Repeating_Chars
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string word = Console.ReadLine();
            //StringBuilder output = new StringBuilder();
            List<char> penq = new List<char>();
            for (int i = 1; i < word.Length; i++)
            {
                if (i == 1)
                {
                    //output.Append(word[i]);
                    penq.Add(word[0]);
                }
                if (word[i] != word[i - 1])
                {
                    //output.Append(word[i]);
                    penq.Add(word[i]);
                }
            }
            Console.WriteLine(String.Join("", penq));
            //Console.WriteLine(output.ToString());
        }
    }
}
