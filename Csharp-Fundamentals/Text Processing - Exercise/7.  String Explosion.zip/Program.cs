﻿using System;
using System.Text;

namespace _7.__String_Explosion
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string text = Console.ReadLine();
            StringBuilder output = new StringBuilder();
            int bombPower = 0;
            for (int i = 0; i < text.Length; i++)
            {
                if (text[i] == '>')
                {
                    bombPower += (int)text[i + 1] - 48; 
                    output.Append(text[i]);
                }
                else 
                {
                    if (bombPower > 0)
                    {
                        bombPower--;
                    }
                    else
                    {
                        output.Append(text[i]);
                    }
                }
            }
            Console.WriteLine(output.ToString());
        }
    }
}
