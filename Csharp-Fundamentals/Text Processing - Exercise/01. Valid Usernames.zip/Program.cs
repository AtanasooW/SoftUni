﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01._Valid_Usernames
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] words = Console.ReadLine().Split(", ");
            List<string> final = new List<string>();
            bool flag = true;
            foreach (var item in words)
            {
                flag = true;
                if (item.Length > 3 && item.Length < 16)
                {

                    for (int i = 0; i < item.Length; i++)
                    {
                        if (Char.IsDigit(item[i]) || item[i] == '_' || item[i] == '-')
                        {

                        }
                        else if (Char.IsLetter(item[i]))
                        {

                        }
                        else
                        {
                            flag = false;
                        }
                    }
                    if (flag)
                    {
                        final.Add(item);
                    }
                }
            }
            foreach (var item in final)
            {
                Console.WriteLine(item);
            }
        }
    }
}
