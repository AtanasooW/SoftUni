﻿using System;

namespace _4.__Caesar_Cipher
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            for (int i = 0; i < input.Length; i++)
            {
                int curChar = input[i];
                curChar += 3;
                Console.Write((char)curChar);
            }
        }
    }
}
