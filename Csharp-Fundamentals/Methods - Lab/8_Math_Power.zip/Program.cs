﻿using System;

namespace _8_Math_Power
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num1 = int.Parse(Console.ReadLine());
            int num2 = int.Parse(Console.ReadLine());
            Console.WriteLine(PrintTheMyltiplyNum(num1, num2));
        }
        static int PrintTheMyltiplyNum(int num1, int num2)
        {
            int sum = 1;  
            for (int i = 1; i <= num2; i++)
            {
                sum *= num1;
            }
            return sum;
        }
    }
}
