﻿using System;

namespace _9_Greater_of_Two_Values
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string type = Console.ReadLine();
            if (type == "string")
            {
                string firststring = Console.ReadLine();
                string secondstring = Console.ReadLine();
                Console.WriteLine(GetMax(firststring, secondstring));
            }
            else if (type == "int")
            {
                int num1 = int.Parse(Console.ReadLine());
                int num2 = int.Parse(Console.ReadLine());
                Console.WriteLine(GetMax(num1, num2));
            }
            else if (type == "char")
            {
                char firstchar = char.Parse(Console.ReadLine());
                char secondchar = char.Parse(Console.ReadLine());
                Console.WriteLine(GetMax(firstchar, secondchar));
            }
        }
        static string GetMax(string firststring, string secondstring)
        {
            if (firststring.CompareTo(secondstring) > 0)
            {
                return firststring;
            }
            else
            {
                return secondstring;
            }
        }
        static int GetMax(int num1, int num2)
        {
            if (num1 > num2) 
            {
                return num1;
            }
            else
            {
                return num2;
            }
        }
        static char GetMax(char firstchar, char secondchar)
        {
            if (firstchar.CompareTo(secondchar) > 0) 
            {
                return firstchar;
            }
            else
            {
                return secondchar;
            }
        }
    }
}
