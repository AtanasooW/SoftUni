﻿using System;

namespace _6_Calculate_Rectangle_Area
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double num1 = double.Parse(Console.ReadLine());
            double num2 = double.Parse(Console.ReadLine());
            Console.WriteLine(PrintArea(num1, num2));
        }
        static double PrintArea(double num1, double num2)
        {
            return num1 * num2;
        }
    }
}
