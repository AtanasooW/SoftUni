﻿
using System;

namespace _3_Calculations
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string calculation = Console.ReadLine();
            int num1 = int.Parse(Console.ReadLine());
            int num2 = int.Parse(Console.ReadLine());
            if (calculation == "add")
            {
                PrintAdd(num1, num2);
            }
            else if (calculation == "multiply")
            {
                PrintMultiply(num1, num2);
            }
            else if (calculation == "divide")
            {
                PrintDevide(num1, num2);
            }
            else if (calculation == "subtract")
            {
                PrintSubtract(num1, num2);
            }

        }
        static void PrintAdd(int num1, int num2)
        {
            Console.WriteLine(num1 + num2); 
        }
        static void PrintMultiply(int num1, int num2)
        {
            Console.WriteLine(num1 * num2);
        }
        static void PrintSubtract(int num1, int num2)
        {
            Console.WriteLine(num1 - num2);
        }
        static void PrintDevide(int num1, int num2)
        {
            Console.WriteLine(num1 / num2);
        }
    }
}
