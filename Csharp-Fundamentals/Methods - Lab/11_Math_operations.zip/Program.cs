﻿using System;

namespace _11_Math_operations
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num1 = int.Parse(Console.ReadLine());
            char char1 = char.Parse(Console.ReadLine());
            int num2 = int.Parse(Console.ReadLine());
            if (char1 == '*')
            {
                Console.WriteLine(GetMultiply(num1, num2));

            }
            else if (char1 == '/')
            {
                Console.WriteLine(GetDivide(num1, num2));
                    }
            else if (char1 == '+')
            {
                Console.WriteLine(GetAdd(num1, num2));
            }
            else if (char1 == '-')
            {
                Console.WriteLine(GetOut(num1, num2));
            }
        }
        static int GetMultiply(int num1, int num2)
        {
            return num1 * num2;
        }
        static int GetDivide(int num1, int num2)
        {
            return num1 / num2;
        }
        static int GetAdd(int num1, int num2)
        {
           return num1 + num2;
        }
        static int GetOut(int num1, int num2)
        {
            return num1 - num2;
        }
    }
}
