﻿using System;

namespace _5_Orders
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string typeOfProduct = Console.ReadLine();
            int quantity = int.Parse(Console.ReadLine());
            if (typeOfProduct == "coffee")
            {
                PrintCoffee(quantity);
            }
            else if (typeOfProduct == "water")
            {
                PrintWater(quantity);
            }
            else if (typeOfProduct == "coke")
            {
                PrintCoke(quantity);
            }
            else if (typeOfProduct == "snacks")
            {
                PrintSnacks(quantity);
            }
        }
        static void PrintCoffee(int quantity)
        {
            Console.WriteLine($"{(quantity * 1.5):F2}");
        }
        static void PrintWater(int quantity)
        {
            Console.WriteLine($"{(quantity * 1):F2}");
        }
        static void PrintCoke(int quantity)
        {
            Console.WriteLine($"{(quantity * 1.4):F2}");
        }
        static void PrintSnacks(int quantity)
        {
            Console.WriteLine($"{(quantity * 2):F2}");
        }
    }
}
