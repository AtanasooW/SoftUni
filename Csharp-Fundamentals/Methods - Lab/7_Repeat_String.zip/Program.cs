﻿using System;
using System.Text;

namespace _7_Repeat_String
{
    internal class Program
    {
        static void Main(string[] args)
        {
           string text = Console.ReadLine();
            int counter = int.Parse(Console.ReadLine());
            Console.WriteLine(PrintTheText(text, counter));
        }
        static string PrintTheText(string text, int counter)
        {
            StringBuilder mytext = new StringBuilder();
            for (int i = 0; i < counter; i++)
            {
                mytext.Append(text);
            }
            return mytext.ToString();
        }
    }
}
