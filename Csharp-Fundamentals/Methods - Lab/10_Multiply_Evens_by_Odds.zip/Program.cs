﻿using System;
using System.Linq;

namespace _10_Multiply_Evens_by_Odds
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num = Math.Abs(int.Parse(Console.ReadLine()));
            Console.WriteLine(GetMultipleOfEvenAndOdds(num));
        }
        static int GetSumOfEvenDigitis(int num)
        {
            int sum = 0;
            int digit = 0;
            while (num > 0)
            {
                digit = num % 10;
                num /= 10;
                if (digit % 2 == 0)
                {
                    sum += digit;
                }
            }
            return sum;
        }
        static int GetSumOfOddDigits(int num) 
        {
            int sum = 0;
            int digit = 0;
            while (num > 0)
            {
                digit = num % 10;
                num /= 10;
                if (digit % 2 != 0)
                {
                    sum += digit;
                }
            }
                        return sum;

        }
        static int GetMultipleOfEvenAndOdds(int sum)
        {
            return GetSumOfOddDigits(sum) * GetSumOfEvenDigitis(sum);
        }
    }
}
