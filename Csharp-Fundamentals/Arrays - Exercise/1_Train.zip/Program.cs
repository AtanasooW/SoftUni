﻿using System;

namespace _1_Train
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int[] nums = new int[n];
            int sum = 0;
            for (int i = 0; i < n; i++)
            {
                nums[i] = int.Parse(Console.ReadLine());
                sum += nums[i];

            }
            Console.WriteLine(String.Join(" ", nums));
            Console.WriteLine(sum);
        }
    }
}
