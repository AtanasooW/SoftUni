﻿using System;
using System.Linq;
namespace _2_Common_Elements
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] arry = Console.ReadLine().Split(' ');
            string[] arry2 = Console.ReadLine().Split(' ');
            string penis = "";
            for (int i = 0; i < arry2.Length; i++)
            {
                for (int k = 0; k < arry.Length; k++)
                {
                    if (arry2[i] == arry[k])
                    {
                        penis += $"{arry[k]} ";
                    }
                }
            }
            Console.WriteLine(penis);
        }
    }
}
