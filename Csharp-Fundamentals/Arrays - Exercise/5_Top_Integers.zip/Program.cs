﻿using System;
using System.Linq;

namespace _5_Top_Integers
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] arry = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
            int[] greatnum = new int[arry.Length];
            int topIndex = 0;
            bool isItGreatNum = true;
            for (int i = 0; i < arry.Length ; i++)
            {
                    isItGreatNum = true;
                for (int j = i + 1; j < arry.Length; j++)
                {
                    if (arry[j] >= arry[i])
                    {
                        isItGreatNum = false;
                        break;
                    } 
                }
                if (isItGreatNum)
                {
                    greatnum[topIndex] += arry[i];
                    topIndex++;
                }
            }
            for (int i = 0; i < topIndex; i++)
            {
                Console.Write($"{greatnum[i]} ");
            }
        }
    }
}
