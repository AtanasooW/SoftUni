﻿using System;
using System.Linq;

namespace _06._Equal_Sum
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] array = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();
            int leftsum = 0;
            int rightsum = 0;
            bool iseven = false;

            for (int i = 0; i < array.Length; i++)
            {
                int currentnum = array[i];
                for (int left = i; left >= 0; left--)
                {
                    leftsum += array[left];
                }
                for (int right = i; right <= array.Length - 1; right++)
                {
                    rightsum += array[right];
                }
                if (leftsum == rightsum)
                {
                    iseven = true;
                    Console.WriteLine(i);
                    break;
                }
                leftsum = 0;
                rightsum = 0;
            }
            if (!iseven)
            {
                Console.WriteLine("no");
            }
        }
    }
}