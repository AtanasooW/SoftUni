﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _6._Cards_Game
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> deck1 = Console.ReadLine().Split().Select(int.Parse).ToList();
            List<int> deck2 = Console.ReadLine().Split().Select(int.Parse).ToList();
            int j = 0;
            for (int i = 0; i < 848181; i++)
            {
                if (deck1[j] > deck2[j])
                {
                    int save = deck1[j];
                    deck1.Add(deck2[j]);
                    deck1.RemoveAt(j);
                    deck1.Add(save);
                    deck2.RemoveAt(j);
                    //Console.WriteLine(String.Join(' ', deck1));
                    //Console.WriteLine(String.Join(' ', deck2));
                    if (deck2.Count == 0)
                    {
                        Console.WriteLine($"First player wins! Sum: {deck1.Sum()}");
                        break;
                    }
                }
                else if (deck1[j] < deck2[j])
                {
                    int save = deck2[j];
                    deck2.Add(deck1[j]);
                    deck2.RemoveAt(j);
                    deck2.Add(save);
                    deck1.RemoveAt(j);
                    //Console.WriteLine(String.Join(' ', deck1));
                    //Console.WriteLine(String.Join(' ', deck2));
                    if (deck1.Count == 0)
                    {
                        Console.WriteLine($"Second player wins! Sum: {deck2.Sum()}");
                        break;
                    }
                }
                else if (deck1[j] == deck2[j])
                {
                    deck1.RemoveAt(j);
                    deck2.RemoveAt(j);

                    if (deck2.Count == 0)
                    {
                        Console.WriteLine($"First player wins! Sum: {deck1.Sum()}");
                        break;
                    }
                    else if (deck1.Count == 0)
                    {
                        Console.WriteLine($"Second player wins! Sum: {deck2.Sum()}");
                        break;
                    }
                }

            }
        }
    }
}
