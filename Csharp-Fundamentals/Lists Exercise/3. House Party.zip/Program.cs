﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _3._House_Party
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int peopleCount = int.Parse(Console.ReadLine());
            List<string> peopleNames = new List<string>();
            bool isItHere = false;
            for (int i = 0; i < peopleCount; i++)
            {
                List<string> people = Console.ReadLine().Split(' ').ToList();
                if (people[2] != "not")
                {
                    if (peopleNames.Contains(people[0]))
                    {
                        Console.WriteLine($"{people[0]} is already in the list!");
                        isItHere = true;
                    }
                    if (isItHere == false)
                    {
                        peopleNames.Add(people[0]);

                    }
                }
                else if (people[2] == "not")
                {
                    if (!peopleNames.Contains(people[0]))
                    {
                        Console.WriteLine($"{people[0]} is not in the list!");
                    }
                    if (peopleNames.Contains(people[0]))
                    {
                        peopleNames.Remove(people[0]);
                    }
                }
                isItHere = false;
            }
            foreach (string name in peopleNames)
            {
                Console.WriteLine(name);
            }
        }
    }
}
