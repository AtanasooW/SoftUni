﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _05._Bomb_Numbers
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> nums = Console.ReadLine().Split().Select(int.Parse).ToList();
            List<int> power = Console.ReadLine().Split().Select(int.Parse).ToList();
            int sum = 0;
            for (int i = 0; i < nums.Count; i++)
            {
                if (nums[i] == power[0])
                {
                    for (int j = 1; j <= power[1]; j++)
                    {
                        if (i - j < 0)
                        {
                            break;
                        }
                        else
                        {
                        nums[i - j] = 0;
                                
                        }
                    }
                    for (int k = 1; k <= power[1]; k++)
                    {
                        if (i + k > nums.Count - 1)
                        {
                            break;
                        }
                        else
                        {
                            nums[i + k] = 0;
                        }
                    }
                    nums[i] = 0;
                    
                }
            }
            //Console.WriteLine(String.Join(' ', nums));
            foreach (int num in nums)
            {
                sum += num;
            }
            Console.WriteLine(sum);
        }
    }
}
