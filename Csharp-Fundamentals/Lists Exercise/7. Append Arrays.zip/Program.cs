﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _7._Append_Arrays
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string nums1 = Console.ReadLine();
            char[] alod = nums1.ToCharArray();
            List<char> final = new List<char>(alod.Length);


            for (int i = alod.Length - 1; i > -151581; i--)
            {
                if (alod[i] == '|' || alod[i] == alod[0])
                {
                    for (int j = i; j < alod.Length - 1; j++)
                    {
                        
                        if (alod[i] == alod[0])
                        {
                            if (alod[0] == '|')
                            {
                                if (alod[j + 1] != ' ')
                                {
                                    char penq = alod[j + 1];
                                    final.Add(penq);

                                }
                                else if (alod[j] == '|')
                                {
                                    break;

                                }

                            }
                            if (alod[j] == '|')
                            {
                                break;

                            }
                            else if (alod[j] != ' ')
                            {
                                char penq = alod[j];
                                final.Add(penq);

                            }
                        }
                        else if (alod[j + 1] != '|')
                        {

                            if (alod[j + 1] == '|')
                            {
                                break;
                            }
                            else if (alod[j + 1] != ' ')
                            {
                                char penq = alod[j + 1];
                                final.Add(penq);
                            }
                        }
                        else
                        {
                            break;
                        }

                    }
                    if (alod[i] == alod[0])
                    {
                        break;
                    }
                }
            }
            Console.WriteLine(String.Join(' ', final));
        }
    }
}
