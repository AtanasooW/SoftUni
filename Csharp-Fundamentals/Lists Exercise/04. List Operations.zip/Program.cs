﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _04._List_Operations
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> nums = Console.ReadLine().Split().Select(int.Parse).ToList();
            string[] command = Console.ReadLine().Split();
            while (command[0] != "End")
            {
                switch (command[0])
                {
                    case "Add":
                        nums.Add(int.Parse(command[1]));
                        break;
                    case "Remove":
                        if (nums.Count <= int.Parse(command[1]) || int.Parse(command[1]) < 0)
                        {
                            Console.WriteLine("Invalid index");
                        }
                        else
                        {
                            nums.RemoveAt(int.Parse(command[1]));

                        }
                        break;
                    case "Insert":
                        if (nums.Count <= int.Parse(command[2]) || int.Parse(command[2]) < 0)
                        {
                            Console.WriteLine("Invalid index");
                        }
                        else
                        {
                            nums.Insert(int.Parse(command[2]), int.Parse(command[1]));
                        }
                        break;
                }
                switch (command[1])
                {
                    case "left":
                        for (int i = 0; i < int.Parse(command[2]); i++)
                        {
                            int firstDigit = nums[0];
                            nums.RemoveAt(0);
                            nums.Add(firstDigit);
                        }
                        break;
                    case "right":
                        for (int i = 0; i < int.Parse(command[2]); i++)
                        {
                            int lastDigit = nums[nums.Count - 1];
                            nums.RemoveAt(nums.Count - 1);
                            nums.Insert(0, lastDigit);
                        }
                        break;
                }
                command = Console.ReadLine().Split();
            }
            Console.WriteLine(String.Join(' ', nums));
        }
    }
}
