﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _1._Train
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> nums = Console.ReadLine()
                .Split()
                .Select(int.Parse)
                .ToList();
            int max = int.Parse(Console.ReadLine());
            string[] command = Console.ReadLine().Split();
            while (command[0] != "end")
            {
                if (command[0] == "Add")
                {
                    nums.Add(int.Parse(command[1]));
                    command = Console.ReadLine().Split();
                }
                else if (command[0] != "Add")
                {

                    int lastnum = int.Parse(command[0]);
                    while (command[0] != "Add" && command[0] != "end")
                    {
                        for (int i = 0; i < nums.Count; i++)
                        {
                            int penq = nums[i];
                            if (penq + int.Parse(command[0]) <= max)
                            {
                                nums[i] += int.Parse(command[0]);
                                break;
                            } 
                        }
                        command = Console.ReadLine().Split();

                    }
                }
            }
            Console.WriteLine(String.Join(' ', nums));
        }
    }
}
